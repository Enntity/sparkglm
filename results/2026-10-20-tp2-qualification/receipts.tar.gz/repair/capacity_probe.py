# SPDX-License-Identifier: AGPL-3.0-only
"""One near-limit prefix, native/serial equality and four cached branches."""
import concurrent.futures as cf
import datetime,hashlib,json,re,subprocess,threading,time,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=Path.cwd()/'capacity';OUT.mkdir(exist_ok=False)
URL='http://127.0.0.1:8893';LIMIT=1048576;OLD_LIMIT=1014752
record={'passed':False,'context_limit':LIMIT,'old_resident_limit':OLD_LIMIT,'requests':[],'memory':[]}
stop=threading.Event();save_lock=threading.RLock()
def save():
 with save_lock:(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
def memwatch():
 while not stop.is_set():
  try:
   remote=subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','ennspark02-fab','cat /proc/meminfo'],text=True,timeout=10)
   for host,raw in [('ennspark01',Path('/proc/meminfo').read_text()),('ennspark02',remote)]:
    info={}
    for line in raw.splitlines():
     key,rest=line.split(':',1)
     if key in ('MemAvailable','MemFree','SwapFree'):info[key+'_kib']=int(rest.split()[0])
    record['memory'].append({'host':host,'time':time.time(),**info})
  except Exception as exc:record.setdefault('memory_monitor_errors',[]).append(repr(exc))
  stop.wait(5)
def post(path,body,timeout=1800):
 req=urllib.request.Request(URL+path,json.dumps(body).encode(),{'Content-Type':'application/json'})
 return urllib.request.urlopen(req,timeout=timeout)
def tokenize(prompt,messages=False):
 body={'messages':[{'role':'user','content':prompt}],'chat_template_kwargs':{'reasoning_effort':'low'}} if messages else {'prompt':prompt}
 with post('/tokenize',body,180) as response:data=json.load(response)
 ids=data.get('tokens');n=data.get('count',len(ids) if ids else None);assert isinstance(n,int)
 return n
BASE={'model':'glm-5.3-flash-atlas','temperature':0,'top_k':1,'top_p':1,'min_p':0,'repetition_penalty':1,
      'chat_template_kwargs':{'reasoning_effort':'low'},'return_token_ids':True,'max_tokens':192,
      'stream':True,'stream_options':{'include_usage':True}}
def request(prompt,serial,label,barrier=None,cancel=False):
 body=dict(BASE,messages=[{'role':'user','content':prompt}],disable_mtp=serial)
 if label.startswith(('extended-','cached-C4','cancelled-')):body['max_tokens']=384
 if barrier:barrier.wait(timeout=30)
 row={'label':label,'serial':serial,'started':time.monotonic(),'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),
      'body_without_messages':{k:v for k,v in body.items() if k!='messages'},'events':[],'token_ids':[],'content':'','reasoning_content':''}
 with save_lock:record['requests'].append(row);save()
 try:
  with post('/v1/chat/completions',body) as response:
   for raw in response:
    if not raw.startswith(b'data:'):continue
    data=raw[5:].strip()
    if data==b'[DONE]':row['done']=True;break
    e=json.loads(data);row['events'].append(e);assert not e.get('error'),e
    if e.get('usage'):row['usage']=e['usage']
    for choice in e.get('choices',[]):
     delta=choice.get('delta') or {};ids=choice.get('token_ids') or delta.get('token_ids') or []
     row['token_ids'].extend(ids)
     for key in ('content','reasoning_content'):row[key]+=delta.get(key) or ''
     if choice.get('finish_reason'):row['finish_reason']=choice['finish_reason']
    if cancel and row['token_ids'] and not row.get('finish_reason'):row['cancelled']=True;break
 except BaseException as exc:
  row['error']=repr(exc);raise
 finally:
  row['ended']=time.monotonic();save()
 if cancel:assert row.get('cancelled') and not row.get('finish_reason') and not row.get('done'),'Request finished before cancellation'
 if not cancel:
  assert row.get('done') and row.get('usage') and row['token_ids']
  assert row.get('finish_reason')=='stop','Near-limit answer truncated'
  if serial:assert accepted(row)==0
 return row
def accepted(row):return row['usage'].get('completion_tokens_details',{}).get('accepted_prediction_tokens',0)
def cached(row):return row['usage'].get('prompt_tokens_details',{}).get('cached_tokens',0)
def logs(rank,since=None,until=None):
 args=['docker','logs']
 if since:args+=['--since',since]
 if until:args+=['--until',until]
 args+=['atlas-sparkglm-rc-repair-rank'+str(rank)]
 if rank:args=['ssh','-o','BatchMode=yes','ennspark02-fab',*args]
 raw=subprocess.check_output(args,stderr=subprocess.STDOUT,text=True,timeout=30)
 return re.sub(r'\x1b\[[0-9;]*m','',raw)
def utcnow():return datetime.datetime.now(datetime.timezone.utc).isoformat()
monitor=threading.Thread(target=memwatch,daemon=True);monitor.start()
try:
 allocations=[]
 for rank in (0,1):
  raw=logs(rank);(OUT/('rank'+str(rank)+'-allocation.log')).write_text(raw)
  agreed=re.findall(r'KV cache: rank '+str(rank)+r' fits \d+ blocks; all ranks agree on (\d+)',raw)
  allocated=re.findall(r'KV cache: (\d+) blocks [×x] 11 layers',raw)
  assert allocated,'Missing allocated target KV pool evidence'
  target=int(allocated[-1]);assert target>=65538,target
  if agreed:assert int(agreed[-1])==target,(agreed,target)
  allocation={'rank':rank,'target_blocks':target}
  if rank==0:
   matches=re.findall(r'native GLM MTP private KV allocated from joint aggregate budget.*?target_blocks=(\d+).*?private_blocks=(\d+)',raw)
   assert matches,'Missing rank-0 native MTP private KV allocation evidence'
   private_target,private=map(int,matches[-1]);assert private_target==target and private==target+4,(target,private_target,private)
   allocation['private_blocks']=private
  allocations.append(allocation)
 assert allocations[0]['target_blocks']==allocations[1]['target_blocks'],'Rank KV allocation disagreement'
 record['allocations']=allocations;save()
 unit='The archive contains ordinary maintenance notes about pumps, valves, lamps, and clocks. No secret marker appears in this ordinary record.\n'
 count=tokenize(unit);copies=(1047000-512)//count
 def make(n):return 'Read this archive.\n'+unit*(n//2)+'\nThe unique archive marker is ORCHID-7291.\n'+unit*(n-n//2)+'\nState only the unique archive marker, exactly.'
 prompt=make(copies);n=tokenize(prompt,True)
 copies+=(1047000-n)//count;prompt=make(copies);n=tokenize(prompt,True)
 assert OLD_LIMIT+2048<n<LIMIT-256,(n,OLD_LIMIT,LIMIT)
 (OUT/'prompt.txt').write_text(prompt)
 record.update(prompt_tokens_tokenizer=n,prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),unit_tokens=count,copies=copies);save()
 serial=request(prompt,True,'near-limit-serial')
 native=request(prompt,False,'near-limit-native')
 assert serial['token_ids']==native['token_ids'],'Near-limit native/serial tokens differ'
 assert accepted(native)>0 and cached(native)>0,'Native/cached path not exercised'
 assert all('ORCHID-7291' in r['content'] for r in (serial,native)),'Near-limit marker retrieval failed'
 assert all(r['usage']['prompt_tokens']>OLD_LIMIT for r in (serial,native))
 suffix=' Then write three short sentences explaining why the maintenance archive needs an exact identifier.';extension=prompt+suffix
 record['extension_suffix']=suffix
 seeded=request(extension,False,'extended-prefix-native')
 assert cached(seeded)>0 and accepted(seeded)>0 and 'ORCHID-7291' in seeded['content']
 barrier=threading.Barrier(4)
 wave_start=utcnow()
 with cf.ThreadPoolExecutor(4) as pool:branches=list(pool.map(lambda i:request(extension,False,'cached-C4-'+str(i),barrier),range(4)))
 wave_end=utcnow();raw=logs(0,wave_start,wave_end);(OUT/'c4-scheduler.log').write_text(raw)
 record['c4_scheduler_active4']=bool(re.search(r'DFLASH WIDTH n_active=4\b',raw));save()
 assert record['c4_scheduler_active4'],'No scheduler evidence of four simultaneously active sequences'
 assert max(r['started'] for r in branches)<min(r['ended'] for r in branches),'Branches did not overlap'
 for r in branches:assert cached(r)>0 and accepted(r)>0 and r['token_ids']==seeded['token_ids'],'Cached C4 branch differs'
 cancel_suffix=' Then write 100 numbered maintenance instructions, each a complete sentence.'
 record['cancel_suffix']=cancel_suffix
 request(prompt+cancel_suffix,False,'cancelled-long-prefix',cancel=True)
 reused=request('What is 17 + 25? Reply with only the integer.',False,'slot-reuse')
 assert reused['content'].strip()=='42'
 stop.set();monitor.join(timeout=15)
 assert not monitor.is_alive() and not record.get('memory_monitor_errors'),'Memory monitor failed'
 assert all(any(r['host']==host for r in record['memory']) for host in ('ennspark01','ennspark02')),'Missing host memory samples'
 assert all(r['MemAvailable_kib']>=4096*1024 for r in record['memory']),'Loaded host headroom fell below 4 GiB'
 record['passed']=True
except BaseException as exc:
 record['error']=repr(exc);raise
finally:
 stop.set();monitor.join(timeout=15)
 record['minimum_MemAvailable_kib']={host:min((r['MemAvailable_kib'] for r in record['memory'] if r['host']==host),default=None) for host in ('ennspark01','ennspark02')}
 save()
