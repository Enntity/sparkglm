# SPDX-License-Identifier: AGPL-3.0-only
"""Correct a chat response-schema assertion using saved receipts only."""
import hashlib, importlib.util, json, math, re, sys
from pathlib import Path
out=Path(sys.argv[1]).resolve()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):return json.loads((out/name).read_text())
checksums=out/'SHA256SUMS'
verified=0
for line in checksums.read_text().splitlines():
    digest,name=line.split('  ',1)
    p=(out/name).resolve();assert p.is_relative_to(out)
    assert sha(p)==digest,name
    verified+=1
old=read('dispatch-summary.json')
assert not old['complete'] and old['error']=="KeyError('token_ids')"
assert old['delta']>0 and old['new_spec_requests']==old['reused_serial_requests']==960
assert old['serial_control_sha256']==sha(out/'dist-serial.json')
module=importlib.util.spec_from_file_location('saved_specsample',out/'specsample.py')
s=importlib.util.module_from_spec(module);module.loader.exec_module(s)
docs=[read('dist-spec.json'),read('dist-serial.json')]
for doc in docs:
    s.validate_document(doc)
    receipts=[r for rows in doc['receipts'].values() for r in rows]
    ids=[r['id'] for r in receipts]
    assert len(ids)==len(set(ids))==960 and all(ids)
comparison=s.compare_documents(docs)
assert comparison=={k:v for k,v in read('compare-spec-serial.json').items() if k!='arms'}
assert comparison['result']=='NO_DIFFERENCE_DETECTED'
request=read('chat-smoke.request.json');chat=read('chat-smoke.response.json')
assert request['temperature']==0.7 and request.get('disable_mtp') is not True
c=chat['choices'][0]
assert c['finish_reason']=='stop' and c['message']['content'].strip()
assert chat['usage']['completion_tokens']>0
assert chat['usage']['completion_tokens_details']['accepted_prediction_tokens']>0
def metric(name):
    text=(out/name).read_text()
    matches=re.findall(r'^vllm:spec_decode_num_drafts_total(?:\{[^\n]*\})?\s+([0-9.eE+-]+)\s*$',text,re.M)
    assert len(matches)==1
    val=float(matches[0]);assert math.isfinite(val) and val>=0;return val
delta=metric('chat-after.metrics.txt')-metric('chat-before.metrics.txt');assert delta>0
result={'schema':'sparkglm.saved-sampler-reassessment/v1','passed':True,
        'new_inference_requests':0,'original_summary_sha256':sha(out/'dispatch-summary.json'),
        'original_checksums_sha256':sha(checksums),'verified_files':verified,
        'new_spec_requests':960,'reused_serial_requests':960,'chat_smoke_requests':1,
        'chat_smoke_passed':True,'chat_draft_counter_delta':delta,
        'comparison_result':comparison['result'],'worst':comparison['worst'],
        'reason':'Non-streaming chat does not return choice.token_ids. Saved natural stop, content, usage and positive native draft/acceptance counters satisfy the intended chat smoke check. Original failure is retained.',
        'script_sha256':sha(Path(__file__))}
with (out/'assessment-corrected.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
