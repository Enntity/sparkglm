<!-- SPDX-License-Identifier: AGPL-3.0-only -->
# Frozen GLM TP2 RC release validation

Freeze engine e1ee623547ee8ca85abb4e17091907cb267175fe and image sha256:f5c00e667bd2473ec26a243a3c2d28573a8986bbe8a8063f078b30e5f0051a20. No engine tuning during this run. Reserve only 01/02 with LLooM. Production Qwen on 03/04 stays running. Uncap both GPUs for all measurements; restore caps and managed serving afterwards.

Run Spark and Strict+native-MTP with normal 4x1m, .91, KV sharding, display carveout and 48GiB prefix cache. Strict+MTP uses per-request serial controls. Gate supplement (30 behavior completions including logprobs/schema/vision), sampler (160 independent draws per each of six cells per arm), 14 tool calls, greedy C1/C4, frozen 52 quality cases, 60 long needles, and prompt NLL on the same frozen >20K token corpus. Native MTP also gets its existing normal-serving lifecycle probe (C4, prefix clones, 70K context, cancellation, schema, sampling). Configured 1M is not claimed as tested 1M.

Use Low reasoning and an 8192-token ceiling for answer-quality cases; reject all truncated quality/needle outputs. Preserve full requests/responses. Bounded token-parity probes may intentionally finish at their token limit. All transport/completeness, tools, schema/vision, exact speculative/serial token parity and lifecycle assertions must pass. Sampler adjusted p<=.01 fails; non-rejection is limited evidence, not equivalence. Paired Spark quality must not score below Strict in any category/context stratum and every Spark-only failure requires review before release. As a conservative screening threshold, Spark prompt NLL may rise no more than .02 nats/token versus Strict; report the actual delta. Baseline misses are reported, not erased.

For both 4x1m modes run RigMark three decode workloads twice, cold/warm prefill at 8K/32K/64K twice, and C1/C2/C3/C4 twice. Use separate fresh 8x128k loads for full Kindling (80 runs /193 streams) in Spark and default Strict serial. Record profile and draft mode explicitly. Benchmark completeness, content and timing audit must pass. Do not compare different profiles as matched. Compare existing historical NVFP4 numbers only with compatible current cells.

Record identity and uncapped clocks before/after each load, preserve server logs, reject restarted containers, maintain lease heartbeat. Run current product static checks and reconcile release docs only after results. Publish only if gates pass; failures leave the RC unqualified with evidence.

Harness-only adaptations: route NLL output to this run; explicit Low for long needles; add strict no-truncation answer-quality postcheck. Frozen original fixtures and benchmark code otherwise reused.
