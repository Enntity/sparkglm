<!-- SPDX-License-Identifier: AGPL-3.0-only -->
# Surgical repair after failed native-MTP sampler

The user explicitly requested a surgical fix without rerunning all validation. Preserve every frozen-image receipt, including the failed sampler and the .91 native-MTP capacity warning. Complete the currently running first-pass Strict normal phase, then stop at its existing phase boundary and restore the reservation normally.

The only engine repair is a temperature guard on the masked-chat raw-argmax shortcut. Greedy behavior is unchanged; sampled requests fall through to the existing processed target sampler. Add a real decision-path regression, run it red before the change and green after, review the exact diff, and record a new source commit, install tree, binary and image identity.

Carry forward unaffected frozen greedy, tools, NLL, retrieval and Spark results with explicit provenance and the code-based applicability argument. Repeat the failed native sampled-distribution gate and focused greedy equality checks on the repaired image. Complete the previously unrun Kindling benchmarks on that image. Do not label carried-forward results as rerun or erase the failed candidate.

Separately validate the existing .92 utilization setting for native MTP while keeping the 4096 MiB guard, prefix caching and arithmetic policy. Record the actual KV allocation, memory headroom, a tokenizer-counted request crossing the old limit, and cache/concurrency behavior. A capacity estimate alone is not a pass.

Publication remains conditional on the final, combined assessment: original failures, repaired-gate results, unchanged-path evidence, remaining full benchmarks and capacity checks must be reconciled explicitly.
