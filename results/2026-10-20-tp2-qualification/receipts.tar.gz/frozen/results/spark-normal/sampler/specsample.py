#!/usr/bin/env python3
"""Sampled-verify fidelity checks against the running server (rank 0's host).

    specsample.py dist LABEL [N]      N uninterrupted raw-completion speculative draws per prompt/config
    specsample.py serial LABEL [N]    Same requests with disable_mtp=true (exact returned token IDs)
    specsample.py chain LABEL [N]     OPTIONAL DIAGNOSTIC (not a fidelity gate): the same draws one token per request (/v1/completions on
                                      token ids, max_tokens 1: the post-prefill sampler on a whole row; requires
                                      blocking completions return_token_ids support)
    specsample.py compare A B         chi-square homogeneity per prompt x temperature x position (A vs B)
    specsample.py greedy LABEL        T=0 sha of three fixed prompts (256 tokens each)
    specsample.py speed LABEL TEMP    five C1 prose requests at TEMP (the caller reads tok_step from the logs)
"""
import concurrent.futures as cf, hashlib, json, math, os, sys, urllib.request, uuid
from pathlib import Path
"""Observed completion contract; never resample, pad token IDs, or suppress EOS."""
import math

TERMINAL = '<terminal:stop>'

def checked_ids(value, expected=None):
    if not isinstance(value, list) or any(type(i) is not int or i < 0 for i in value):
        raise ValueError('missing/invalid returned token_ids; text re-tokenization is forbidden')
    if expected is not None and len(value) != expected:
        raise ValueError(f'expected {expected} returned token IDs, got {len(value)}')
    return value

def validate_sequence(ids, finish_reason, limit):
    checked_ids(ids)
    if len(ids) > limit:
        raise ValueError('returned IDs exceed requested token limit')
    if finish_reason not in ('stop', 'length'):
        raise ValueError('missing/unsupported finish_reason')
    if finish_reason == 'length' and len(ids) != limit:
        raise ValueError('length finish must reach requested token limit')
    return ids

def response_receipt(result, disable_mtp, limit):
    if not isinstance(result, dict) or result.get('error'):
        raise ValueError('invalid/error completion response')
    choices = result.get('choices')
    if not isinstance(choices, list) or len(choices) != 1 or not isinstance(choices[0], dict):
        raise ValueError('completion must have exactly one choice')
    choice = choices[0]
    if choice.get('index') != 0:
        raise ValueError('missing/unexpected choice index')
    ids = validate_sequence(choice.get('token_ids'), choice.get('finish_reason'), limit)
    usage = result.get('usage') or {}
    count = usage.get('completion_tokens')
    if type(count) is not int or count != len(ids):
        raise ValueError('raw completion token-count/usage mismatch')
    accepted = (usage.get('completion_tokens_details') or {}).get('accepted_prediction_tokens')
    if type(accepted) is not int or not 0 <= accepted <= len(ids):
        raise ValueError('missing/invalid accepted_prediction_tokens receipt')
    if disable_mtp and accepted != 0:
        raise ValueError('serial reference accepted speculative tokens')
    return {'ids': ids, 'usage': usage, 'id': result.get('id'),
            'finish_reason': choice['finish_reason'], 'disable_mtp': disable_mtp}

def marginal(receipt, position, limit):
    ids = validate_sequence(receipt['ids'], receipt['finish_reason'], limit)
    if not 0 <= position < limit:
        raise ValueError('position outside observation horizon')
    return ids[position] if position < len(ids) else TERMINAL

def stop_category(receipt, limit):
    validate_sequence(receipt['ids'], receipt['finish_reason'], limit)
    return (receipt['finish_reason'], len(receipt['ids']))

def fisher_stop_p(a, b):
    """Two-sided exact test of stopped/not-stopped; sparse stops are not pooled."""
    na, nb = len(a), len(b)
    if not na or not nb or any(type(x) is not bool for x in a+b):
        raise ValueError('nonempty boolean arms required')
    ka, kb = sum(a), sum(b)
    total, successes = na+nb, ka+kb
    def choose(n,k):
        return math.lgamma(n+1)-math.lgamma(k+1)-math.lgamma(n-k+1)
    def logp(x):
        return choose(na,x)+choose(nb,successes-x)-choose(total,successes)
    observed = logp(ka)
    probabilities = [math.exp(logp(x)) for x in range(max(0,successes-nb), min(na,successes)+1)
                     if logp(x) <= observed+1e-10]
    return min(1.0, math.fsum(probabilities))


URL = os.environ.get("BENCH_URL", "http://127.0.0.1:8893")
MODEL = os.environ.get("BENCH_MODEL", "glm-5.3-flash-atlas")
PROMPTS = [
    "Write one sentence about the sea.",
    "Name a fruit and describe its taste in a few words.",
    "Continue the story in one line: The old clockmaker opened the door and",
]
# (temperature, top_k, top_p, min_p, top_n_sigma): the server defaults' shape, and the reference card's
# (top-p only: the candidates' absent-mass path).
CONFIGS = {"a": (0.7, 20, 0.95, 0.08, 0.0), "b": (1.0, 0, 0.95, 0.0, 0.0)}
TOKENS = 8
SCHEMA = "specsample-uninterrupted-eos-v4"
MIN_GATE_SAMPLES = 160
KW = {"chat_template_kwargs": {"thinking": False, "enable_thinking": False}}


def post(path, body):
    req = urllib.request.Request(URL + path, data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    return urllib.request.urlopen(req, timeout=600)


def sampling(cfg):
    t, k, p, m, s = CONFIGS[cfg]
    return {"temperature": t, "top_k": k, "top_p": p, "min_p": m, "top_n_sigma": s,
            "repetition_penalty": 1.0, "presence_penalty": 0.0, "frequency_penalty": 0.0}



def stream_ids(content, cfg):
    raise ValueError("Streaming chat is not this blocking-completion gate; use completion_draw")


def recorded_post(body, receipt_path):
    # Save the exact request and response bytes before JSON/contract validation.
    # Each concurrent draw has a unique prefix; never overwrite earlier evidence.
    prefix = Path(receipt_path or ("raw-standalone/" + uuid.uuid4().hex))
    prefix.parent.mkdir(parents=True, exist_ok=True)
    with Path(str(prefix) + ".request.json").open("x") as f:
        json.dump(body, f)
    metadata = {"url": URL + "/v1/completions", "http_status": None}
    try:
        with post("/v1/completions", body) as response:
            metadata["http_status"] = response.status
            raw = response.read()
    except urllib.error.HTTPError as error:
        metadata["http_status"] = error.code
        raw = error.read()
        error.close()
        with Path(str(prefix) + ".response.bin").open("xb") as f:
            f.write(raw)
        metadata["error"] = str(error)
        with Path(str(prefix) + ".transport.json").open("x") as f:
            json.dump(metadata, f)
        raise
    except Exception as error:
        metadata["error"] = repr(error)
        with Path(str(prefix) + ".transport.json").open("x") as f:
            json.dump(metadata, f)
        raise
    with Path(str(prefix) + ".response.bin").open("xb") as f:
        f.write(raw)
    with Path(str(prefix) + ".transport.json").open("x") as f:
        json.dump(metadata, f)
    if metadata["http_status"] != 200:
        raise ValueError("completion HTTP status was not 200")
    return json.loads(raw)


def chain_ids(prompt_ids, cfg, receipt_path=None):
    # Diagnostic only: respect an observed stop; never request a continuation
    # after termination or silently condition on survival.
    ids, steps = [], []
    prefix = str(receipt_path or ("raw-chain/" + uuid.uuid4().hex))
    for position in range(TOKENS):
        body = {"model": MODEL, "prompt": prompt_ids + ids, "max_tokens": 1,
                "return_token_ids": True, "disable_mtp": True, **sampling(cfg)}
        result = recorded_post(body, prefix + f"-step{position}")
        receipt = response_receipt(result, True, 1)
        steps.append(receipt)
        ids.extend(receipt["ids"])
        if receipt["finish_reason"] == "stop":
            break
    finish = steps[-1]["finish_reason"]
    validate_sequence(ids, finish, TOKENS)
    return {"ids": ids, "finish_reason": finish, "steps": steps, "raw_prefix": prefix}


def prompt_ids(prompt):
    with post("/tokenize", {"messages": [{"role": "user", "content": prompt}], **KW}) as r:
        return checked_ids(json.loads(r.read()).get("tokens"))


def completion_draw(pid, cfg, disable_mtp, receipt_path=None):
    body = {"model": MODEL, "prompt": pid, "max_tokens": TOKENS,
            "return_token_ids": True, "disable_mtp": disable_mtp, **sampling(cfg)}
    prefix = str(receipt_path or ("raw-standalone/" + uuid.uuid4().hex))
    result = recorded_post(body, prefix)
    receipt = response_receipt(result, disable_mtp, TOKENS)
    receipt["raw_prefix"] = prefix
    return receipt


def preflight():
    # Same prompt IDs and endpoint, uninterrupted generation. Zero accepted
    # tokens is necessary but not sufficient to prove serial execution: the
    # parent must also validate scheduler logs/dispatch receipts.
    pid = prompt_ids(PROMPTS[0])
    spec = completion_draw(pid, "a", False)
    serial = completion_draw(pid, "a", True)
    print("PREFLIGHT_OK", json.dumps({"prompt_ids": pid, "spec": spec, "serial": serial}))


def ask(content, max_tokens, temperature, logprobs=False):
    body = {"model": MODEL, "max_tokens": max_tokens, "temperature": temperature,
            "chat_template_kwargs": {"thinking": False, "enable_thinking": False},
            "messages": [{"role": "user", "content": content}]}
    if logprobs:
        body.update({"logprobs": True, "top_logprobs": 0})
    req = urllib.request.Request(URL + "/v1/chat/completions", data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=600) as r:
        d = json.loads(r.read())
    c = d["choices"][0]
    lp = (c.get("logprobs") or {}).get("content")
    if lp:
        return [t["token"] for t in lp]
    return (c["message"].get("content") or "").split(" ")


def dist(label, n, mode="spec"):
    if n < 1 or mode not in ("spec", "serial", "chain"):
        raise ValueError("invalid sample count or mode")
    if not label or Path(label).name != label:
        raise ValueError("label must be a filename component")
    out = {"schema": SCHEMA, "url": URL, "model": MODEL, "requested_samples": n,
           "tokens": TOKENS, "configs": CONFIGS, "prompts": PROMPTS,
           "mode": mode, "complete": False, "samples": {}, "receipts": {}, "prompt_ids": {},
           "errors": {}, "terminal_category": TERMINAL,
           "sampling": {key: sampling(key) for key in CONFIGS}}
    path = Path(f"dist-{label}.json")
    rawdir = Path(f"raw-{label}")
    if path.exists() or rawdir.exists():
        raise FileExistsError(f"refusing to replace evidence for {label}; choose a fresh label")
    rawdir.mkdir()
    try:
        with cf.ThreadPoolExecutor(4) as ex:
            for i, p in enumerate(PROMPTS):
                pid = prompt_ids(p)
                out["prompt_ids"][str(i)] = pid
                for cfg in CONFIGS:
                    key = f"{i}{cfg}"
                    out["receipts"][key] = [None] * n
                    jobs = {}
                    for draw in range(n):
                        prefix = str(rawdir / f"{key}-{draw:04d}")
                        if mode == "chain":
                            job = ex.submit(chain_ids, pid, cfg, prefix)
                        else:
                            job = ex.submit(completion_draw, pid, cfg, mode == "serial", prefix)
                        jobs[job] = (draw, prefix)
                    # Drain every submitted future even after one fails. Successful
                    # peers and all raw responses survive; never redraw a failure.
                    for job in cf.as_completed(jobs):
                        draw, prefix = jobs[job]
                        try:
                            out["receipts"][key][draw] = job.result()
                        except Exception as error:
                            out["errors"].setdefault(key, []).append(
                                {"draw": draw, "raw_prefix": prefix, "error": repr(error)})
                    receipts = out["receipts"][key]
                    out["samples"][key] = [r["ids"] if r is not None else None for r in receipts]
                    if out["errors"].get(key):
                        raise ValueError(f"{key}: {len(out['errors'][key])} failed draws; see raw evidence")
                    got = out["samples"][key]
                    print(label, key, "distinct", len({tuple(x) for x in got}), "of", len(got), flush=True)
        out["complete"] = True
    except Exception as error:
        out["error"] = repr(error)
        raise
    finally:
        with path.open("x") as f:
            json.dump(out, f)


def q_gamma(a, x):
    """Regularized upper incomplete gamma Q(a, x) (Numerical Recipes)."""
    if x <= 0:
        return 1.0
    if x < a + 1:
        s, term, ap = 1.0 / a, 1.0 / a, a
        for _ in range(1000):
            ap += 1
            term *= x / ap
            s += term
            if abs(term) < abs(s) * 1e-14:
                break
        return 1.0 - s * math.exp(-x + a * math.log(x) - math.lgamma(a))
    b, c, d = x + 1 - a, 1e300, 1.0 / (x + 1 - a)
    h = d
    for i in range(1, 1000):
        an = -i * (i - a)
        b += 2
        d = an * d + b
        d = 1e-300 if abs(d) < 1e-300 else d
        c = b + an / c
        c = 1e-300 if abs(c) < 1e-300 else c
        d = 1.0 / d
        h *= d * c
        if abs(d * c - 1) < 1e-14:
            break
    return math.exp(-x + a * math.log(x) - math.lgamma(a)) * h


def chi2(a, b):
    """Homogeneity of two categorical samples: (stat, df, p); rare tokens pooled."""
    if not a or not b:
        raise ValueError("cannot compare an empty arm")
    cats = {}
    for x in a:
        cats.setdefault(x, [0, 0])[0] += 1
    for x in b:
        cats.setdefault(x, [0, 0])[1] += 1
    keep = [v for v in cats.values() if sum(v) >= 10]
    other = [sum(v[0] for v in cats.values() if sum(v) < 10), sum(v[1] for v in cats.values() if sum(v) < 10)]
    if sum(other) > 0:
        keep.append(other)
    na, nb = len(a), len(b)
    while len(keep) > 1 and any(sum(v) * min(na, nb) / (na + nb) < 5 for v in keep):
        keep.sort(key=sum)
        small = keep.pop(0)
        keep[0] = [keep[0][0] + small[0], keep[0][1] + small[1]]
    if len(keep) < 2:
        return 0.0, 0, 1.0
    stat = 0.0
    for ca, cb in keep:
        tot = ca + cb
        for o, n in ((ca, na), (cb, nb)):
            e = tot * n / (na + nb)
            stat += (o - e) ** 2 / e
    df = len(keep) - 1
    return stat, df, q_gamma(df / 2, stat / 2)


def validate_document(doc):
    if doc.get("schema") != SCHEMA or not doc.get("complete") or doc.get("errors"):
        raise ValueError("legacy, incomplete, or failed evidence is not a distribution gate")
    if type(doc.get("requested_samples")) is not int or doc["requested_samples"] < MIN_GATE_SAMPLES:
        raise ValueError(f"smoke data only: gate needs >= {MIN_GATE_SAMPLES} samples per cell")
    if doc.get("mode") not in ("spec", "serial"):
        raise ValueError("primary gate requires uninterrupted spec/serial; chain is diagnostic only")
    if doc.get("tokens") != TOKENS or doc.get("terminal_category") != TERMINAL:
        raise ValueError("wrong observation horizon/terminal schema")
    cells = {f"{i}{cfg}" for i in range(len(PROMPTS)) for cfg in CONFIGS}
    if set(doc.get("samples", {})) != cells or set(doc.get("receipts", {})) != cells:
        raise ValueError("missing prompt/config cells or receipts")
    for key, rows in doc["samples"].items():
        receipts = doc["receipts"][key]
        if len(rows) != doc["requested_samples"] or len(receipts) != len(rows):
            raise ValueError("missing samples/receipts")
        for row, r in zip(rows, receipts):
            validate_sequence(row, r["finish_reason"], TOKENS)
            if row != r["ids"] or r.get("disable_mtp") is not (doc["mode"] == "serial"):
                raise ValueError("sample/receipt/arm mismatch")
            # Recheck receipt semantics, not only stored marginal IDs.
            response_receipt({"choices": [{"index": 0, "token_ids": row,
                              "finish_reason": r["finish_reason"]}], "usage": r["usage"]},
                             doc["mode"] == "serial", TOKENS)


def compare_documents(documents):
    for doc in documents:
        validate_document(doc)
    if {doc["mode"] for doc in documents} != {"spec", "serial"}:
        raise ValueError("primary gate requires uninterrupted spec and serial modes")
    for field in ("tokens", "configs", "prompts", "model", "sampling", "prompt_ids"):
        if documents[0][field] != documents[1][field]:
            raise ValueError(f"mismatched {field}")
    a, b = (d["receipts"] for d in documents)
    tests = []
    for key in sorted(a):
        for pos in range(TOKENS):
            ma = [marginal(r, pos, TOKENS) for r in a[key]]
            mb = [marginal(r, pos, TOKENS) for r in b[key]]
            stat, df, p = chi2(ma, mb)
            tests.append({"kind": "token_or_absorbing_stop", "cell": key, "position": pos,
                          "chi2": stat, "df": df, "p": p})
            # Do not let rare-token pooling hide a difference in termination mass.
            sa, sb = ([x == TERMINAL for x in arm] for arm in (ma, mb))
            tests.append({"kind": "stopped_before_position_exact", "cell": key, "position": pos,
                          "stopped_counts": [sum(sa), sum(sb)], "totals": [len(sa), len(sb)],
                          "p": fisher_stop_p(sa, sb)})
        stat, df, p = chi2([stop_category(r, TOKENS) for r in a[key]],
                          [stop_category(r, TOKENS) for r in b[key]])
        tests.append({"kind": "finish_reason_and_length", "cell": key, "chi2": stat, "df": df, "p": p})
        stopped = [[r["finish_reason"] == "stop" for r in arm] for arm in (a[key], b[key])]
        tests.append({"kind": "stop_by_horizon_exact", "cell": key,
                      "stopped_counts": [sum(x) for x in stopped], "totals": [len(x) for x in stopped],
                      "p": fisher_stop_p(*stopped)})
    # Correct across every marginal and termination test in the entire family.
    for test in tests:
        test["adjusted_p"] = min(1.0, test["p"] * len(tests))
    worst = min(tests, key=lambda t: t["adjusted_p"])
    return {"schema": SCHEMA, "tests": tests, "worst": worst,
            "result": "DIFFERENCE_DETECTED" if worst["adjusted_p"] <= 0.01 else "NO_DIFFERENCE_DETECTED",
            "limitation": "Non-rejection is not equivalence. Position/termination marginals do not prove joint-sequence equality. Preserve exact image/profile and scheduler dispatch receipts; acceptance=0 alone does not prove serial execution. Stop is an observed finish reason, not an inferred EOS token ID."}


def compare(la, lb):
    documents = [json.loads(Path(f"dist-{label}.json").read_text()) for label in (la, lb)]
    result = compare_documents(documents)
    result["arms"] = [la, lb]
    with Path(f"compare-{la}-{lb}.json").open("x") as f:
        json.dump(result, f)
    print(json.dumps({k: result[k] for k in ("arms", "worst", "result", "limitation")}))
    if result["result"] == "DIFFERENCE_DETECTED":
        raise SystemExit(1)


def greedy(label):
    fill = ("The archive held ledgers, maps and letters from many decades, each catalogued with care. ")
    for i, p in enumerate(["Write a reflective essay about walking through a city at dawn, in plain paragraphs.",
                           "Write a complete Python module implementing an LRU cache class with docstrings.",
                           "Fixed exactness prompt v1.\n\n" + fill * 300 + "\nList three themes of this archive."]):
        t = "".join(ask(p, 256, 0))
        print(label, "greedy", i, hashlib.sha1(t.encode()).hexdigest()[:12], repr(t[:50]))


def speed(label, temp):
    p = "Write a reflective essay about walking through a city at dawn, in plain paragraphs."
    ask("Say hi.", 8, 0)
    for _ in range(5):
        ask(f"Run tag {uuid.uuid4().hex[:12]}.\n\n" + p, 512, temp)
    print(label, "speed done", temp)


if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "preflight":
        preflight()
    elif cmd in ("dist", "serial", "chain"):
        dist(sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 160, "spec" if cmd == "dist" else cmd)
    elif cmd == "compare":
        compare(sys.argv[2], sys.argv[3])
    elif cmd == "greedy":
        greedy(sys.argv[2])
    elif cmd == "speed":
        speed(sys.argv[2], float(sys.argv[3]))
