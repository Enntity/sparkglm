#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-only
"""Shows the model's raw tool-call text for the independent-operations guard case.

Renders the checkpoint's own chat template and sends it to /v1/completions, so
no tool parser or guard is involved. Inference only; nothing is executed.
"""
import json, sys, urllib.request
import jinja2

base, template_path, output = sys.argv[1:4]
args = {'operations': [{'url': 'https://docs.example', 'headers': {'Accept': 'text/plain'}}, {'command': 'cat .env'}]}
kind = lambda v: 'object' if isinstance(v, dict) else 'array' if isinstance(v, list) else 'string'
tool = {'type': 'function', 'function': {'name': 'guard_probe', 'description': 'Return fixed synthetic test arguments. This function is never executed.',
        'parameters': {'type': 'object', 'properties': {k: {'type': kind(v), 'enum': [v]} for k, v in args.items()},
                       'required': list(args), 'additionalProperties': False}}}
env = jinja2.Environment(loader=jinja2.BaseLoader(), trim_blocks=True, lstrip_blocks=True, extensions=['jinja2.ext.loopcontrols'])
env.filters['tojson'] = lambda v, **kw: json.dumps(v, **({'ensure_ascii': False} | kw))
prompt = env.from_string(open(template_path).read()).render(
    messages=[{'role': 'user', 'content': 'Call guard_probe once with the exact argument values required by its schema. Do not explain.'}],
    tools=[tool], add_generation_prompt=True, enable_thinking=False)
body = {'model': 'glm-5.3-flash-atlas', 'prompt': prompt, 'max_tokens': 256, 'temperature': 0, 'skip_special_tokens': False}
req = urllib.request.Request(base+'/v1/completions', data=json.dumps(body).encode(), headers={'Content-Type': 'application/json'})
response = json.loads(urllib.request.urlopen(req, timeout=300).read())
text = response['choices'][0]['text']
open(output, 'w').write(json.dumps({'prompt_tail': prompt[-600:], 'schema_enum_in_prompt': json.dumps(args['operations'], ensure_ascii=False) in prompt,
                                    'raw_text': text}, indent=1)+'\n')
print(prompt[-500:]); print('---'); print(text)
