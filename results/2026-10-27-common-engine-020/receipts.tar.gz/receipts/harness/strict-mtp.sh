#!/usr/bin/env bash
# Strict native MTP on 03/04 with the same arguments start.sh passes, plus --strict-mtp.
set -euo pipefail
cd ~/sparkglm-q020/src
set -a; . ./.env; set +a
IMAGE=$(install/build.sh --tag)
line=$(./start.sh fabric | sed "s/\x1b\[[0-9;]*m//g" | grep "fabric:")
read -r hca0 iface0 ip0 hca1 iface1 < <(sed -E "s/.*fabric: ([^ ]+) \(([^,]+), ([^)]+)\) here; ([^ ]+) \(([^,]+), .*/\1 \2 \3 \4 \5/" <<< "$line")
ip0=${ip0%/*}
common=(--leader-address "$ip0" --model-root "$MODEL_ROOT" --checkpoint nvidia--GLM-5.3-Flash-FP4-Local --image "$IMAGE"
        --profile 4x1m --mode strict --strict-mtp --tool-guard on --tool-guard-max-bytes 1048576 --kv-shard)
docker rm -f atlas-sparkglm-rank0 >/dev/null 2>&1 || true
ssh "$WORKER" docker rm -f atlas-sparkglm-rank1 >/dev/null 2>&1 || true
ssh "$WORKER" "bash -s -- $(printf "%q " --rank 1 --fabric-hca "$hca1" --fabric-interface "$iface1" --no-fabric-siblings "${common[@]}")" < install/start-node.sh
install/start-node.sh --rank 0 --fabric-hca "$hca0" --fabric-interface "$iface0" --no-fabric-siblings "${common[@]}"
