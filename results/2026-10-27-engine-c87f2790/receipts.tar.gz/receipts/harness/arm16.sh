#!/usr/bin/env bash
# SPDX-License-Identifier: AGPL-3.0-only
# One atlas#16 check arm on 03/04: start the fix image in MODE (strict | strict-mtp | spark),
# record identity, then run every suite, the probes and the spelled-markup probe.
set -uo pipefail
mode=$1 q=~/sparkglm-q020 R=~/sparkglm-q020/${RUNS:-runs16}/$1
mkdir -p "$R"; cd "$q/src"
./start.sh stop >/dev/null 2>&1
if [[ $mode == strict-mtp ]]; then
  "$q/strict-mtp.sh" > "$R/start.log" 2>&1
  for i in $(seq 90); do curl -sf http://127.0.0.1:8893/health >/dev/null && break; sleep 10; done
else
  MODE=$mode ./start.sh up > "$R/start.log" 2>&1
fi
echo "start exit $?"; sed 's/\x1b\[[0-9;]*m//g' "$R/start.log" | grep -E 'smoke|ready' || true
cd "$q"
python3 harness/identity.py --worker 10.100.112.2 --model-root "$q/models" --output "$R/identity.json"
date -u +%FT%TZ > "$R/main.start"
python3 harness/qualify.py --base-url http://127.0.0.1:8893 --output "$R/suite" > "$R/suite.log" 2>&1; echo $? > "$R/suite.exit"
python3 harness/probes.py --base-url http://127.0.0.1:8893 --output "$R/probes.json" > "$R/probes.log" 2>&1
python3 harness/spelled.py --base-url http://127.0.0.1:8893 --output "$R/spelled.json" > "$R/spelled.log" 2>&1
docker logs --since "$(cat "$R/main.start")" atlas-sparkglm-rank0 > "$R/rank0.log" 2>&1
ssh 10.100.112.2 docker logs --since "$(cat "$R/main.start")" atlas-sparkglm-rank1 > "$R/rank1.log" 2>&1
python3 harness/guardlog.py "$R/suite/summary.json" "$R/guard-log.json" < "$R/rank0.log"
tail -1 "$R/suite.log"; grep '"ok": false' "$R/suite.log" | cut -c1-250
cut -c1-260 "$R/probes.log"; cut -c1-200 "$R/spelled.log"
