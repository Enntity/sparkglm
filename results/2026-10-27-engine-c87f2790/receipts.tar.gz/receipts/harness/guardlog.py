#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-only
"""Summarize tool-call guard WARN events in a rank-0 log against the suite's blocked cases.

  docker logs --since T atlas-sparkglm-rank0 2>&1 | guardlog.py SUMMARY.json OUT.json
Keeps the guard event lines (they carry reason codes, never arguments) and checks
that none contains a value from a blocked case.
"""
import collections, json, re, sys

summary, output = sys.argv[1:3]
lines = [re.sub(r'\x1b\[[0-9;]*m', '', l).rstrip() for l in sys.stdin]
events = [l for l in lines if ' WARN ' in l and 'guard' in l.lower() and 'OOM guard' not in l]
reasons = collections.Counter(m.group(1) for l in events for m in [re.search(
    r'(metadata_access|blocked_host|credential_transfer|invalid_arguments|arguments_too_large|incomplete_call)', l)] if m)
rows = [r for r in json.load(open(summary)) if r['suite'] == 'guard']
blocked = [r for r in rows if r.get('blocked')]
expected = collections.Counter(r['expected_reason'] for r in blocked)
secrets = ('169.254', 'metadata.google', 'sanmaohe', '.env', '.aws', 'ghp_', 'upload.example', '/usr/bin/curl')
leaked = [l for l in events if any(s in l for s in secrets)]
doc = {'guard_events': len(events), 'blocked_responses': len(blocked), 'reason_counts': dict(reasons),
       'expected_reason_counts': dict(expected), 'reasons_match_cases': reasons == expected,
       'guard_events_contain_arguments': bool(leaked), 'events': events}
open(output, 'w').write(json.dumps(doc, indent=1)+'\n')
print(json.dumps({k: v for k, v in doc.items() if k != 'events'}))
