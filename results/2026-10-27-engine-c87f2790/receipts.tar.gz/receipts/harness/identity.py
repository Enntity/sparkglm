#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-only
"""Record image, engine, checkpoint and launch identity of both running ranks.

  identity.py --worker HOST --model-root DIR --output FILE
Only SPARKGLM_*, ATLAS_* and NCCL_* environment values are kept.
"""
import argparse, json, pathlib, shlex, subprocess

p = argparse.ArgumentParser()
p.add_argument('--worker', required=True)
p.add_argument('--model-root', required=True)
p.add_argument('--output', required=True)
a = p.parse_args()


def run(cmd, worker=False):
    return subprocess.run(['ssh', '-o', 'BatchMode=yes', a.worker, shlex.join(cmd)] if worker else cmd, check=True, capture_output=True, text=True).stdout


def rank(n):
    worker = n == 1
    name = f'atlas-sparkglm-rank{n}'
    c = json.loads(run(['docker', 'inspect', name], worker))[0]
    env = dict(e.split('=', 1) for e in c['Config']['Env'])
    entry = (c['Config']['Entrypoint'] or [])+(c['Config']['Cmd'] or [])
    binary = run(['docker', 'exec', name, 'sh', '-c', 'sha256sum /usr/local/bin/spark'], worker).split()
    argv = run(['docker', 'exec', name, 'sh', '-c', 'for p in /proc/[0-9]*; do [ "$(readlink $p/exe)" = /usr/local/bin/spark ] && tr "\\0" "\\n" < $p/cmdline && break; done'], worker).splitlines()
    ckpt = {}
    for d in ('nvidia--GLM-5.3-Flash-FP4-Local', 'incoai--GLM-5.3-Flash-DFlash2'):
        out = run(['sh', '-c', f'cd {a.model_root}/{d} && sha256sum config.json $(ls *.index.json 2>/dev/null) && cat .sparkglm-revision'], worker).split('\n')
        ckpt[d] = {'revision': out[-2].strip(), 'sha256': {l.split()[1]: l.split()[0] for l in out[:-2] if l.strip()}}
    return {'rank': n, 'host': run(['hostname'], worker).strip(), 'container': name,
            'image': c['Config']['Image'], 'image_id': c['Image'],
            'labels': {k: v for k, v in c['Config']['Labels'].items() if k.startswith(('io.enntity', 'org.opencontainers.image.version'))},
            'started_at': c['State']['StartedAt'], 'status': c['State']['Status'], 'oom_killed': c['State']['OOMKilled'],
            'restart_count': c.get('RestartCount'), 'command': entry, 'engine_argv': argv, 'binary': {'path': binary[1], 'sha256': binary[0]},
            'env': {k: v for k, v in sorted(env.items()) if k.startswith(('SPARKGLM_', 'ATLAS_', 'NCCL_'))},
            'checkpoints': ckpt,
            'gpu': run(['nvidia-smi', '--query-gpu=name,driver_version,clocks.max.sm', '--format=csv,noheader'], worker).strip(),
            'clock_cap_service': run(['sh', '-c', 'systemctl is-active gpu-clock-cap.service || true'], worker).strip()}


ranks = [rank(0), rank(1)]
same = {k: len({json.dumps(r[k], sort_keys=True) for r in ranks}) == 1 for k in ('image_id', 'labels', 'binary', 'checkpoints')}
doc = {'schema': 'sparkglm.rank-identity/v1', 'ranks': ranks, 'ranks_match': same, 'all_match': all(same.values())}
pathlib.Path(a.output).write_text(json.dumps(doc, indent=1)+'\n')
print(json.dumps({'all_match': doc['all_match'], **same}))
