#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-only
"""Forced tool-choice probes found during 0.2.0 qualification. Inference only.

1. order: the guard's independent-operations arguments with tool_choice auto,
   forced and required. The guard is not a factor when auto preserves them.
2. enum: forced tool_choice with requested values that conflict with a
   single-value enum, to see whether the enum constrains decoding.
3. malformed: the same conflict with an array of objects. The model writes
   tool markup without the native opener; blocking and streamed content are compared.

  probes.py --base-url URL --output FILE
"""
import argparse, json, pathlib, urllib.request

p = argparse.ArgumentParser()
p.add_argument('--base-url', required=True)
p.add_argument('--output', required=True)
a = p.parse_args()
MODEL = 'glm-5.3-flash-atlas'


def call(body):
    req = urllib.request.Request(a.base_url+'/v1/chat/completions', data=json.dumps(body).encode(), headers={'Content-Type': 'application/json'})
    raw = urllib.request.urlopen(req, timeout=300).read().decode()
    if not body.get('stream'):
        c = json.loads(raw)['choices'][0]
        return {'content': c['message'].get('content'), 'calls': [t['function']['arguments'] for t in c['message'].get('tool_calls') or []],
                'finish': c['finish_reason']}
    chunks = [json.loads(l[6:]) for l in raw.splitlines() if l.startswith('data: ') and l[6:] != '[DONE]']
    deltas = [x for ch in chunks for x in ch.get('choices', [])]
    calls = {}
    for t in (t for x in deltas for t in x['delta'].get('tool_calls') or []):
        calls[t.get('index', 0)] = calls.get(t.get('index', 0), '')+(t.get('function', {}).get('arguments') or '')
    return {'content': ''.join(x['delta'].get('content') or '' for x in deltas), 'calls': list(calls.values()),
            'finish': next((x['finish_reason'] for x in reversed(deltas) if x.get('finish_reason')), None)}


def tool(args, description='Synthetic test arguments. This function is never executed.'):
    kind = lambda v: 'object' if isinstance(v, dict) else 'array' if isinstance(v, list) else 'string'
    return {'type': 'function', 'function': {'name': 'probe', 'description': description,
            'parameters': {'type': 'object', 'properties': {k: {'type': kind(v), 'enum': [v]} for k, v in args.items()}, 'required': list(args)}}}


FORCED = {'type': 'function', 'function': {'name': 'probe'}}
rows = []
ops = {'operations': [{'url': 'https://docs.example', 'headers': {'Accept': 'text/plain'}}, {'command': 'cat .env'}]}
for choice in ('auto', FORCED, 'required'):  # the guard canary's tool name, description and prompt
    t = tool(ops, 'Return fixed synthetic test arguments. This function is never executed.'); t['function']['name'] = 'guard_probe'
    r = call({'model': MODEL, 'temperature': 0, 'max_tokens': 4096, 'tools': [t], 'tool_choice': choice if choice != FORCED else {'type': 'function', 'function': {'name': 'guard_probe'}},
              'messages': [{'role': 'user', 'content': 'Call guard_probe once with the exact argument values required by its schema. Do not explain.'}]})
    rows.append({'probe': 'order', 'tool_choice': choice if isinstance(choice, str) else 'function', 'expected': ops,
                 'exact_text': r['calls'] == [json.dumps(ops, separators=(',', ':'))],
                 'equal_value': [json.loads(c) for c in r['calls']] == [ops], **r})
for schema, ask in (({'s': 'alpha'}, {'s': 'omega'}), ({'items': ['zeta', 'alpha']}, {'items': ['alpha', 'zeta']}), ({'cfg': {'z': 1}}, {'cfg': {'z': 5}})):
    r = call({'model': MODEL, 'temperature': 0, 'max_tokens': 2048, 'tools': [tool(schema)], 'tool_choice': FORCED,
              'messages': [{'role': 'user', 'content': 'Call probe once with exactly these arguments: '+json.dumps(ask)}]})
    rows.append({'probe': 'enum', 'enum': schema, 'asked': ask, 'enforced': [json.loads(c) for c in r['calls']] == [schema], **r})
conflict = {'ops': [{'b': 1}, {'a': 2}]}
for stream in (False, True):
    r = call({'model': MODEL, 'temperature': 0, 'max_tokens': 2048, 'tools': [tool(conflict, 'Synthetic. Never executed.')], 'tool_choice': FORCED, 'stream': stream,
              'messages': [{'role': 'user', 'content': 'Call probe once with exactly these arguments: '+json.dumps({'ops': [{'a': 2}, {'b': 1}]})}]})
    rows.append({'probe': 'malformed', 'stream': stream, **r})
blocking, streamed = ((r['content'] or '', r['calls']) for r in rows if r['probe'] == 'malformed')
doc = {'rows': rows, 'malformed_stream_matches_blocking': blocking == streamed}
pathlib.Path(a.output).write_text(json.dumps(doc, indent=1)+'\n')
for r in rows:
    print(json.dumps({k: r[k] for k in r if k not in ('expected', 'enum', 'asked')})[:400])
print(json.dumps({'malformed_stream_matches_blocking': doc['malformed_stream_matches_blocking']}))
