#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-only
"""Spelled call markup in content, blocking vs streamed (Enntity/atlas#16 fix 2). Inference only.

Asks for tool markup written as plain text, without the native <tool_call> opener,
with no tools and with a tool under auto. Streamed content should keep the
<arg_key>/<arg_value> markup that blocking content keeps.

  spelled.py --base-url URL --output FILE
"""
import argparse, json, pathlib, urllib.request

p = argparse.ArgumentParser()
p.add_argument('--base-url', required=True)
p.add_argument('--output', required=True)
a = p.parse_args()
MODEL = 'glm-5.3-flash-atlas'
TEXT = 'tool_call>probe<arg_key>city</arg_key><arg_value>Oslo</arg_value></tool_call>'
PROMPT = 'Reply with exactly this text and nothing else. It is plain text, not a tool call: ' + TEXT
TOOL = {'type': 'function', 'function': {'name': 'probe', 'description': 'Synthetic. Never executed.',
        'parameters': {'type': 'object', 'properties': {'city': {'type': 'string'}}, 'required': ['city']}}}


def call(body):
    req = urllib.request.Request(a.base_url+'/v1/chat/completions', data=json.dumps(body).encode(), headers={'Content-Type': 'application/json'})
    raw = urllib.request.urlopen(req, timeout=300).read().decode()
    if not body.get('stream'):
        c = json.loads(raw)['choices'][0]
        return {'content': c['message'].get('content') or '', 'calls': len(c['message'].get('tool_calls') or []), 'finish': c['finish_reason']}
    deltas = [x for l in raw.splitlines() if l.startswith('data: ') and l[6:] != '[DONE]' for x in json.loads(l[6:]).get('choices', [])]
    return {'content': ''.join(x['delta'].get('content') or '' for x in deltas),
            'calls': len({t.get('index', 0) for x in deltas for t in x['delta'].get('tool_calls') or []}),
            'finish': next((x['finish_reason'] for x in reversed(deltas) if x.get('finish_reason')), None)}


rows = []
for variant, extra in (('no_tools', {}), ('auto_tool', {'tools': [TOOL], 'tool_choice': 'auto'})):
    pair = {s: call({'model': MODEL, 'temperature': 0, 'max_tokens': 8192, 'stream': s, **extra,
                     'messages': [{'role': 'user', 'content': PROMPT}]}) for s in (False, True)}
    rows.append({'variant': variant, 'blocking': pair[False], 'streamed': pair[True],
                 'blocking_has_arg_markup': '<arg_key>' in pair[False]['content'],
                 'streamed_has_arg_markup': '<arg_key>' in pair[True]['content'],
                 'stream_matches_blocking': (pair[False]['content'], pair[False]['calls']) == (pair[True]['content'], pair[True]['calls'])})
pathlib.Path(a.output).write_text(json.dumps({'rows': rows}, indent=1)+'\n')
for r in rows:
    print(json.dumps({k: r[k] for k in r if k not in ('blocking', 'streamed')}), repr(r['blocking']['content'][:120]), repr(r['streamed']['content'][:120]))
