# SPDX-License-Identifier: AGPL-3.0-only
"""Compare every final chain/ring repetition and verify matched inputs."""
import json
from ops import ROOT, save

names = {top: f'tp4-{top}-spark-final' for top in ('chain', 'ring')}
results = {top: json.loads((ROOT / 'results' / arm / 'speed.json').read_text())
           for top, arm in names.items()}
assert all(row['passed'] and row['runs'] == 2 for row in results.values())
assert results['chain']['requests'] == results['ring']['requests']
assert results['chain']['prompts_sha256'] == results['ring']['prompts_sha256']
identity = {top: [json.loads((ROOT / arm / (f'ennspark0{i}-identity.json')).read_text())
                  for i in range(1, 5)] for top, arm in names.items()}
expected = {'ATLAS_RDMA_TOPOLOGY', 'ATLAS_RDMA_LEFT_RAILS', 'ATLAS_RDMA_RIGHT_RAILS',
            'ATLAS_KV_NVME_DIR', 'ATLAS_SSM_TIER_SWAP_DIR'}
config_diff = []
for chain, ring in zip(identity['chain'], identity['ring']):
    assert chain['image'] == ring['image'] and chain['source'] == ring['source']
    assert chain['clock_service'] == ring['clock_service'] == 'inactive'
    left, right = chain['processes'][0], ring['processes'][0]
    assert left['argv'] == right['argv']
    differences = {key: [left['atlas_env'].get(key), right['atlas_env'].get(key)]
                   for key in left['atlas_env'].keys() | right['atlas_env'].keys()
                   if left['atlas_env'].get(key) != right['atlas_env'].get(key)}
    assert set(differences) <= expected, differences
    assert left['atlas_env']['ATLAS_GLM_PC_WRITE_FLOOR'] == right['atlas_env']['ATLAS_GLM_PC_WRITE_FLOOR'] == '1'
    config_diff.append({'host': chain['host'], 'differences': differences})
rows = {}
for case in ('prose', 'code', 'structured'):
    chain, ring = (results[top]['decode'][case] for top in ('chain', 'ring'))
    repetitions = []
    for a, b in zip(chain['runs'], ring['runs']):
        assert a['run'] == b['run'] and a['finish_reason'] == b['finish_reason'] == 'stop'
        exact = all(a[key] == b[key] for key in ('output_sha256', 'reasoning_sha256',
                      'stream_sha256', 'output_characters', 'reasoning_characters', 'completion_tokens'))
        repetitions.append({'run': a['run'], 'chain_tps': a['decode_tokens_per_second'],
                            'ring_tps': b['decode_tokens_per_second'], 'exact_outputs': exact,
                            'chain_tokens': a['completion_tokens'], 'ring_tokens': b['completion_tokens']})
    c, r = chain['decode_tokens_per_second']['median'], ring['decode_tokens_per_second']['median']
    rows[case] = {'chain_median_tps': c, 'ring_median_tps': r,
                  'ring_change_percent': (r / c - 1) * 100, 'repetitions': repetitions}
out = {'passed': all(r['exact_outputs'] for row in rows.values() for r in row['repetitions']),
       'scope': 'Two repetitions per prompt; uncapped clock service; same image, model, requests, and argv. Topology and its cache namespaces differ. Not a statistical significance claim.',
       'rows': rows, 'configuration_differences': config_diff,
       'source_files': {top: 'results/' + arm + '/speed.json' for top, arm in names.items()}}
save('topology-performance.json', out)
print(json.dumps(out['rows'], indent=2))
assert out['passed'], 'Chain/ring output mismatch; inspect before accepting comparison'
