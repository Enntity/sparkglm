
import argparse,json,sys
from pathlib import Path
sys.path.insert(0,"/home/enntitysparkadmin/glm-unified-rc-20261021/validation")
from nvme_probe import Probe
old=Path.cwd()/"nvme-probe"
d=json.loads((old/"result.json").read_text()); prompt=(old/"target-prompt.txt").read_text(); plan=d['requests'][0]['prompt_plan']
a=argparse.Namespace(url='http://127.0.0.1:8893',out=Path.cwd()/'nvme-warm-control',blocks=2048,timeout=600,ssh_suffix='-fab')
p=Probe(a);p.startup()
for label,serial in [('warm-native-1',False),('warm-serial-1',True),('warm-native-2',False),('warm-serial-2',True)]:
 r=p.request(label,prompt,plan,serial=serial)
 print(label,len(r['token_ids']),r['content'],flush=True)
p.record['passed']=True;p.save()
