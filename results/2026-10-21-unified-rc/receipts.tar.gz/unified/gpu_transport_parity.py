# SPDX-License-Identifier: AGPL-3.0-only
import ast, hashlib, io, tarfile
from ops import *
engine=ROOT.parent/'glm-native-mtp-20261020/engine'
files=[
'crates/spark-comm/src/nccl_backend/rdma_pair/oneshot.rs',
'crates/spark-comm/src/nccl_backend/rdma_pair/oneshot_tests.rs',
'crates/spark-comm/src/nccl_backend/rdma_pair/oneshot/relay.rs',
'crates/spark-comm/src/nccl_backend/rdma_pair/oneshot/relay/forward.rs',
'crates/spark-comm/src/nccl_backend/rdma_pair/chain/bootstrap.rs',
'kernels/gb10/common/rdma_oneshot.cu']
archive=io.BytesIO()
with tarfile.open(fileobj=archive,mode='w') as tar:
 for f in files: tar.add(engine/f,arcname=f)
save('transport-parity-source-hashes.json',{f:hashlib.sha256((engine/f).read_bytes()).hexdigest() for f in files})
source=ast.parse((ROOT/'gpu_transport.py').read_text())
cmd=next(ast.literal_eval(n.value) for n in source.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cmd' for t in n.targets))
compile_script='''
# Reproduce the original production module before changing any source. The
# flags are build_target.rs plus common/model KERNEL.toml and gb10 arch.
original=$(find /build/target/release/build -name t0__rdma_oneshot.ptx -print -quit)
nvcc --ptx -arch=sm_121f -O3 --fmad=false -DTQ_PLUS_SIGNS --expt-relaxed-constexpr --Werror all-warnings /build/kernels/gb10/common/rdma_oneshot.cu -o /tmp/original-rdma.ptx
cmp "$original" /tmp/original-rdma.ptx
printf 'Original production PTX reproduced byte-for-byte: '
sha256sum /tmp/original-rdma.ptx
# Apply only the reviewed parity fix from the local source archive.
tar -xf - -C /build
nvcc --ptx -arch=sm_121f -O3 --fmad=false -DTQ_PLUS_SIGNS --expt-relaxed-constexpr --Werror all-warnings /build/kernels/gb10/common/rdma_oneshot.cu -o /tmp/parity-rdma.ptx
printf 'Fixed production PTX: '
sha256sum /tmp/parity-rdma.ptx
'''
cmd=cmd.replace('cd /build\n','cd /build\n'+compile_script)
cmd=cmd.replace('sha256sum "$ATLAS_ONESHOT_CUBIN_DIR/"*','cp /tmp/parity-rdma.ptx "$ATLAS_ONESHOT_CUBIN_DIR/rdma_oneshot.cubin"\nsha256sum "$ATLAS_ONESHOT_CUBIN_DIR/"*\ncargo test --locked --release -j 4 -p spark-comm --lib chain_completion_words_follow_payload_parity -- --nocapture')
cmd=cmd.replace(' export ATLAS_RDMA_TOPOLOGY=$topology',' printf "\\nTOPOLOGY=%s\\n" "$topology"\n export ATLAS_RDMA_TOPOLOGY=$topology')
(ROOT/'gpu-transport-parity-command.sh').write_text(cmd)
args=['docker','run','--rm','-i','--name','glm-parity-gpu-tests','--gpus','all','--network','host','--ipc','host','--memory','12g','--ulimit','memlock=-1:-1','--device','/dev/infiniband','-e','LD_LIBRARY_PATH=/usr/local/cuda/lib64:/lib/aarch64-linux-gnu','-e','ATLAS_PDL=1','--entrypoint','/bin/bash','localhost/atlas-glm-unified-builder:e611459b2621']
started=time.time()
with (ROOT/'transport-gpu-parity-tests.log').open('wb') as log:r=ssh('ennspark01',args+['-lc',cmd],data=archive.getvalue(),stdout=log,stderr=subprocess.STDOUT,timeout=900,check=False)
save('transport-gpu-parity-tests-exit.json',{'code':r.returncode,'started':started,'ended':time.time()})
print('GPU parity tests exit',r.returncode)
assert r.returncode==0
