# TP4 token-sharded NVMe prefix tier

The pair-only limitation was host geometry, not a missing storage backend. The existing record lanes, physical-block allocator, fast pitched I/O, per-rank prefix restore, and all-rank match/depth agreements already use the shard world. This port retains those paths and the current record format.

## Changes

- `NvmeGeometry` carries its actual class count. A row costs `own + (world - 1) * peer`, and staging accounts for every lane. Pre-allocation sizing receives the actual shard world; post-allocation sizing derives it from the cache.
- Sizing rejects invalid class/record combinations. Attach requires the exact cache geometry and the actual latent-shard owner. Sharded startup fingerprints include class count and separate own/peer record sizes, so equal aggregate byte counts cannot hide different layouts.
- Removed the TP2-only NVMe refusal. The independent TP4 overlap refusal remains.
- Disk LRU can reclaim an on-disk tail up to `world - 1` edges above the leaves. Every descendant must be on disk and unpinned; all dropped records are counted. Previously it considered leaves or parents of leaves only, so a TP4 class could discard a newer prefix despite a colder reclaimable tail.
- TP2 record bytes, file placement, budgets, and I/O remain unchanged. Its sharded startup fingerprint is intentionally stronger. Unsharded fingerprint and format remain unchanged. Files are process-local and unlinked, so no persistent migration is needed.

For the existing GLM record sizes, TP4 uses 106,496 + 3 × 12,288 = 143,360 bytes per four-class row. Fast staging is 128 × 143,360 = 18,350,080 bytes. The disk budget buys `floor(budget / 143,360)` slots per class. This is capacity accounting, not a throughput measurement.

## Test evidence

`nvme-red.log`: before production edits, the new TP4 geometry test failed with two classes instead of four; the full-class eviction test failed to spill the newer class-0 prefix. The new all-four-lane byte/fault test already passed, confirming the lower storage path supported TP4.

`nvme-runtime-green.log`: after the port, 64 NVMe runtime tests passed, zero failed, one existing disk microbenchmark ignored (0.08 seconds). This includes all four ranks on sync/fast paths, every logical bad-tag boundary, exact bytes/residues, existing TP2 round trips, pinned TP4 tails, and a branched six-record tail. This local CPU-only command used `--cap-lints=warn` because the existing no-CUDA build leaves `host_sync_trace::traced` unused under deny(warnings).

Final additions awaiting the parent's normal Linux/CUDA builder run: four-class kept-record invalidation, factory exact-owner/layout rejection, all-rank factory real-file attachments, model KEEP/re-restore and common-prefix cap, and the new real CUDA/file test. Mac model no-default test compilation is unsupported by existing unconditional CUDA test imports; the subsequent normal-feature check was interrupted by ENOSPC. No model-test pass is claimed from either attempt. Root removed only reproducible local target outputs and moved remaining validation to its cached Linux builder.

Pinned `cargo fmt --all` and `git diff --check` pass on the final source. No local compilation restarted after ENOSPC. No hardware, reservation, route, clock, model, or profile changes were made by this storage subtask. No commits made.

## Exact validation commands

In the normal cached Linux/CUDA build environment (preserve production build flags):

```sh
cargo test -p spark-runtime --lib nvme
cargo test -p spark-model --lib kv_nvme
```

No ignored CPU tests are needed. The existing ignored `nvme_disk_bench` is a larger disk benchmark with MockGpuBackend, not real CUDA DMA.

For the new actual-device check, on the reserved GPU01 after stopping the model, mount an existing NVMe-backed directory and run:

```sh
ATLAS_NVME_TEST_DIR=/nvme cargo test -p spark-runtime --lib tp4_nvme_device_file_round_trip -- --ignored --nocapture
```

This loads no model or PTX and uses one device to exercise each of the four rank geometries independently, with 32-block pools, two layers, all four residues, sync/fast O_DIRECT files, byte-exact restoration, rotated targets within residue, and a bad class-3 tag stopping the verified prefix at three blocks. It prints each case and total checked bytes, unlinks its files, and removes its unique directory. This proves actual DMA/layout and disk I/O; it does not replace all-rank model prefix-cache qualification. The parent will run the final TP4 native+NVMe serving configuration and carry forward prior numerical evidence rather than rerun the full benchmark suite.

## Owned changed files

Engine-relative paths:

1. `crates/spark-runtime/src/kv_cache/nvme_lanes.rs`
2. `crates/spark-runtime/src/kv_cache/nvme_spill.rs`
3. `crates/spark-runtime/src/radix_tree/inner/nvme.rs`
4. `crates/spark-model/src/factory/build.rs`
5. `crates/spark-model/src/factory/build/glm.rs`
6. `crates/spark-model/src/factory/build/kv_nvme.rs`
7. `crates/spark-runtime/src/kv_cache/tests/nvme_shard.rs`
8. `crates/spark-runtime/src/kv_cache/tests/nvme_shard_gpu.rs` (new)
9. `crates/spark-runtime/src/radix_tree/tests/nvme_classes.rs`
10. `crates/spark-model/src/factory/build/kv_nvme_shard_tests.rs`
11. `crates/spark-model/src/model/kv_nvme_shard_tests.rs`
12. `docs/glm-kv-shard.md`
13. `docs/glm-nvme-prefix-cache.md`

Independent read-only reviewer: `/root/tp4_topology`; no production blocker reported as of final source handoff. Final CUDA/file-test review is pending.
