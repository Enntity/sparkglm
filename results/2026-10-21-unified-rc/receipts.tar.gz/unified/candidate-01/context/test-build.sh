#!/bin/bash
set -euo pipefail
cargo test --locked --release -j 4 -p spark-comm --lib chain:: -- --nocapture
cargo test --locked --release -j 4 -p spark-comm --lib oneshot::relay -- --nocapture
cargo test --locked --release -j 4 -p spark-model --lib glm_sparse_native -- --nocapture
cargo test --locked --release -j 4 -p spark-model --lib glm_native -- --nocapture
cargo test --locked --release -j 4 -p spark-model --lib native_target_prerequisites -- --nocapture
cargo test --locked --release -j 4 -p spark-model --lib weight_loader::glm5::mtp -- --nocapture
cargo test --locked --release -j 4 -p spark-model --lib native_mtp_prefix::admission -- --nocapture
cargo test --locked --release -j 4 -p spark-model --lib glm5_mtp -- --nocapture
cargo test --locked --release -j 4 -p spark-server --bin spark glm_chain -- --nocapture
cargo test --locked --release -j 4 -p spark-server --bin spark preflight::independent::tests::long_context -- --nocapture
cargo test --locked --release -j 4 -p spark-server --bin spark scheduler::admission -- --nocapture
cargo test --locked --release -j 4 -p spark-model --lib glm_mla_fuse --no-run
cargo build --locked --release -j 4 -p spark-server
