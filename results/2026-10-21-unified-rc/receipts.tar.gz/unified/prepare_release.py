# SPDX-License-Identifier: AGPL-3.0-only
"""Prepare reviewable release receipts; omit machine configs and credentials."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

ROOT = Path(__file__).resolve().parent
PRODUCT = ROOT.parent / 'glm-native-mtp-20261020/product'
DEST = PRODUCT / 'results/2026-10-21-unified-rc'
qualification = json.loads((ROOT / 'qualification.json').read_text())
assert qualification['passed'] is True
assert not DEST.exists(), 'Preserve any existing release; inspect before replacing it'
DEST.mkdir()

for source, name in [('RELEASE.md', 'RESULT.md'), ('qualification.json', 'qualification.json'),
                     ('final-image.json', 'final-image.json'), ('image-host-identity.json', 'image-host-identity.json')]:
    shutil.copy2(ROOT / source, DEST / name)

def add(archive, path, name):
    if path.name.endswith('-identity.json') and path.parent.name.startswith(('tp2-', 'tp4-')):
        # Full Docker inspect remains in work/. Public receipts retain only
        # source/binary/configuration, clocks and memory proof.
        data = json.loads(path.read_text())
        data.pop('inspect', None)
        payload = (json.dumps(data, indent=2) + '\n').encode()
        info = tarfile.TarInfo(name)
        info.size = len(payload)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(payload))
    else:
        archive.add(path, arcname=name, recursive=False)

exact = {
    'build-plan.json', 'final-build-validation.json', 'final-transport-ptx.json',
    'final-policy-review.md', 'strict-tp4-split-control.json', 'parity-source-identity.json',
    'transport-parity-source-hashes.json', 'nvme-gpu-exit.json', 'nvme-gpu-filesystem.json',
    'stub-initialization-nvme-gpu-exit.json', 'builder-build-exit.json', 'runtime-build-exit.json',
    'transport-gpu-parity-tests-exit.json', 'transport-gpu-profile-tests-exit.json',
    'transport-gpu-tests-exit.json', 'gpu-tests-exit.json', 'topology.md', 'topology-review.md',
    'attention.md', 'attention-plan.md', 'native-mtp.md', 'native-review.md',
    'nvme-tp4.md', 'nvme-port-review.md', 'tp4-nvme-pressure.json', 'tp4-strict-unsplit.json',
    'topology-performance.json', 'restoration-verdict.json',
    'strict-native-speed-comparison.json', 'nvme-causal-comparison.json',
    'nvme-replay-storage-audit.md', 'write-floor-review.md', 'final-static.json',
    'image-content-proof.json', 'restoration-pair.json', 'restoration-drafter-0304.json',
    'cases.json', 'prompts.json', 'shared-baseline.json', 'rc4-baseline.json',
    'presence-route-restoration-proof.json', 'tp4-nvme-write-floor.json',
}
with tarfile.open(DEST / 'receipts.tar.gz', 'w:gz', compresslevel=6) as archive:
    for path in sorted(ROOT.iterdir()):
        if path.is_file() and (path.name in exact or path.suffix in ('.log', '.py', '.sh', '.rs')):
            add(archive, path, 'unified/' + path.name)
        if path.is_dir() and (path.name == 'results' or path.name.startswith(('tp2-', 'tp4-'))):
            for child in sorted(path.rglob('*')):
                if child.is_file():
                    add(archive, child, 'unified/' + str(child.relative_to(ROOT)))
    for path in sorted((ROOT / 'topology-harness').rglob('*')):
        if path.is_file() and 'target' not in path.parts and path.suffix in ('.rs', '.toml', '.lock'):
            add(archive, path, 'unified/' + str(path.relative_to(ROOT)))
    for directory in ('oracle', 'candidate-01', 'candidate-02', 'candidate-03'):
        for path in sorted((ROOT / directory).rglob('*')):
            if not path.is_file() or 'before' in path.name or '__pycache__' in path.parts:
                continue
            if directory == 'oracle' or path.name in ('final-image.json', 'image-host-identity.json', 'build-plan.json', 'source-hashes.json', 'Dockerfile', 'test-build.sh') or path.suffix == '.log':
                add(archive, path, 'unified/' + str(path.relative_to(ROOT)))
    prior = ROOT.parent.parent / 'outputs/glm-focused-fixes-20261020'
    for path in sorted(prior.iterdir()):
        if path.is_file():
            add(archive, path, 'prior-tp2/' + path.name)

rows = [hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.name
        for p in sorted(DEST.iterdir()) if p.is_file()]
(DEST / 'SHA256SUMS').write_text('\n'.join(rows) + '\n')
print(DEST)
