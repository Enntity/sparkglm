# SPDX-License-Identifier: AGPL-3.0-only
"""Scoped transport and receipts for the unified RC; never print credentials."""
import json
from pathlib import Path
import shlex
import subprocess
import time

ROOT = Path(__file__).resolve().parent
OWNER = 'codex-glm-unified'
SESSION = 'codex:01a155d5-fe97-7172-b9fe-b437d6b62cf3'
HOSTS = ['ennspark01', 'ennspark02', 'ennspark03', 'ennspark04']
STAGE = '/home/enntitysparkadmin/glm-unified-rc-20261021'


def save(name, value):
    p = ROOT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, indent=2) + '\n')


def ssh(host, args, data=None, check=True, timeout=900, **kwargs):
    result = subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ServerAliveInterval=15',
                             host, shlex.join(list(map(str, args)))], input=data,
                            timeout=timeout, **({'capture_output': True} if not kwargs else kwargs))
    if check and result.returncode:
        detail = ((result.stdout or b'') + (result.stderr or b''))[-2500:]
        raise RuntimeError(f'{host} {args[:3]} exit {result.returncode}: {detail!r}')
    return result


def cli(args, label, host='ennspark01'):
    started = time.time()
    r = ssh(host, ['env', 'LLOOM_OWNER=' + OWNER, 'LLOOM_SESSION=' + SESSION,
                   'lloom', *args, '--json'], check=False)
    p = ROOT / 'operations' / label
    p.mkdir(parents=True, exist_ok=True)
    (p / 'stdout.json').write_bytes(r.stdout)
    (p / 'stderr.txt').write_bytes(r.stderr)
    save('operations/' + label + '/receipt.json',
         {'host': host, 'argv': args, 'started': started, 'ended': time.time(), 'code': r.returncode})
    if r.returncode:
        raise RuntimeError(f'LLooM {label}: {(r.stdout + r.stderr)[-1800:]!r}')
    return json.loads(r.stdout)


def note(message):
    job = json.loads((ROOT / 'job.json').read_text())['id']
    return cli(['job', 'note', job, message], 'note-' + str(time.time_ns()))


def renew():
    for resource in ('pair', 'drafter-0304'):
        p = ROOT / ('lease-' + resource + '.json')
        if p.exists() and not (ROOT / ('released-' + resource + '.json')).exists():
            cli(['renew', resource], 'renew-' + resource + '-' + str(time.time_ns()))
