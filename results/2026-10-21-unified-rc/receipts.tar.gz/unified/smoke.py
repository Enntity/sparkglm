# SPDX-License-Identifier: AGPL-3.0-only
"""Bounded TP2/TP4 serving smoke; run in a fresh receipt directory.

Provenance: lifecycle/probe.py from glm-tp2-rc-validation-20261020.
Strict assumes native MTP enabled on the server. Spark expects cases.json,
grader.py and check_code.py beside this script (or --cases-dir). No timings
here qualify throughput; prefix checks exercise warm COW, not disk eviction.
"""
import argparse
import concurrent.futures as cf
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import threading
import time
import urllib.error
import urllib.request

BASE = {
    'model': 'glm-5.3-flash-atlas', 'temperature': 0, 'top_k': 1,
    'top_p': 1, 'min_p': 0, 'repetition_penalty': 1,
    'chat_template_kwargs': {'enable_thinking': False, 'reasoning_effort': 'low'},
    'stream': True, 'stream_options': {'include_usage': True}, 'return_token_ids': True,
}
PROSE = 'Write a calm, detailed explanation of how a lighthouse lens works, including practical examples.'
ARITHMETIC = "Compute 2123 * 49 - 7256 * 67 + 595 exactly, showing brief steps. Give the final answer on the last line as 'Answer: <number>'."


def accepted(row):
    return row.get('usage', {}).get('completion_tokens_details', {}).get('accepted_prediction_tokens', 0)


def cached(row):
    return row.get('usage', {}).get('prompt_tokens_details', {}).get('cached_tokens', 0)


class Smoke:
    def __init__(self, args):
        self.args = args
        self.out = Path.cwd() / 'smoke.json'
        if self.out.exists():
            raise FileExistsError(f'{self.out} exists; use a fresh receipt directory')
        self.lock = threading.Lock()
        self.record = {'schema': 'sparkglm.unified-smoke/v1', 'mode': args.mode,
                       'url': args.url, 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                       'started_unix': time.time(), 'requests': [], 'checks': [], 'passed': False,
                       'scope': 'Focused serving smoke; warm prefix COW only; no throughput or capacity qualification.'}

    def save(self):
        with self.lock:
            self.out.write_text(json.dumps(self.record, indent=2, allow_nan=False) + '\n')

    def check(self, name, passed, **detail):
        self.record['checks'].append({'name': name, 'passed': bool(passed), **detail})
        self.save()
        if not passed:
            raise AssertionError(name)
        print('PASS', name, flush=True)

    def get(self, path):
        with urllib.request.urlopen(self.args.url + path, timeout=30) as response:
            return response.read().decode()

    def tokenize(self, prompt):
        req = urllib.request.Request(self.args.url + '/tokenize',
                                     json.dumps({'prompt': prompt}).encode(), {'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=60) as response:
            return json.load(response)['count']

    def request(self, label, prompt, budget=96, serial=False, extra=None, barrier=None, cancel=False):
        body = dict(BASE, messages=[{'role': 'user', 'content': prompt}],
                    max_tokens=budget, disable_mtp=serial)
        body.update(extra or {})
        row = {'label': label, 'request': body, 'events': [], 'token_ids': [],
               'content': '', 'reasoning_content': '', 'tools': {}, 'logprobs': []}
        try:
            req = urllib.request.Request(self.args.url + '/v1/chat/completions',
                                         json.dumps(body).encode(), {'Content-Type': 'application/json'})
            if barrier:
                barrier.wait(timeout=30)
            row['started'] = time.monotonic()
            first = None
            with urllib.request.urlopen(req, timeout=self.args.timeout) as response:
                for raw in response:
                    if not raw.startswith(b'data:'):
                        continue
                    data = raw[5:].strip()
                    if data == b'[DONE]':
                        row['done'] = True
                        break
                    event = json.loads(data)
                    row['events'].append(event)
                    if event.get('error'):
                        raise AssertionError(event['error'])
                    if event.get('usage'):
                        row['usage'] = event['usage']
                    for choice in event.get('choices', []):
                        delta = choice.get('delta') or {}
                        ids = choice.get('token_ids') or delta.get('token_ids') or []
                        row['token_ids'].extend(ids)
                        for key in ('content', 'reasoning_content'):
                            row[key] += delta.get(key) or ''
                        if choice.get('logprobs'):
                            row['logprobs'].append(choice['logprobs'])
                        for tool in delta.get('tool_calls') or []:
                            target = row['tools'].setdefault(str(tool.get('index', 0)),
                                                            {'id': '', 'name': '', 'arguments': ''})
                            if tool.get('id'):
                                target['id'] = tool['id']
                            function = tool.get('function') or {}
                            target['name'] += function.get('name') or ''
                            target['arguments'] += function.get('arguments') or ''
                        if (ids or delta.get('content') or delta.get('tool_calls')) and first is None:
                            first = time.monotonic()
                        if choice.get('finish_reason'):
                            row['finish_reason'] = choice['finish_reason']
                    if cancel and row['token_ids']:
                        row['cancelled_after_tokens'] = len(row['token_ids'])
                        break
            row['ttft_seconds'] = None if first is None else first - row['started']
            if cancel:
                assert row.get('cancelled_after_tokens'), 'Cancellation did not interrupt generated tokens'
            else:
                assert row['token_ids'], 'Missing streamed token IDs'
                assert row.get('finish_reason') in ('stop', 'length', 'tool_calls'), 'Missing final finish reason'
                assert row.get('usage'), 'Missing final usage'
                if serial:
                    assert accepted(row) == 0, 'disable_mtp control accepted draft tokens'
        except BaseException as error:
            row['error'] = repr(error)
            if isinstance(error, urllib.error.HTTPError):
                row['error_body'] = error.read().decode(errors='replace')
            raise
        finally:
            row['ended'] = time.monotonic()
            row['elapsed_seconds'] = row['ended'] - row.get('started', row['ended'])
            with self.lock:
                self.record['requests'].append(row)
            self.save()
        return row

    def group(self, label, prompts, budget=96, serial=False):
        barrier = threading.Barrier(4)
        with cf.ThreadPoolExecutor(4) as pool:
            futures = [pool.submit(self.request, f'{label}-{i}', p, budget, serial, barrier=barrier)
                       for i, p in enumerate(prompts)]
            rows = [f.result() for f in futures]
        overlap = max(r['started'] for r in rows) < min(r['ended'] for r in rows)
        self.check(label + '-overlap', overlap)
        return rows

    def exact(self, name, controls, native):
        comparisons = [{'serial': a['label'], 'native': b['label'],
                        'exact_ids': a['token_ids'] == b['token_ids']} for a, b in zip(controls, native)]
        self.check(name, len(controls) == len(native) and all(x['exact_ids'] for x in comparisons), comparisons=comparisons)

    def prefix_and_reuse(self):
        unit = 'A water clock measures time by steady water flowing into a marked container.\n'
        prefix = 'Read these reference notes.\n' + unit * (12000 // self.tokenize(unit) + 1)
        seed = self.request('prefix-seed', prefix + '\nExplain the mechanism in detail.', 96)
        self.record['prefix_raw_tokens'] = self.tokenize(prefix)
        prompts = [prefix + '\n' + suffix for suffix in (
            'Explain the mechanism using a numbered example.',
            'Explain the maintenance needed, with examples.',
            'Explain the limits of precision, with examples.',
            'Explain how temperature changes the result, with examples.')]
        controls = self.group('prefix-serial', prompts, 64, True) if self.args.mode == 'strict' else None
        rows = self.group('prefix-c4', prompts, 64)
        self.check('prefix-c4-cache-hits', all(cached(r) > 0 for r in rows),
                   cached_tokens=[cached(r) for r in rows])
        self.check('prefix-c4-speculation-exercised', sum(accepted(r) for r in rows) > 0,
                   accepted=[accepted(r) for r in rows])
        if controls:
            self.exact('prefix-c4-native-vs-serial', controls, rows)
        self.request('cancel-prefix', prefix + '\nWrite a very long history of water clocks.', 512, cancel=True)
        prompts = [f'What is {20+i} + 5? Reply with only the integer.' for i in range(4)]
        reused = self.group('reuse-c4', prompts, 32)
        self.check('cancel-slot-reuse-quality', all(r['content'].strip() == str(25+i) for i, r in enumerate(reused)))
        controls = self.group('reuse-serial', prompts, 32, True) if self.args.mode == 'strict' else None
        if controls:
            self.exact('cancel-slot-reuse-native-vs-serial', controls, reused)
        return seed

    def arithmetic(self):
        prompts = [ARITHMETIC] * 4
        controls = self.group('arithmetic-serial', prompts, 384, True) if self.args.mode == 'strict' else None
        rows = self.group('arithmetic-c4', prompts, 384)
        def correct(row):
            answer = re.search(r'Answer:\s*([−-]?\d[\d,]*)\s*$', row['content'], re.I)
            return (row.get('finish_reason') == 'stop' and answer is not None and
                    answer[1].replace('−', '-').replace(',', '') == '-381530')
        self.check('arithmetic-c4-minus381530', all(correct(r) for r in rows + (controls or [])), expected=-381530)
        if controls:
            self.exact('arithmetic-c4-native-vs-serial', controls, rows)

    def json_and_tool(self):
        schema = {'type': 'json_schema', 'json_schema': {'name': 'sum', 'strict': True,
                  'schema': {'type': 'object', 'properties': {'sum': {'type': 'integer'}},
                             'required': ['sum'], 'additionalProperties': False}}}
        row = self.request('constrained-json', 'What is 17 + 25? Return the requested JSON object.', 64,
                           extra={'response_format': schema})
        self.check('constrained-json-quality', row['finish_reason'] == 'stop' and json.loads(row['content']) == {'sum': 42})
        tools = [{'type': 'function', 'function': {'name': 'get_weather',
                  'description': 'Get the current weather in a city.',
                  'parameters': {'type': 'object', 'properties': {'city': {'type': 'string'}},
                                 'required': ['city'], 'additionalProperties': False}}}]
        row = self.request('normal-tool', 'Use get_weather to look up the current weather in Paris.', 128,
                           extra={'tools': tools, 'tool_choice': 'auto'})
        calls = list(row['tools'].values())
        self.check('normal-tool-quality', row['finish_reason'] == 'tool_calls' and len(calls) == 1
                   and calls[0]['name'] == 'get_weather' and json.loads(calls[0]['arguments']) == {'city': 'Paris'}, calls=calls)

    def sampled(self):
        before = self.get('/metrics')
        # This server attaches chat logprobs to blocking responses. Streaming
        # token IDs are tested separately; blocking chat need not expose IDs.
        body = dict(BASE, messages=[{'role': 'user', 'content': PROSE}], max_tokens=128,
                    disable_mtp=False, stream=False, temperature=0.7, top_k=0,
                    top_p=1, min_p=0, top_n_sigma=0, presence_penalty=0,
                    frequency_penalty=0, seed=913, logprobs=True, top_logprobs=3)
        body.pop('stream_options')
        row = {'label': 'sampled-full-vocabulary-logprobs', 'request': body, 'started': time.monotonic()}
        try:
            req = urllib.request.Request(self.args.url + '/v1/chat/completions',
                                         json.dumps(body).encode(), {'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=self.args.timeout) as response:
                row['response'] = json.load(response)
            choice = row['response']['choices'][0]
            row.update(content=choice['message'].get('content') or '',
                       logprobs=choice.get('logprobs'), usage=row['response'].get('usage', {}),
                       finish_reason=choice.get('finish_reason'))
            assert row['finish_reason'] in ('stop', 'length') and row['usage'], 'Incomplete sampled response'
        except BaseException as error:
            row['error'] = repr(error)
            if isinstance(error, urllib.error.HTTPError):
                row['error_body'] = error.read().decode(errors='replace')
            raise
        finally:
            row['ended'] = time.monotonic()
            row['elapsed_seconds'] = row['ended'] - row['started']
            self.record['requests'].append(row)
            self.save()
        after = self.get('/metrics')
        def drafts(text):
            vals = re.findall(r'^vllm:spec_decode_num_drafts_total(?:\{[^\n]*\})?\s+([0-9.eE+-]+)\s*$', text, re.M)
            assert vals, 'Missing draft counter'
            return sum(float(v) for v in vals)
        delta = drafts(after) - drafts(before)
        self.record['sampled_metrics'] = {'before': before, 'after': after, 'draft_delta': delta}
        values = []
        def collect(value):
            if isinstance(value, dict):
                for key, child in value.items():
                    if key == 'logprob':
                        values.append(child)
                    else:
                        collect(child)
            elif isinstance(value, list):
                for child in value:
                    collect(child)
        collect(row['logprobs'])
        self.check('sampled-finite-logprobs', bool(values) and all(isinstance(v, (int, float)) and math.isfinite(v) for v in values), count=len(values))
        self.check('sampled-full-vocabulary-native-exercised', bool(row['content'].strip()) and delta > 0 and accepted(row) > 0,
                   draft_delta=delta, accepted=accepted(row), sampler={'temperature': .7, 'top_k': 0, 'top_p': 1, 'min_p': 0})

    def spark_cases(self):
        path = self.args.cases_dir
        cases = {c['id']: c for c in json.loads((path / 'cases.json').read_text())}
        spec = importlib.util.spec_from_file_location('smoke_grader', path / 'grader.py')
        grader = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(grader)
        for name in ('invoice', 'extract', 'merge', 'original-37-rows3000', 'original-57-rows4800'):
            case = cases[name]
            row = self.request(name, case['prompt'], 384 if case['grader'] == 'code' else 96)
            response = {'choices': [{'finish_reason': row['finish_reason'], 'message': {'content': row['content']}}]}
            grade = grader.grade(case, {'response': response})
            self.check('quality-' + name, grade['status'] == 'pass', grade=grade,
                       prompt_sha256=hashlib.sha256(case['prompt'].encode()).hexdigest(),
                       prompt_tokens=row['usage'].get('prompt_tokens'))

    def run(self):
        try:
            self.record['health'] = self.get('/health')
            if self.args.mode == 'strict':
                serial = self.request('c1-serial', PROSE, 96, True)
                native = self.request('c1-native', PROSE, 96)
                self.exact('c1-native-vs-serial', [serial], [native])
            else:
                self.request('spark-warmup', PROSE, 64)
            self.arithmetic()
            self.json_and_tool()
            self.prefix_and_reuse()
            if self.args.mode == 'strict':
                self.sampled()
            else:
                self.spark_cases()
            self.check('speculation-used', sum(accepted(r) for r in self.record['requests']) > 0)
            self.record['passed'] = True
        except BaseException as error:
            self.record['error'] = repr(error)
            raise
        finally:
            self.record['ended_unix'] = time.time()
            self.save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', required=True, choices=('strict', 'spark'))
    parser.add_argument('--url', default='http://127.0.0.1:8893')
    parser.add_argument('--timeout', type=float, default=600, help='Per-request socket timeout, seconds')
    parser.add_argument('--cases-dir', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    args.url = args.url.rstrip('/')
    Smoke(args).run()


if __name__ == '__main__':
    main()
