use anyhow::Result;
use std::collections::VecDeque;
use std::sync::{Arc, atomic::{AtomicUsize, Ordering}};

struct Write { src: usize, dst: usize, len: usize, flag: usize, flag_dst: usize, ticket: u64 }
pub struct Qp {
    posted: u64,
    completed: u64,
    pending: VecDeque<Write>,
    bytes: Arc<AtomicUsize>,
    delay_rs: bool, delayed_ticket: u64, delay_left: usize,
}
impl Qp {
    pub fn new(bytes: Arc<AtomicUsize>) -> Self { Self { posted: 0, completed: 0, pending: VecDeque::new(), bytes, delay_rs: false, delayed_ticket: 0, delay_left: 0 } }
    pub fn with_delayed_rs(mut self) -> Self { self.delay_rs = true; self }
    pub unsafe fn write_flag(&mut self, src: usize, dst: u64, len: usize, flag: usize, flag_dst: u64) -> Result<u64> {
        self.posted += 1;
        self.pending.push_back(Write {src, dst: dst as usize, len, flag, flag_dst: flag_dst as usize, ticket: self.posted});
        Ok(self.posted)
    }
    pub fn reap(&mut self) {
        if self.delay_rs {
            if let Some(w) = self.pending.front() {
                let code = unsafe { (w.flag as *const u64).read() } as usize & 0xff_ffff;
                if code & (1 << 23) != 0 && self.delayed_ticket != w.ticket {
                    self.delayed_ticket = w.ticket; self.delay_left = 100;
                }
                if self.delay_left > 0 { self.delay_left -= 1; return; }
            }
        }
        if let Some(w) = self.pending.pop_front() {
            unsafe {
                std::ptr::copy_nonoverlapping(w.src as *const u8, w.dst as *mut u8, w.len);
                (w.flag_dst as *mut u64).write((w.flag as *const u64).read());
            }
            self.bytes.fetch_add(w.len, Ordering::Relaxed);
            self.completed = w.ticket;
        }
    }
    pub fn wait(&mut self, ticket: u64) -> Result<()> {
        assert!(ticket <= self.posted, "ticket belongs to another QP");
        while !self.done(ticket) { self.reap(); }
        Ok(())
    }
    pub fn done(&self, ticket: u64) -> bool { self.completed >= ticket }
}
pub struct Link { pub qps: Vec<Qp>, pub base: u64 }
pub type Links = [Option<Link>; 2];
