#![allow(dead_code)]
mod nccl_backend {
    pub mod rdma_pair {
        #[path = "/Users/jmac/Documents/Codex/2026-10-19/cl/work/glm-native-mtp-20261020/engine/crates/spark-comm/src/nccl_backend/rdma_pair/topology.rs"]
        pub mod topology;
        #[path = "/Users/jmac/Documents/Codex/2026-10-19/cl/work/glm-native-mtp-20261020/engine/crates/spark-comm/src/nccl_backend/rdma_pair/bootstrap.rs"]
        pub mod bootstrap;
        #[path = "/Users/jmac/Documents/Codex/2026-10-19/cl/work/glm-unified-rc-20261021/topology-harness/src/oneshot.rs"]
        mod oneshot;
        pub mod chain {
            #[path = "/Users/jmac/Documents/Codex/2026-10-19/cl/work/glm-unified-rc-20261021/topology-harness/src/fake_link.rs"]
            pub mod link;
        }
    }
}
