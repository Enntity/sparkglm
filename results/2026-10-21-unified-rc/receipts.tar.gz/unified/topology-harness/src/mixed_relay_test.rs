use super::*;
use super::super::{chain::link::{Link, Links, Qp}, topology::Topology};
use std::sync::{Arc, atomic::AtomicUsize};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Kind { Flood, Rs, Fused }

fn input(seq: usize, origin: usize, offset: usize) -> u16 {
    let hash = (seq * 12347 + origin * 32771 + offset * 7919) as u32;
    (((hash >> 5) & 1) << 15 | ((121 + hash % 14) << 7) | (hash >> 12 & 127)) as u16
}
fn add(a: u16, b: u16) -> u16 {
    let sum = f32::from_bits((a as u32) << 16) + f32::from_bits((b as u32) << 16);
    let bits = sum.to_bits();
    (bits.wrapping_add(0x7fff + ((bits >> 16) & 1)) >> 16) as u16
}
fn expected(seq: usize, offset: usize) -> u16 {
    add(add(input(seq, 0, offset), input(seq, 1, offset)), add(input(seq, 2, offset), input(seq, 3, offset)))
}
fn flag(ctrl: usize, origin: usize, rank: usize, piece: usize, seq: usize) -> u64 {
    unsafe { (*(ctrl.wrapping_add(chain_flag_line(origin_slot(origin, rank), piece, seq as u64)) as *const AtomicU64)).load(Ordering::Acquire) }
}
fn published(ctrl: usize, origin: usize, rank: usize, piece: usize, seq: usize, code: usize) -> bool {
    let f = flag(ctrl, origin, rank, piece, seq);
    assert!(f >> 24 <= seq as u64 + 1, "origin {origin} raced rank {rank}: seq {seq}, flag {}", f >> 24);
    if f >> 24 == seq as u64 { assert_eq!(f & 0xff_ffff, code as u64); }
    f >> 24 >= seq as u64
}
fn receive(host: usize, rank: usize, origin: usize, seq: usize, kind: Kind, fused_at: usize, cap: usize, max: usize, bytes: usize, offset: usize) -> usize {
    if kind == Kind::Fused {
        let seg_bytes = bytes / 4;
        let seg = offset / seg_bytes;
        host + fused_at + (fused::nraw(rank) + fused::recv_index(rank, origin, seg)) * cap + offset % seg_bytes
    } else {
        host + recv_off(max, origin_slot(origin, rank), seq & 1) + offset
    }
}

fn exercise_mixed(topology: Topology, rails: usize, delayed: usize) {
    use Kind::*;
    let pattern = [Flood, Rs, Flood, Fused, Flood, Rs, Rs, Flood, Fused, Flood, Fused, Flood];
    let ops = pattern.len() * 4;
    let max = 1 << 20;
    let cap = 65536;
    let fused_at = region_bytes(max, 3).next_multiple_of(4096);
    let cfg = Config { max, stripe_min: 8192, timeout_ns: 0, stage_fence: false, sm_stage: 1, pdl: false, fused_seg: cap };
    let mut regions: Vec<Vec<u64>> = (0..4).map(|rank| vec![0; (fused_at + fused::entries(rank) * cap) / 8]).collect();
    let hosts: Vec<usize> = regions.iter_mut().map(|r| r.as_mut_ptr() as usize).collect();
    let traffic: Vec<Vec<Arc<AtomicUsize>>> = (0..4).map(|_| (0..4).map(|_| Arc::new(AtomicUsize::new(0))).collect()).collect();
    let mut links: Vec<Links> = (0..4).map(|rank| [0, 1].map(|side| topology.neighbor(rank, 4, side).map(|peer| Link {
        base: hosts[peer] as u64, qps: (0..rails).map(|_| { let qp = Qp::new(traffic[rank][peer].clone()); if rank == 1 && peer == 0 { qp.with_delayed_rs() } else { qp } }).collect(),
    }))).collect();
    let mut relays: Vec<_> = (0..4).map(|rank| relay::Relay::new(cfg, Shape { ranks: 4, rank, rails: [rails; 2] }, hosts[rank], 0)
        .with_topology(topology).with_fused(relay::RelayFused { host: hosts[rank] + fused_at, at: fused_at, cap })).collect();
    let mut completed = [0usize; 4];
    let mut staged = [false; 4];
    let mut produced = [0u64; 4];
    let mut reduced = [0u64; 4];
    let mut checked_words = 0usize;
    let mut missing_origin_checks = 0usize;
    let mut round = 0usize;
    while completed.iter().any(|&n| n < ops) {
        round += 1;
        assert!(round < 100_000, "stalled {topology:?} delayed{delayed}: completed={completed:?}, produced={produced:?}, reduced={reduced:?}");
        for rank in (0..4).map(|n| (n + round) % 4) {
            if rank == delayed && round % 7 != 0 { continue; }
            for link in links[rank].iter_mut().flatten() { for qp in &mut link.qps { qp.reap(); } }
            if completed[rank] < ops {
                let seq = completed[rank] + 1;
                let kind = pattern[(seq - 1) % pattern.len()];
                let bytes = match kind { Flood => [64, 8192, 131072][seq % 3], _ => [32768, 65536, 131072, 262144][seq % 4] };
                let code = match kind { Flood => bytes, Rs => bytes | RS_BIT, Fused => fused::code(bytes) };
                let parts = if kind == Flood { pieces(bytes, cfg.stripe_min) } else { rs_wire_pieces(code) };
                let k = if kind == Flood { parts.len() } else { rs_per_segment(bytes) };
                let ctrl = hosts[rank] + ctrl_off(max, 3);
                let near = [1, 0, 3, 2][rank];
                let far = if rank < 2 { 2 } else { 1 };
                let role = relay::rs_role(rank);
                if !staged[rank] {
                    assert_eq!(unsafe { (*(ctrl as *const AtomicU32)).load(Ordering::Acquire) }, 0);
                    unsafe { (*(ctrl as *const AtomicU32)).store((code | PIPE_BIT) as u32, Ordering::Release); }
                    produced[rank] = 0;
                    reduced[rank] = 0;
                    staged[rank] = true;
                }
                let raw: Vec<usize> = if kind == Flood { (0..parts.len()).collect() } else { relay::rs_segment_pieces(role.raw.1, k).collect() };
                let computed: Vec<usize> = if kind == Flood { vec![] } else { role.computed.map_or_else(Vec::new, |(_, segs)| relay::rs_segment_pieces(segs, k).collect()) };
                // Model a producer publishing only one raw/computed piece each tick.
                let next = raw.iter().copied().find(|&p| produced[rank] & 1 << p == 0)
                    .map(|p| (p, false)).or_else(|| computed.iter().copied().find(|&p| produced[rank] & 1 << p == 0 && published(ctrl, near, rank, p, seq, code)).map(|p| (p, true)));
                if let Some((p, compute)) = next {
                    let (offset, len) = parts[p];
                    let seg = p / k;
                    let dest = if kind == Fused {
                        let entry = if compute { fused::nraw(rank) + fused::recv_index(rank, near, seg) } else { fused::raw_index(rank, seg) };
                        hosts[rank] + fused_at + entry * cap + (p % k) * len
                    } else { hosts[rank] + offset };
                    for j in (0..len).step_by(2) {
                        let mine = input(seq, rank, offset + j);
                        let value = if compute {
                            let ptr = receive(hosts[rank], rank, near, seq, kind, fused_at, cap, max, bytes, offset+j);
                            let other = unsafe { (ptr as *const u16).read() };
                            assert_eq!(other, input(seq, near, offset+j), "computed input {topology:?} {kind:?} seq{seq} rank{rank} near{near} byte{}", offset+j);
                            if rank < near { add(mine, other) } else { add(other, mine) }
                        } else { mine };
                        unsafe { ((dest+j) as *mut u16).write(value); }
                    }
                    unsafe { (*(ctrl.wrapping_add(READY + 8 * p) as *const AtomicU64)).store(seq as u64, Ordering::Release); }
                    produced[rank] |= 1 << p;
                }
                if kind == Flood {
                    for p in 0..parts.len() {
                        if reduced[rank] & 1 << p != 0 || !(0..4).filter(|&o| o != rank).all(|o| published(ctrl, o, rank, p, seq, code)) { continue; }
                        let (offset, len) = parts[p];
                        for at in (offset..offset+len).step_by(2) {
                            let mut values = [0u16; 4];
                            for origin in 0..4 {
                                values[origin] = if origin == rank { input(seq, rank, at) } else {
                                    let ptr = receive(hosts[rank], rank, origin, seq, kind, fused_at, cap, max, bytes, at);
                                    unsafe { (ptr as *const u16).read() }
                                };
                                assert_eq!(values[origin], input(seq, origin, at), "flood {topology:?} seq{seq} rank{rank} origin{origin} byte{at}");
                            }
                            assert_eq!(add(add(values[0],values[1]), add(values[2],values[3])), expected(seq, at));
                            checked_words += 1;
                        }
                        reduced[rank] |= 1 << p;
                    }
                } else {
                    for p in rank*k..(rank+1)*k {
                        if reduced[rank] & 1 << (p % k) != 0 || !published(ctrl, near, rank, p, seq, code) || !published(ctrl, far, rank, p, seq, code) { continue; }
                        let (offset, len) = parts[p];
                        for at in (offset..offset+len).step_by(2) {
                            let n = receive(hosts[rank], rank, near, seq, kind, fused_at, cap, max, bytes, at);
                            let f = receive(hosts[rank], rank, far, seq, kind, fused_at, cap, max, bytes, at);
                            let (n, f) = unsafe { ((n as *const u16).read(), (f as *const u16).read()) };
                            assert_eq!(n, input(seq, near, at), "near {topology:?} {kind:?} seq{seq} rank{rank} byte{at}");
                            let pair = if rank < near { add(input(seq, rank, at), n) } else { add(n, input(seq, rank, at)) };
                            let sum = if rank < 2 { add(pair, f) } else { add(f, pair) };
                            assert_eq!(sum, expected(seq, at), "sum {topology:?} {kind:?} seq{seq} rank{rank} byte{at}");
                            checked_words += 1;
                        }
                        reduced[rank] |= 1 << (p % k);
                    }
                }
                let drained = unsafe { (*(ctrl as *const AtomicU32)).load(Ordering::Acquire) == 0 };
                if reduced[rank] == (1u64 << k) - 1 && drained {
                    if kind != Flood {
                        let missing = if rank < 2 { 3 } else { 0 };
                        assert!((0..parts.len()).all(|p| flag(ctrl, missing, rank, p, seq) >> 24 != seq as u64), "unexpected missing-origin RS payload");
                        missing_origin_checks += 1;
                    }
                    completed[rank] += 1;
                    staged[rank] = false;
                }
            }
            relays[rank].serve(&mut links[rank]).unwrap();
        }
    }
    if topology == Topology::Ring {
        assert!(traffic[0][3].load(Ordering::Relaxed) > 0 && traffic[3][0].load(Ordering::Relaxed) > 0);
    }
    assert!(checked_words > 1_000_000 && missing_origin_checks > 50);
    println!("mixed {topology:?} {rails} rails delayed rank{delayed}: {ops} ops/rank, {checked_words} exact BF16 sums, {missing_origin_checks} absent-origin checks, {round} ticks");
}

#[test]
fn production_relay_mixed_flood_rs_fused_exact_sums_with_delayed_ranks() {
    for topology in [Topology::Chain, Topology::Ring] {
        for rails in [1, 2] {
            for delayed in [0, 1, 2, 3] { exercise_mixed(topology, rails, delayed); }
        }
    }
}
