use super::*;
use super::super::{chain::link::{Link, Links, Qp}, topology::Topology};
use std::sync::{Arc, atomic::AtomicUsize};

fn payload(seq: usize, origin: usize, offset: usize) -> u64 {
    ((seq as u64) << 48) ^ ((origin as u64) << 44) ^ (offset as u64).wrapping_mul(7919)
}

fn exercise(topology: Topology, rails: usize, pipelined: bool) {
    const OPS: usize = 48;
    let max = 1 << 20;
    let cfg = Config { max, stripe_min: 8192, timeout_ns: 0, stage_fence: false, sm_stage: 1, pdl: false, fused_seg: 0 };
    let mut regions: Vec<Vec<u64>> = (0..4).map(|_| vec![0; region_bytes(max, 3) / 8]).collect();
    let hosts: Vec<usize> = regions.iter_mut().map(|r| r.as_mut_ptr() as usize).collect();
    let traffic: Vec<Vec<Arc<AtomicUsize>>> = (0..4).map(|_| (0..4).map(|_| Arc::new(AtomicUsize::new(0))).collect()).collect();
    let mut links: Vec<Links> = (0..4).map(|rank| [0, 1].map(|side| topology.neighbor(rank, 4, side).map(|peer| Link {
        base: hosts[peer] as u64,
        qps: (0..rails).map(|_| Qp::new(traffic[rank][peer].clone())).collect(),
    }))).collect();
    let mut relays: Vec<_> = (0..4).map(|rank| relay::Relay::new(cfg, Shape { ranks: 4, rank, rails: [rails; 2] }, hosts[rank], 0).with_topology(topology)).collect();
    let mut completed = [0usize; 4];
    let mut staged = [false; 4];
    let mut ready = [0usize; 4];
    let mut round = 0;
    while completed.iter().any(|&n| n < OPS) {
        round += 1;
        assert!(round < 100_000, "stalled {topology:?} at {completed:?}");
        for rank in (0..4).map(|n| (n + round) % 4) {
            // Exercise a late rank and deliberately skewed completions.
            if rank == 3 && round % 5 != 0 { continue; }
            for link in links[rank].iter_mut().flatten() { for qp in &mut link.qps { qp.reap(); } }
            if completed[rank] < OPS {
                let seq = completed[rank] + 1;
                let a2a = seq % 3 == 0;
                let bytes = if a2a { 32768 } else { [64, 8192, 131072, max][seq % 4] };
                let code = bytes | if a2a { RS_BIT | A2A_BIT } else { 0 };
                let parts = if a2a { rs_wire_pieces(code) } else { pieces(bytes, cfg.stripe_min) };
                let ctrl = hosts[rank] + ctrl_off(max, 3);
                if !staged[rank] {
                    assert_eq!(unsafe { (*(ctrl as *const AtomicU32)).load(Ordering::Acquire) }, 0);
                    for offset in (0..bytes).step_by(8) {
                        unsafe { ((hosts[rank] + offset) as *mut u64).write(payload(seq, rank, offset)); }
                    }
                    unsafe { (*(ctrl as *const AtomicU32)).store((code | if pipelined || a2a { PIPE_BIT } else { 0 }) as u32, Ordering::Release); }
                    staged[rank] = true;
                    ready[rank] = 0;
                }
                if ready[rank] < parts.len() {
                    unsafe { (*(ctrl.wrapping_add(READY + 8 * ready[rank]) as *const AtomicU64)).store(seq as u64, Ordering::Release); }
                    ready[rank] += 1;
                }
                let wanted: Vec<usize> = if a2a {
                    let k = rs_per_segment(bytes); (rank*k..(rank+1)*k).collect()
                } else { (0..parts.len()).collect() };
                let complete = (0..4).filter(|&o| o != rank).all(|o| wanted.iter().all(|&p| {
                    unsafe { (*(ctrl.wrapping_add(chain_flag_line(origin_slot(o, rank), p, seq as u64)) as *const AtomicU64)).load(Ordering::Acquire) >> 24 >= seq as u64 }
                }));
                let drained = unsafe { (*(ctrl as *const AtomicU32)).load(Ordering::Acquire) == 0 };
                if complete && drained {
                    for origin in (0..4).filter(|&o| o != rank) {
                        let recv = hosts[rank] + recv_off(max, origin_slot(origin, rank), seq & 1);
                        for &p in &wanted {
                            let (offset, len) = parts[p];
                            for at in (offset..offset+len).step_by(8) {
                                let got = unsafe { ((recv+at) as *const u64).read() };
                                assert_eq!(got, payload(seq, origin, at), "{topology:?} seq{seq} rank{rank} origin{origin} byte{at}");
                            }
                        }
                    }
                    completed[rank] += 1;
                    staged[rank] = false;
                }
            }
            relays[rank].serve(&mut links[rank]).unwrap();
        }
    }
    if topology == Topology::Ring {
        assert!(traffic[0][3].load(Ordering::Relaxed) > 0);
        assert!(traffic[3][0].load(Ordering::Relaxed) > 0);
    }
}

#[test]
fn production_relay_preserves_payloads_with_back_to_back_and_delayed_ranks() {
    for topology in [Topology::Chain, Topology::Ring] {
        for rails in [1, 2] {
            for pipelined in [false, true] { exercise(topology, rails, pipelined); }
        }
    }
}
