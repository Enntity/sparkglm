# SPDX-License-Identifier: AGPL-3.0-only
"""Confirm the final binary build uses the GPU-qualified transport PTX."""
import json
from ops import *

final = json.loads((ROOT / 'final-image.json').read_text())
code = '''import hashlib,json,pathlib
paths=list(pathlib.Path('/build/target/release/build').glob('atlas-kernels-*/out/t0__rdma_oneshot.ptx'))
assert paths
print(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}))
'''
hashes = json.loads(ssh('ennspark01', ['docker', 'run', '--rm', '--runtime=runc',
                    '--network=none', '--memory', '128m', '--entrypoint', 'python3',
                    final['builder_id'], '-c', code]).stdout)
assert set(hashes.values()) == {'a6fb26169f6cb6d37a7ffa9e97626f80b94aed304a3fe0a01bf4e758b46e14f2'}, hashes
save('final-transport-ptx.json', {'builder_id': final['builder_id'], 'image_id': final['image_id'],
                               'binary_sha256': final['hashes']['/usr/local/bin/spark'],
                               'passed': True, 'ptx': hashes})
print('Final build transport PTX exactly matches the GPU-qualified parity fix')
