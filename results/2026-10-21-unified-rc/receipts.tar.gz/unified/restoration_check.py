# SPDX-License-Identifier: AGPL-3.0-only
"""Attest each restored lane immediately; do not touch another owner's lane."""
import ast
import json
import sys
import time
from ops import ROOT, HOSTS, ssh, save

resource = sys.argv[1]
assert resource in ('pair', 'drafter-0304')
hosts = HOSTS[:2] if resource == 'pair' else HOSTS[2:]
record = {'resource': resource, 'checked_unix': time.time(), 'hosts': {}, 'passed': False}
for host in hosts:
    if resource == 'pair':
        before = json.loads((ROOT / (host + '-managed-before.json')).read_text())[0]
        name, expected = before['Name'].lstrip('/'), before['Image']
    else:
        rows = json.loads((ROOT / (host + '-before.json')).read_text())['containers'].splitlines()
        before = next(json.loads(row) for row in rows if 'lloom-atlas-sparkqwen-' in row)
        name, expected = before['Names'], 'sha256:' + before['Image']
    current = json.loads(ssh(host, ['docker', 'inspect', name]).stdout)[0]
    assert current['Image'].startswith(expected) and current['State']['Running']
    cap = ssh(host, ['systemctl', 'show', 'gpu-clock-cap.service', '--property=ActiveState', '--value']).stdout.decode().strip()
    assert cap == 'active'
    record['hosts'][host] = dict(name=name, image=current['Image'], running=True,
                                started=current['State']['StartedAt'], clock_service=cap)
if resource == 'pair':
    module = ast.parse((ROOT / 'fallback.py').read_text())
    code = next(ast.literal_eval(node.value) for node in module.body
                if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'code' for t in node.targets))
    code = code.replace("'model':'enntity-presence'", "'model':'glm-5.3-flash-atlas'")
    canary = json.loads(ssh('ennspark01', ['python3', '-c', code]).stdout)
    assert canary['passed'] and canary['route_proof']['resolvedModel'] == 'glm-5.3-flash-atlas'
    save('pair-restored-canary.json', canary)
    record['canary'] = {'model': canary['route_proof']['resolvedModel'], 'answer': '42', 'seconds': canary['seconds']}
else:
    canary = json.loads((ROOT / 'presence-sparkqwen-pair-canary.json').read_text())
    assert canary['passed'] and canary['route_proof']['resolvedModel'] == 'qwen3.8-flash-next-atlas'
    record['canary'] = {'model': canary['route_proof']['resolvedModel'], 'answer': '42', 'seconds': canary['seconds']}
record['passed'] = True
save('restoration-' + resource + '.json', record)
print(resource, 'restored: original managed images, clock caps, real gateway canary')
