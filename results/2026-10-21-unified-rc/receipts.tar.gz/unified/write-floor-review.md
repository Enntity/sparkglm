# Shared prefix write protection review

The failure reproduces without eviction or NVMe I/O. A different request that shares the target's first 16 tokens changes the target's later answer in both serial and native MTP. Setting the existing `ATLAS_GLM_PC_WRITE_FLOOR=1` switch fixes the reproduced failure and passes two forced disk restore cycles with exact outputs. The engine binary and kernels are unchanged.

## Evidence

All paths below are relative to this directory. The original failed receipts are preserved.

| Run | Observed result |
| --- | --- |
| `results/tp4-chain-strict-native-nvme-pressure/nvme-probe/result.json` | Cold serial/native returned the same 50 emitted IDs. After pressure, every rank restored 160/160 blocks with zero reported failures; the answer changed to 54 IDs. This run lacked a pre-pressure resident warm control. |
| `results/tp4-chain-strict-native-nvme-replay/nvme-probe/result.json` | Same prompt/run ID `85f8bbc5b934`, clean reload. Cold serial/native and resident warm native/serial all returned exactly the same 50 IDs. After pressure, the restored native answer changed to the same 54 IDs. This rejects the initial cold-versus-warm dispatch explanation. |
| `results/tp4-chain-strict-native-resident-pressure/nvme-probe/result.json` | Same clean-start controls, then only the original 8,199-token pressure0 request. Its cached prefix was exactly 16 tokens. Both subsequent native and serial answers changed to the same 54 IDs. All seven requests have zero NVMe events on all four ranks. Conservative occupancy bound: 799 blocks in a 2,048-block pool. |
| `results/tp4-chain-strict-native-write-floor/nvme-probe/result.json` | Only the write-floor setting changed. Cold serial/native, resident warm native/serial, both restored native requests and both following serial controls all returned the original exact 50 IDs. Every rank restored 160/160 blocks in cycle 1 and 156/156 in cycle 2, with zero failures. All gates passed. |

The non-evicting receipt's SHA-256 is `e2b20f234cbb0e1288d7951cf340360d9c53e2aca7781d8e481aab91dd2b2dbf`; the passing receipt's is `86fde925ef4ce538365d62526326fedd350175c409ae61db2ca0a7bc080ab279`. Each receipt retains full per-request, per-rank log deltas and raw streaming events. Counts above are emitted ID counts; usage counts include one additional completion token.

`nvme-causal-comparison.json` records all receipt hashes, prompt equality, per-rank restore evidence and artifact identity. The two pressure profiles have identical `server_argv`; their sole environment difference is `ATLAS_GLM_PC_WRITE_FLOOR` changing from absent (effective `0`) to `1`. The original target prompt and all four cycle-1 pressure prompt plans are identical. Engine commit: `d3620ffbaf654186c7213b320e52d0112a71f956`; binary SHA-256: `e79d163dd10c07e3244de7c26a73c915a35ae3df08d5db34162243baaf182467`. Candidate-03's recorded content projection is identical across all four hosts, despite imported Docker image IDs differing between pairs.

The GPU SSM snapshot pool has **16 slots**, from `--ssm-cache-slots=16`. `ATLAS_SSM_TIER_SLOTS=2` sizes the host tier. The target's 4,096-token snapshot remained resident; no target SSM disk fault-in appeared in the logs. The disk budget was 48 GiB combined, split into 24 GiB KV and 24 GiB SSM, with fast KV I/O enabled and KEEP disabled.

## Mechanism and fix scope

`model/trait_impl/prefill_b/pc_policy.rs` documents and implements the relevant behavior: with the switch off, a cache match without a usable SSM anchor recomputes from token zero and rewrites matched blocks still held by other cached requests. The pressure request logs exactly that path for its shared 16-token block. Its 8,192-row prefill uses a different execution shape than the target's 4,096-row prefix.

With the switch on, `pc_write_floor` extends the existing layer write floor through the whole matched prefix. GLM attention then preserves both latent KV and pooled semantic-index rows below that floor. The new request still computes its recurrence and reads the existing cached rows. No weight format, storage format, collective, or native MTP boundary rule changes.

The no-eviction reproduction, source path and single-setting correction identify the shared-prefix rewrite as the operational cause. A byte trace of the shared first block has not been taken. These failures establish no NVMe transport defect.

## Preconditions for TP-2 and TP-4, Strict and Spark

- Set `ATLAS_GLM_PC_WRITE_FLOOR=1` on every rank.
- Keep `ATLAS_PREFIX_SUBBLOCK=0`.
- Keep `ATLAS_MARCONI_EXACT` unset or `0`; the exact-leaf replay shortcut can otherwise corrupt shared rows.
- Keep `ATLAS_GLM_KV_WRITE_FLOOR_LEGACY` unset or `0`; that diagnostic bypasses GLM's floor.
- Reload cleanly when changing the policy. It protects cached values already present and cannot repair a previously mutated block.

The current pressure profile meets the other prerequisites. Startup already compares both write-floor switches across ranks. The rule has no TP-2-specific geometry. KV swap files are created per process and immediately unlinked, so they cannot carry old poisoned data across a clean reload.

Native MTP still recomputes target and predictor together after a private-prefix miss and restores the agreed target/predictor boundary after a hit. Protecting the target's cached blocks preserves the state against which its immutable predictor snapshot was made. DFlash captures the target state produced by that same forward pass; its capture geometry and acceptance rules are unchanged.

Cold requests with no shared prefix and normal Marconi replays keep their existing write floors. MLA fusion stays enabled for ordinary decode/verify and unfloored tails. A recompute with protected cached rows takes the already-existing separate MLA front. No throughput claim is made for that case.

## Focused checks

The existing CPU filters are `write_floor_covers_the_matched_rows_of_a_recompute` and `mla_write_floor_tests`. The latter covers latent/index write suppression, wholly protected chunks, dense/sparse piece boundaries, and invalid partial index-pool floors. They can run in the cached Linux builder with `cargo test -p spark-model --lib <filter>`; they were not rerun locally for this review.

The completed flag-on check reused the exact original prompt, required cold/resident-warm serial/native equality, and passed two forced disk restores with full restoration evidence on all ranks and exact output equality to the pre-pressure warm controls. This supports the four-profile configuration fix. This causal experiment used TP4 Strict native; broader TP2/Spark qualification remains with the release owner. Engine source remained unchanged during this review.
