set -euo pipefail
cd /build

# Reproduce the original production module before changing any source. The
# flags are build_target.rs plus common/model KERNEL.toml and gb10 arch.
original=$(find /build/target/release/build -name t0__rdma_oneshot.ptx -print -quit)
nvcc --ptx -arch=sm_121f -O3 --fmad=false -DTQ_PLUS_SIGNS --expt-relaxed-constexpr --Werror all-warnings /build/kernels/gb10/common/rdma_oneshot.cu -o /tmp/original-rdma.ptx
cmp "$original" /tmp/original-rdma.ptx
printf 'Original production PTX reproduced byte-for-byte: '
sha256sum /tmp/original-rdma.ptx
# Apply only the reviewed parity fix from the local source archive.
tar -xf - -C /build
nvcc --ptx -arch=sm_121f -O3 --fmad=false -DTQ_PLUS_SIGNS --expt-relaxed-constexpr --Werror all-warnings /build/kernels/gb10/common/rdma_oneshot.cu -o /tmp/parity-rdma.ptx
printf 'Fixed production PTX: '
sha256sum /tmp/parity-rdma.ptx
python3 - <<'PATCH'
from pathlib import Path
p=Path('crates/spark-comm/src/nccl_backend/rdma_pair/chain_loopback_tests.rs')
s=p.read_text();assert s.count('for _ in 0..1000 {')==1
p.write_text(s.replace('for _ in 0..1000 {','for _ in 0..3 {'))
print('Work-only test change: timing-only tail reduced1000to3; correctness assertions unchanged; no timing claims')
PATCH
export ATLAS_ONESHOT_CUBIN_DIR=/tmp/transport-test-kernels
mkdir "$ATLAS_ONESHOT_CUBIN_DIR"
for name in rdma_oneshot bf16_add; do
 ptx=$(find /build/target/release/build -name "t0__${name}.ptx" -print -quit)
 test -s "$ptx"
 cp "$ptx" "$ATLAS_ONESHOT_CUBIN_DIR/$name.cubin"
done
cp /tmp/parity-rdma.ptx "$ATLAS_ONESHOT_CUBIN_DIR/rdma_oneshot.cubin"
sha256sum "$ATLAS_ONESHOT_CUBIN_DIR/"*
cargo test --locked --release -j 4 -p spark-comm --lib chain_completion_words_follow_payload_parity -- --nocapture
export ATLAS_RDMA_ONESHOT=1 ATLAS_RDMA_PAIR_CHAIN=1 ATLAS_RDMA_LEFT_RAILS=rocep1s0f0,roceP2p1s0f0 ATLAS_RDMA_RIGHT_RAILS=rocep1s0f0,roceP2p1s0f0
export ATLAS_RDMA_ONESHOT_MAX=8388544 ATLAS_RDMA_RS_BLOCKS=16 ATLAS_RDMA_ONESHOT_SM_STAGE=1 ATLAS_RDMA_ONESHOT_PDL=0 ATLAS_ONESHOT_LOOPBACK_ROUNDS=1 ATLAS_ONESHOT_A2A_ROWS=4096 ATLAS_RDMA_ONESHOT_CHANNELS=1 ATLAS_RDMA_RS_FUSED_SEG=16777216
for topology in chain ring; do
 printf "\nTOPOLOGY=%s\n" "$topology"
 export ATLAS_RDMA_TOPOLOGY=$topology
 cargo test --locked --release -j 4 -p spark-comm --lib chain_loopback -- --ignored --nocapture --test-threads=1
done
