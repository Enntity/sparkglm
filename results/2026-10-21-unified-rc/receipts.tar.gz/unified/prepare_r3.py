# SPDX-License-Identifier: AGPL-3.0-only
"""Preserve candidate two, then build the TP4 storage and precision-policy delta."""
import hashlib
import json
import shutil
import subprocess
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ENGINE = ROOT.parent / 'glm-native-mtp-20261020/engine'
PRODUCT = ROOT.parent / 'glm-native-mtp-20261020/product'
OLD = ROOT / 'candidate-02'
CTX = ROOT / 'context'


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()


state = json.loads((ROOT / 'cluster-state.json').read_text())
assert not state['owned'] and not state['pending'], 'Stop validation containers before replacing active identity manifests'
assert not git(ENGINE, 'status', '--porcelain')
assert not git(PRODUCT, 'status', '--porcelain', '--', 'install')
commit = git(ENGINE, 'rev-parse', 'HEAD')
tree = git(ENGINE, 'rev-parse', 'HEAD^{tree}')
pin = json.loads((PRODUCT / 'install/atlas-source.json').read_text())
assert pin['commit'] == commit and pin['tree'] == tree
OLD.mkdir(exist_ok=False)
for name in ('context', 'context.tar', 'build-plan.json', 'final-image.json',
             'builder-build.log', 'builder-build-exit.json', 'runtime-build.log',
             'runtime-build-exit.json', 'image-host-identity.json'):
    shutil.move(ROOT / name, OLD / name)
previous = json.loads((OLD / 'final-image.json').read_text())
old_hashes = json.loads((OLD / 'context/source-hashes.json').read_text())
roots = ('crates/', 'kernels/', 'vendor/', 'jinja-templates/', 'test_data/',
         'bench/ngram_ref/', 'scripts/dev/glm_sparse_native/')
hashes = {f: hashlib.sha256((ENGINE / f).read_bytes()).hexdigest()
          for f in git(ENGINE, 'ls-files').splitlines()
          if (f.startswith(roots) or f in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'))
          and (ENGINE / f).is_file()}
assert not set(old_hashes) - set(hashes)
CTX.mkdir()
changed = []
for name, digest in hashes.items():
    if old_hashes.get(name) != digest:
        dest = CTX / 'patch' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ENGINE / name, dest)
        changed.append(name)
assert changed and all(name.startswith(('crates/spark-runtime/', 'crates/spark-model/')) for name in changed), changed
(CTX / 'source-hashes.json').write_text(json.dumps(hashes, sort_keys=True) + '\n')
(CTX / 'changed-files.json').write_text(json.dumps(changed) + '\n')
for name in ('verify_source.py', 'touch_changed.py'):
    shutil.copy2(OLD / 'context' / name, CTX / name)
shutil.copytree(PRODUCT / 'install', CTX / 'install', ignore=shutil.ignore_patterns('__pycache__'))
install = git(PRODUCT, 'rev-parse', 'HEAD:install')
plan = {'commit': commit, 'tree': tree, 'product_commit': git(PRODUCT, 'rev-parse', 'HEAD'),
        'install_tree': install, 'image': 'localhost/atlas-sparkglm:unified-rc-' + install[:12],
        'builder_base': previous['builder_tag'], 'builder_base_id': previous['builder_id'],
        'builder_tag': 'localhost/atlas-glm-unified-builder:' + install[:12],
        'runtime_base': previous['tag'], 'runtime_base_id': previous['image_id'],
        'changed_source': changed, 'verified_source_files': len(hashes),
        'qualification_delta': 'TP4 sharded NVMe prefix tier; TP4 shared expert split disabled in both modes'}
(CTX / 'test-build.sh').write_text('''#!/bin/bash
set -euo pipefail
cargo test --locked --release -j 4 -p spark-runtime --lib nvme -- --nocapture
cargo test --locked --release -j 4 -p spark-model --lib kv_nvme -- --nocapture
cargo build --locked --release -j 4 -p spark-server
''')
(CTX / 'Dockerfile').write_text(f'''# SPDX-License-Identifier: AGPL-3.0-only
FROM {plan['builder_base']} AS builder
WORKDIR /build
COPY patch/ /build/
COPY changed-files.json touch_changed.py source-hashes.json verify_source.py test-build.sh /tmp/
COPY install/ /product/install/
RUN python3 /tmp/touch_changed.py && python3 /tmp/verify_source.py
RUN bash /tmp/test-build.sh
FROM {plan['runtime_base']}
COPY --from=builder /build/target/release/spark /usr/local/bin/spark
COPY install/serve.py /opt/atlas/serve.py
COPY install/profiles/ /opt/atlas/profiles/
COPY install/atlas-source.json /opt/atlas/source-manifest.json
LABEL io.enntity.sparkglm.install-tree="{install}" io.enntity.sparkglm.engine-commit="{commit}" io.enntity.sparkglm.local-rc="true"
''')
with tarfile.open(ROOT / 'context.tar', 'w') as archive:
    for p in CTX.iterdir():
        archive.add(p, arcname=p.name)
plan['context_sha256'] = hashlib.sha256((ROOT / 'context.tar').read_bytes()).hexdigest()
(ROOT / 'build-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
print(json.dumps(plan, indent=2))
