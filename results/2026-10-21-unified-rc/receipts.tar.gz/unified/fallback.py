# SPDX-License-Identifier: AGPL-3.0-only
"""Switch the authorized Presence route and verify the throttled gateway path."""
import json,sys
from ops import *
profile=sys.argv[1] if len(sys.argv)>1 else 'deepseek-direct'
if '--verify-only' not in sys.argv:
 preview=cli(['route','enntity-presence',profile],'presence-'+profile+'-preview','ennspark03')
 changed=cli(['route','enntity-presence',profile,'--apply','--yes'],'presence-'+profile+'-applied','ennspark03')
code=r'''
import json,pathlib,urllib.request,time,os,re,uuid
cfg=json.loads((pathlib.Path.home()/'.lloom/config.json').read_text());env=dict(os.environ)
p=pathlib.Path.home()/'.config/lloom/env'
if p.exists():
 for line in p.read_text().splitlines():
  m=re.match(r'^([A-Za-z_][A-Za-z0-9_]*)=(.*)$',line.strip())
  if m:
   k,v=m.groups();v=v.strip()
   if len(v)>=2 and v[0]==v[-1] and ord(v[0]) in (34,39):v=v[1:-1]
   env.setdefault(k,v)
caller='glm-restore-'+uuid.uuid4().hex[:12]
headers={'Content-Type':'application/json','x-lloom-client':caller}
if cfg['security']['apiKeys']:
 key=re.sub(r'\$\{([A-Za-z_][A-Za-z0-9_]*)\}',lambda m:env[m[1]],cfg['security']['apiKeys'][0]);headers['Authorization']='Bearer '+key
base='http://'+cfg['server'].get('host','127.0.0.1')+':'+str(cfg['server']['port'])
admin_headers=dict(headers)
if cfg['security'].get('adminApiKeys'):
 key=re.sub(r'\$\{([A-Za-z_][A-Za-z0-9_]*)\}',lambda m:env[m[1]],cfg['security']['adminApiKeys'][0]);admin_headers['Authorization']='Bearer '+key
def call(path,body=None):
 with urllib.request.urlopen(urllib.request.Request(base+path,json.dumps(body).encode() if body else None,admin_headers if path.startswith('/gateway/') else headers),timeout=300) as r:return json.load(r)
models=call('/v1/models');route=call('/gateway/routing');status=call('/gateway/status')
body={'model':'enntity-presence','messages':[{'role':'user','content':'What is 17 + 25? Reply with only the integer.'}],'temperature':0,'max_tokens':64,'chat_template_kwargs':{'reasoning_effort':'low'}}
t=time.monotonic();answer=call('/v1/chat/completions',body)
c=answer['choices'][0];assert c['finish_reason']=='stop' and c['message']['content'].strip()=='42',answer
proof=[]
for _ in range(20):
 proof=[row for row in call('/gateway/metrics')['recent'] if row.get('caller')==caller]
 if proof:break
 time.sleep(.2)
assert len(proof)==1 and proof[0].get('ok') is True,proof
print(json.dumps({'passed':True,'seconds':time.monotonic()-t,'request':body,'response':answer,'route_proof':proof[0],'routing':call('/gateway/routing'),'status':call('/gateway/status'),'models':call('/v1/models')}))
'''
x=json.loads(ssh('ennspark03',['python3','-c',code]).stdout)
expected={'deepseek-direct':'deepseek-flash','sparkqwen-pair':'qwen3.8-flash-next-atlas'}[profile]
save('presence-'+profile+'-canary-attempt.json',x)
assert x['route_proof'].get('resolvedModel')==expected, 'Canary did not reach the requested backend'
assert x['routing']['aliases']['enntity-presence']['members']==[expected]
save('presence-'+profile+'-canary.json',x)
print('Presence route',profile,'verified: 42; model',x['route_proof'].get('resolvedModel'))
