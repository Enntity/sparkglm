# SPDX-License-Identifier: AGPL-3.0-only
import hashlib,json,subprocess,threading
from ops import *
plan=json.loads((ROOT/'build-plan.json').read_text());stop=threading.Event()
def heartbeat():
 while not stop.wait(120):
  try:renew();note('Building pinned unified TP2/TP4 RC; focused Linux regressions and rebuilt native ABI2 attention')
  except Exception as exc:print('Heartbeat error',repr(exc),flush=True)
for host in HOSTS[:2]:assert not ssh(host,['docker','ps','-q']).stdout.strip(),'Container still running'
for tag,key in ((plan['builder_base'],'builder_base_id'),(plan['runtime_base'],'runtime_base_id')):
 assert ssh('ennspark01',['docker','image','inspect','--format','{{.Id}}',tag]).stdout.decode().strip()==plan[key]
threading.Thread(target=heartbeat,daemon=True).start()
try:
 ssh('ennspark01',['mkdir','-p',STAGE+'/build'])
 with (ROOT/'context.tar').open('rb') as source:ssh('ennspark01',['tar','-xf','-','-C',STAGE+'/build'],stdin=source,stdout=subprocess.DEVNULL)
 for target,tag in (('builder',plan['builder_tag']),(None,plan['image'])):
  label='builder' if target else 'runtime'
  with (ROOT/(label+'-build.log')).open('wb') as log:
   args=['docker','build','--pull=false','--progress=plain','-t',tag]
   if target:args+=['--target',target]
   result=ssh('ennspark01',args+[STAGE+'/build'],stdout=log,stderr=subprocess.STDOUT,check=False,timeout=7200)
  save(label+'-build-exit.json',{'code':result.returncode});assert result.returncode==0,f'{label} build failed'
 image=ssh('ennspark01',['docker','image','inspect','--format','{{.Id}}',plan['image']]).stdout.decode().strip()
 builder=ssh('ennspark01',['docker','image','inspect','--format','{{.Id}}',plan['builder_tag']]).stdout.decode().strip()
 code="""import pathlib,json,hashlib
paths=[pathlib.Path('/usr/local/bin/spark'),pathlib.Path('/opt/atlas/serve.py'),*pathlib.Path('/opt/atlas/native').glob('*.so'),*pathlib.Path('/opt/atlas/profiles').glob('*.json')]
print(json.dumps({'source':json.loads(pathlib.Path('/opt/atlas/source-manifest.json').read_text()),'hashes':{str(p):hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in paths}}))"""
 a=json.loads(ssh('ennspark01',['docker','run','--rm','--runtime=runc','--network=none','--memory','128m','--entrypoint','python3',image,'-c',code]).stdout)
 assert a['source']['commit']==plan['commit'] and a['source']['tree']==plan['tree']
 old=json.loads(ssh('ennspark01',['docker','run','--rm','--runtime=runc','--network=none','--memory','128m','--entrypoint','python3',plan['runtime_base_id'],'-c',code]).stdout)
 changed={'/usr/local/bin/spark','/opt/atlas/serve.py','/opt/atlas/native/libatlas_glm_sparse_native.so','/opt/atlas/profiles/4x1m-tp4.json'}
 assert {k:v for k,v in old['hashes'].items() if k not in changed}=={k:v for k,v in a['hashes'].items() if k not in changed}
 assert a['hashes']['/opt/atlas/serve.py']==hashlib.sha256((ROOT/'context/install/serve.py').read_bytes()).hexdigest()
 final={'image_id':image,'tag':plan['image'],'builder_id':builder,'builder_tag':plan['builder_tag'],'source':a['source'],'hashes':a['hashes'],'install_tree':plan['install_tree'],'product_commit':plan['product_commit']}
 save('final-image.json',final)
 note('Unified CUDA image built, focused Linux checks passed, source and runtime artifact identity verified')
 print('Built:',image,flush=True)
finally:stop.set()
