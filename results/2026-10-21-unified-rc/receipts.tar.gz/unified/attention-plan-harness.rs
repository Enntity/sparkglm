mod speculative { pub mod glm_repair_policy { pub const MAX_LONG_CONTEXT: usize = 32768; } }
#[path="/Users/jmac/Documents/Codex/2026-10-19/cl/work/glm-native-mtp-20261020/engine/crates/spark-model/src/layers/ops/glm_sparse_native_plan.rs"]
mod plan;
