set -euo pipefail
cd /build
python3 - <<'PATCH'
from pathlib import Path
p=Path('crates/spark-comm/src/nccl_backend/rdma_pair/chain_loopback_tests.rs')
s=p.read_text();assert s.count('for _ in 0..1000 {')==1
p.write_text(s.replace('for _ in 0..1000 {','for _ in 0..3 {'))
print('Work-only test change: timing-only tail reduced1000to3; correctness assertions unchanged; no timing claims')
PATCH
export ATLAS_ONESHOT_CUBIN_DIR=/tmp/transport-test-kernels
mkdir "$ATLAS_ONESHOT_CUBIN_DIR"
for name in rdma_oneshot bf16_add; do
 ptx=$(find /build/target/release/build -name "t0__${name}.ptx" -print -quit)
 test -s "$ptx"
 cp "$ptx" "$ATLAS_ONESHOT_CUBIN_DIR/$name.cubin"
done
sha256sum "$ATLAS_ONESHOT_CUBIN_DIR/"*
export ATLAS_RDMA_ONESHOT=1 ATLAS_RDMA_PAIR_CHAIN=1 ATLAS_RDMA_LEFT_RAILS=rocep1s0f0,roceP2p1s0f0 ATLAS_RDMA_RIGHT_RAILS=rocep1s0f0,roceP2p1s0f0
export ATLAS_RDMA_ONESHOT_MAX=8388544 ATLAS_RDMA_RS_BLOCKS=16 ATLAS_RDMA_ONESHOT_SM_STAGE=1 ATLAS_RDMA_ONESHOT_PDL=0 ATLAS_ONESHOT_LOOPBACK_ROUNDS=1 ATLAS_ONESHOT_A2A_ROWS=4096 ATLAS_RDMA_ONESHOT_CHANNELS=1 ATLAS_RDMA_RS_FUSED_SEG=16777216
for topology in chain ring; do
 export ATLAS_RDMA_TOPOLOGY=$topology
 cargo test --locked --release -j 4 -p spark-comm --lib chain_loopback -- --ignored --nocapture --test-threads=1
done
