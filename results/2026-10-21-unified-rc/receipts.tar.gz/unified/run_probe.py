# SPDX-License-Identifier: AGPL-3.0-only
import json,shlex,subprocess,sys,threading,time
from ops import *
from cluster import collect
s=json.loads((ROOT/'cluster-state.json').read_text());script=sys.argv[1];extra=sys.argv[2:]
assert script in ('smoke.py','capacity.py','nvme_probe.py','quick_speed.py','short_parity.py')
out=STAGE+'/validation/results/'+s['arm'];ssh('ennspark01',['mkdir','-p',out]);stop=threading.Event()
def heartbeat():
 while not stop.wait(100):
  try:renew();note(s['arm']+': '+script+' focused validation running')
  except Exception as e:print(repr(e),flush=True)
threading.Thread(target=heartbeat,daemon=True).start()
label=script.replace('.py','')+('-serial' if '--serial' in extra else '')
try:
 renew();note(s['arm']+': '+label)
 command='cd '+shlex.quote(out)+' && '+shlex.join(['python3','-u',STAGE+'/validation/'+script,*extra])
 with (ROOT/s['arm']/(label+'.log')).open('wb') as log:r=ssh('ennspark01',['bash','-c',command],stdout=log,stderr=subprocess.STDOUT,check=False,timeout=3600)
 save(s['arm']+'/'+label+'-exit.json',{'code':r.returncode});collect();assert r.returncode==0,'Probe failed: '+label
 print(s['arm'],label,'passed',flush=True)
finally:stop.set()
