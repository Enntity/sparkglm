#!/usr/bin/env bash
# Replay only under an active authorized reservation on an idle GB10.
# Run inside the pinned validation image with eval/, native/, source/ mounted.
# The candidate must be extracted from the recorded actual unified builder.
set -euo pipefail
cd /eval
nvcc -std=c++17 -O2 --fmad=false --prec-div=true --ftz=false \
  -gencode=arch=compute_121a,code=sm_121a -shared -Xcompiler=-fPIC \
  native-prep.cu -o libatlas_native_prep.so
nvcc -O3 -std=c++17 -shared -Xcompiler=-fPIC \
  -gencode=arch=compute_121a,code=sm_121a -I/source \
  atlas-wrapper-tp24.cu -o libatlas_sparse_tp24.so
nvcc -std=c++17 -O2 --fmad=false --prec-div=true --ftz=false \
  -gencode=arch=compute_121a,code=sm_121a -shared -Xcompiler=-fPIC \
  merge-ds.cu -o libatlas_sparse_merge_tp24.so
timeout 180s python3 native-prep-check.py
timeout 240s python3 unified-check.py --heads 16 32 \
  --atlas /eval/libatlas_sparse_tp24.so --merge /eval/libatlas_sparse_merge_tp24.so
