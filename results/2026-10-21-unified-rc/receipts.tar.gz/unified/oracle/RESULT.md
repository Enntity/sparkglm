# Sparse native ABI2 oracle: passed

Ran on reserved `ennspark02` (GB10), under `r-687a4ddc` / `codex-glm-unified`. The candidate library was extracted from the actual unified builder image `sha256:19033fb71b297c30ee931aaf6db11f2bb24f22dc2a043dd0eec33c2e16dc8728`, then copied directly over the 01→02 fabric link. Candidate SHA256: `59f53b2d980ad78f9a092d9d7a6623ec210b612f42c8476a808c943920abd9f8`.

Engine `4abf199ce65ba0a34723248f66421ed448b2f6fe`; pinned source build uses FlashInfer `8eccd0c1352165302840c0e19066bc42d36dbd7a`. Runtime was the cached `vllm/vllm-openai:v0.30.0`, image ID and registry digest recorded in `receipt.json`, with Torch `2.13.0+cu130` and TVM FFI. No image pull or production source edit.

- Preparation: all **8 Q cases and 24 KV cases** passed, including 16/32 heads and 32K tails, zero/tiny/random/extreme inputs, input preservation, and guards. Peak Torch reserved memory 404,750,336 bytes.
- Combined ABI2 check: all **8 fixtures** passed at 2048, 3515, 4100, and 4096 rows for each of 16/32 heads, starting at sequence position 16384. Prepared buffers, metadata, final output, and final LSE matched independent reference components byte-for-byte; inputs and guards remained intact. The 24 rejection cases passed for each head count. Peak Torch reserved memory stayed below the 2 GiB cap.

| Local heads | Current Atlas baseline median | Native inclusive median | Speedup |
|---|---:|---:|---:|
| 16 (TP4 geometry) | 31.419 ms | 15.991 ms | 1.965× |
| 32 (TP2 geometry) | 34.394 ms | 24.206 ms | 1.421× |

Timing uses 4096 query rows, 3 warmups and 9 alternating pairs; the native timing includes preparation. Both exceeded the existing 1.3× kernel gate. Raw samples are in `unified-check.log` and `receipt.json`. No clocks were changed. These synthetic kernel results are not model-quality or whole-model throughput qualification.

## Reference provenance and setup repairs

The retained native TVM library came from `ennspark01:/home/enntitysparkadmin/.cache/huggingface/flashinfer/.cache/flashinfer/0.6.15/121a/cached_ops/sparse_mla_sm120/sparse_mla_sm120.so`, SHA256 `f63925f3590235c436017af0818b02cee028c2caeb6721422a15f652bb65b79a`. Its original exact source revision remains unresolved, as documented in the engine. It was not modified.

The retained Atlas timing wrapper explicitly rejected 16 heads. A work-only wrapper (`eval/atlas-wrapper-tp24.cu`) admits 16/32 and includes the current engine's existing BF16 sparse kernel, which already supports 16 heads. That wrapper is only the timing baseline; candidate output byte equivalence is against separately invoked native attention and merge. Current kernel sources and all required includes are retained in `source/`.

The retained merge binary also rejected 16 heads, causing the first run to stop at `reference merge` (`unified-check-old-merge.log`). Rebuilt the existing 16/32-head `merge-ds.cu` source with the documented precise flags; no math change was made. The rerun passed both head counts. First baseline compile lacked a required include; copied the unchanged include and rebuilt. Those setup failures are preserved in the build logs and are not candidate kernel failures.

All local scripts/libraries/logs and their SHA256 hashes are retained here (`sha256.json`). Remote task assets remain at `/home/enntitysparkadmin/glm-unified-oracle-20261021` on 02; the extracted candidate remains under the same task directory on 01. All task build/GPU containers used `--rm`; the stopped extraction container was removed. `environment-after.log` and `builder-identity.log` confirm cleanup. The parent's reservation remains active; no resource release, routing, model, netplan, or clock change was made.
