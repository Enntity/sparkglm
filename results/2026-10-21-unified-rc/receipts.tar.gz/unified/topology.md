# TP4 switchless chain/ring transport implementation

Implemented in the existing engine working tree. Root owns the unified product interface, central commits, build and qualification. This subtask subsequently used the reserved GPU01 for the focused transport defect reproduction and parity fix checks described below; no fabric configuration was changed.

## Behavior and product contract

- Set `ATLAS_RDMA_TOPOLOGY=chain` or `ATLAS_RDMA_TOPOLOGY=ring` on every TP4 rank. Omission preserves legacy chain behavior. Unknown/empty values fail rather than silently selecting a topology. Ring requires exactly four ranks.
- `ATLAS_RDMA_PAIR_CHAIN=1` must remain set for both topologies: despite its name, it means ordered data+flag RDMA WRITEs on a single QP, not physical chain topology.
- Chain has the existing neighbors: left=`rank-1`, right=`rank+1`, with no left on rank0/no right on rank3. Ring wraps: rank0 left=rank3; rank3 right=rank0. Both rail lists are required on every ring rank.
- Keep `ATLAS_RDMA_ALLREDUCE=1`, `ATLAS_RDMA_ONESHOT=1`, existing one-shot settings, and routed socket NCCL startup/fallback settings. The peer identity bootstrap still uses rank0's existing NCCL TCP connections and master port+2.
- Bootstrap wire magic changes from `ATLCHAN3` to `ATLCHAN5` (the intermediate ring prototype used `ATLCHAN4`). All TP4 ranks must use the same new build. Topology is part of the agreement before any QP connects; mixed topology and wrapped-edge rail-count mismatch fail with a named reason.
- Startup reports `RDMA ring ready: rank ...` or `RDMA chain ready: rank ...` with both rail lists.
- TP2 pair bootstrap, arithmetic, and transport path are untouched. The shared kernel retains its original R=2 flag addresses. The new variable is read only when the 3/4-rank transport connects.

## What the ring accelerates

Small all-reduce, broadcast, and gather copy each rank's original payload to both adjacent ranks. In ring mode the clockwise neighbor forwards once to the opposite rank. Every peer receives one copy in at most two physical hops, compared with up to three in chain. Every link gets equal aggregate flood traffic; both directions of the new rank0/rank3 edge carry payloads.

GPU reduction arithmetic and reduction order are unchanged. Multi-rank completion addresses now select the matching payload parity, as described in the defect fix below. The receiver always writes the slot corresponding to the original rank; wraparound explicitly recalculates the destination slot rather than assuming the chain's slot invariant. Deferred WRITE completion tracking retains the QP that owns each flag-source ticket.

The existing specialized reduce-scatter (including FP8 and fused variants), all-to-all, and command forwarding use their established linear schedules. Their kernels have rank-specific pairing/segment roles. Preserving those paths retains all existing optimizations and avoids changing arithmetic to obtain the ring's lower latency for decode collectives. Large all-reduce still uses specialized reduce-scatter plus gather at its configured threshold; its gather benefits from the ring.

No percentage gain is claimed. The transport shortens the latency-sensitive flood path; end-to-end gains require measurement on four actual hosts.

## Cabling map from the completed ring-recovery receipts

With rank0..3 = ennspark01..04:

| Host | Left rails | Right rails |
|---|---|---|
| 01 | `rocep1s0f1,roceP2p1s0f1` (to04; ring only) | `rocep1s0f0,roceP2p1s0f0` (to02) |
| 02 | `rocep1s0f0,roceP2p1s0f0` (to01) | `rocep1s0f1,roceP2p1s0f1` (to03) |
| 03 | `rocep1s0f0,roceP2p1s0f0` (to02) | `rocep1s0f1,roceP2p1s0f1` (to04) |
| 04 | `rocep1s0f1,roceP2p1s0f1` (to03) | `rocep1s0f0,roceP2p1s0f0` (to01; ring only) |

The new link is 10.100.196.1/2 and 10.100.197.1/2. Existing recovery receipts verified jumbo ping and bidirectional RDMA on each. This subtask made no current-host health claim and did not modify netplan, interfaces, MTUs, routes, or cabling.

## Changed engine files

- `crates/spark-comm/src/nccl_backend/rdma_pair.rs` — registers the topology module.
- `crates/spark-comm/src/nccl_backend/rdma_pair/topology.rs` — explicit topology parser, wire identity, neighbor and flood routing.
- `crates/spark-comm/src/nccl_backend/rdma_pair/topology_tests.rs` — mode validation, wrapped neighbors, no duplicate/missing deliveries, two-hop bound and balanced use of all ring links.
- `crates/spark-comm/src/nccl_backend/rdma_pair/chain.rs` — topology selection/rail validation, handshake and relay configuration, startup logging. Existing command/proxy behavior retained.
- `crates/spark-comm/src/nccl_backend/rdma_pair/chain/collectives.rs` — unchanged collective method bodies extracted from pre-existing oversized chain.rs. This keeps both touched modules below the 500-line cap.
- `crates/spark-comm/src/nccl_backend/rdma_pair/chain/bootstrap.rs` — topology on the wire, wrapped link validation and identity routing.
- `crates/spark-comm/src/nccl_backend/rdma_pair/chain/bootstrap_tests.rs` — real TCP four-rank ring bootstrap, mixed-mode failure and wrapped-edge rail mismatch.
- `crates/spark-comm/src/nccl_backend/rdma_pair/oneshot/relay.rs` — modulo neighbor destinations, topology selection, QP ownership bookkeeping.
- `crates/spark-comm/src/nccl_backend/rdma_pair/oneshot/relay/forward.rs` — forwarding implementation extracted below file cap; ring flood routing, preserved specialized routes, destination origin-slot calculation, completion waits on the originating QP.

## CPU validation already completed

`topology-all-tests.log`: 31 passed, 0 failed, 3.22 seconds.

The temporary harness imports the actual production topology and TCP bootstrap modules. It also imports the actual production Relay/forward modules; unchanged host-side layouts and piece scheduling are extracted from production oneshot.rs. Only the RDMA QP I/O is replaced with deferred in-memory WRITEs. The harness checks 48 back-to-back flood/all-to-all operations for each of chain/ring × 1/2 rails × eager/pipelined staging, deliberately delaying one rank and checking every received payload. It confirms nonzero traffic on both 0→3 and 3→0.

Commands/receipts:

```sh
cargo test --offline --manifest-path work/glm-unified-rc-20261021/topology-harness/Cargo.toml
```

- `topology-red.log` — pre-implementation missing topology-module failure.
- `topology-green.log` — 30 production parser/bootstrap tests passed.
- `topology-relay.log` — actual production relay CPU transport harness passed.
- `topology-all-tests.log` — combined 31-test pass.
- `topology-cargo-check.log` — forced `atlas_rdma_verbs` Mac check reached eight pre-existing Linux-only `sched_*`/`CPU_*` libc API errors in proxy.rs; Linux compilation remains required. No ring type errors were reported, but this is not a successful crate check.

The initial TCP test attempt encountered sandbox localhost-bind EPERM; the authorized escalated local-only rerun passed. This was an environment restriction, not a topology failure.

## Required focused GPU validation (root-owned)

First build/check spark-comm on Linux with the actual RDMA cfg enabled. A check with `ATLAS_SKIP_BUILD=1` alone does not compile this module; use the real build or force `RUSTFLAGS='--cfg atlas_rdma_verbs'` for a CPU-only Linux check.

Existing real-NIC/GPU loopback tests accept the new environment variable unchanged. On one reserved Spark, run both topology values with the same build, kernel directory, HCA and settings:

```sh
ATLAS_RDMA_TOPOLOGY=ring \
ATLAS_ONESHOT_CUBIN_DIR=<actual-cubin-directory> \
ATLAS_RDMA_ONESHOT=1 ATLAS_RDMA_PAIR_CHAIN=1 \
ATLAS_RDMA_LEFT_RAILS=<same-local-HCA-list> \
ATLAS_RDMA_RIGHT_RAILS=<same-local-HCA-list> \
ATLAS_RDMA_ONESHOT_MAX=8388544 ATLAS_RDMA_RS_BLOCKS=16 \
ATLAS_RDMA_ONESHOT_SM_STAGE=1 ATLAS_RDMA_ONESHOT_PDL=0 \
ATLAS_ONESHOT_LOOPBACK_ROUNDS=1 \
cargo test -p spark-comm chain_loopback_four_ranks -- --ignored --nocapture
```

Repeat with `ATLAS_RDMA_TOPOLOGY=chain`. The existing test covers exact BF16 all-reduce against `(x0+x1)+(x2+x3)`, every broadcast root, positive/negative-stride gather, reduce-scatter interleaved with floods, payloads above maximum, graph capture/replay, and delayed ranks. If the shipped profile uses two channels, include `ATLAS_RDMA_ONESHOT_CHANNELS=2`; it adds the existing concurrent-channel stress sequence. PDL must remain off for this four-processes-on-one-GPU loopback because multiple persistent kernels sharing one GPU can deadlock for unrelated scheduling reasons.

Other affected existing tests (same environment; ensure the runner reports actual execution, not skip):

- `chain_loopback_all_to_all`: set `ATLAS_ONESHOT_A2A_ROWS=4096` with the production 8,388,544-byte one-shot limit; smaller one-shot limits can legitimately refuse/skip these rows.
- `chain_loopback_reduce_scatter_fp8`: checks the existing specialized FP8 route in each topology.
- `chain_loopback_reduce_scatter_fused`: set the actual nonzero `ATLAS_RDMA_RS_FUSED_SEG`; otherwise it skips. This is the crucial fused→flood→fused interleave regression.

Then actual four-host verification is still necessary: use the per-host rails above, capture all four startup identities, sample the 01f1/04f0 NIC counters before/after matched decode, and verify wraparound traffic in both directions. Compare identical strict and Spark prompt outputs in chain and ring with identical settings and serial/spec modes as needed. Compare short uncapped prose/code/structured timing with only topology changed; no ring percentage claim without those receipts. Physically unplugging/reconfiguring cables is unnecessary: chain mode simply does not open the endpoint edge.

Unchanged reduction arithmetic supports expecting exact chain/ring results; they are not a substitute for the GPU and live-serving checks.

## Follow-up: mixed specialized/flood CPU regression

At the root's request, added only `topology-harness/src/mixed_relay_test.rs` and its scratch harness registration after freezing production source. No engine source changed.

`topology-mixed-relay.log`: the new focused test passed in 13.67 seconds. Together with the preceding 31-test pass, all 32 current harness tests have passing receipts (the previous 31 were not unnecessarily rerun).

The new test executes the production relay with deferred in-memory QP writes. A CPU producer/consumer emulates the existing BF16 kernel's raw staging, pairwise sums, ready-word publication, own-segment final reduction, and fused-region layout. The expected reference is the independent fixed tree `(x0+x1)+(x2+x3)` with BF16 rounding at each add. This tests transport bytes/order and buffer lifetime; it does not execute or validate CUDA arithmetic itself.

- Topologies: chain and ring.
- One/two rails, with each of four ranks delayed in turn: 16 configurations.
- 48 operations/rank/configuration, alternating flood, ordinary reduce-scatter and fused reduce-scatter; includes consecutive ordinary RS and fused→flood→fused reuse.
- One producer piece published per tick; delayed QP writes retain source pointers until completion, so premature source-buffer reuse is observable.
- 63,979,520 exact BF16 sum comparisons passed.
- 1,536 checks confirmed that the absent RS origin does not publish this operation's flags, exercising the proxy's missing-origin skip when the next flood arrives.
- Single-buffered fused raw/receive regions were reused across operations with one rank delayed, with exact results on every rank.
- Ring configurations confirm payload traffic on both directions of the wraparound link.

No concrete defect was found. Actual GPU/NIC loopback plus four-host serving validation remain the release gate.

## Ring cross-QP completion defect and fix

The first real GPU loopback exposed a defect not caught by the initial CPU harness: all four chain tests passed, and ring A2A/FP8/fused tests passed individually, but the mixed ring test reported 333,789 wrong values across 67 steps. A diagnostic rerun passed eager and captured-graph phases, then timed out during back-to-back stress at internal operation 120. These are preserved in `transport-gpu-profile-tests.log` and `ring-gpu-diagnostic-red.log`.

Ring floods and the retained linear specialized routes can deliver the same origin through different incoming QPs. For example origin2 reaches rank0 via rank1 for reduce-scatter, then via rank3 for the next flood. One shared completion word allowed the next operation's flag to overtake the current payload and satisfy its `flag >= sequence` wait. A late older flag could also overwrite the newer one and cause a timeout.

The regression now delays only the rank1→rank0 reduce-scatter QP independently. Against the original implementation all chain cases passed, then the first ring case failed at reduce-scatter sequence2/rank0/byte0 (BF16 bits49816 received,49819 expected). Receipt: `topology-cross-qp-red.log`. The previous fake QP scheduling reaped each rank's QPs together, which concealed this route crossover.

The fix assigns completion words to the existing payload parity slots: even sequence uses the first u64 and odd sequence the second u64 within each existing64-byte flag line. It changes no allocation sizes or arithmetic. Host chain sends/forwards and all chain GPU waits use the same address. TP2 retains its single-word ABI. Chain bootstrap magic is bumped to `ATLCHAN5` so old/new wire semantics cannot connect accidentally.

Additional engine files in this fix:

- `crates/spark-comm/src/nccl_backend/rdma_pair/oneshot.rs` — shared chain completion address helper.
- `crates/spark-comm/src/nccl_backend/rdma_pair/oneshot_tests.rs` — parity address and out-of-order completion regression.
- `kernels/gb10/common/rdma_oneshot.cu` — parity selection for multi-rank generic/gather/A2A/RS waits; R=2 unchanged.

Previously changed `oneshot/relay.rs`, `oneshot/relay/forward.rs` and `chain/bootstrap.rs` receive the corresponding host addresses and wire version. An independent source review found all chain reads/writes covered and no arithmetic changes.

With independent QP delay enabled, `topology-cross-qp-green.log` passes all32 tests in14.88seconds, including63,979,520 exact BF16 sums,1,536 absent-origin checks, both topologies,1/2rails, and each rank delayed in turn. Socket-enabled execution is required for the TCP bootstrap tests.

GPU check script: `gpu_transport_parity.py`; exact remote command: `gpu-transport-parity-command.sh`; source hashes: `transport-parity-source-hashes.json`. It first recompiles the original module and requires byte identity with the retained RC PTX, then applies only the six-file fix and recompiles the corrected module using exactly the same production flags. Original PTX SHA256: `403085c934a5ab1efe82211753906ad51dc3f3051b3d469201d89ff1ffbdee0b`. Corrected PTX SHA256: `a6fb26169f6cb6d37a7ffa9e97626f80b94aed304a3fe0a01bf4e758b46e14f2`. The unchanged BF16-add module retains SHA256 `ac9cd83a9b237d1101f2b7916d1cde3b3887cb20b04b62b2e4471f055f398f4f`.

The only test-only mutation changes the timing tail from1000 to3iterations; all correctness loops/assertions remain intact. No timing claim is made from loopback. All four tests run for chain and ring with production one-shot maximum, one channel,16RS blocks,16MiB fused segment, and PDL disabled for the one-GPU loopback. Final GPU results are recorded below.

## Final focused GPU result

`transport-gpu-parity-tests.log` and `transport-gpu-parity-tests-exit.json`: exit0; all eight transport tests passed in the retained candidate1 builder with only the reviewed fix applied. Chain4/4 passed in15.95seconds; ring4/4 passed in18.17seconds. The production parity unit test also passed.

| Check | Chain | Ring |
|---|---|---|
| A2A,4096rows | 0wrong bytes, no poison | 0wrong bytes, no poison |
| Mixed eager/graph/back-to-back,67steps | 0wrong values, no poison | 0wrong values, no poison |
| FP8 reduce-scatter,32KiB–8MiB | 0out-of-bound values | 0out-of-bound values |
| Fused reduce-scatter,64KiB–16MiB segments | 0wrong values | 0wrong values |

The FP8 test is its existing bounded-error comparison, not a claim of exact equality to full BF16. Generic and fused BF16 checks compare exact expected values. These are real NIC/GPU loopback tests on one Spark; they do not replace the parent's final four-host startup, wraparound-traffic and whole-model checks. Printed timing tails are diagnostic only and are not evidence of ring speedup.

Root centrally committed the fix as `494098191bbc716166f31de01beea7314f0b11d9` (tree `2aab2485e8a031950b26ac34f90d88d5364e2500`). The test archive preceded the root's repository formatter on `oneshot_tests.rs`; this only restored pre-existing whitespace. Runtime sources and CUDA kernel semantics match. The ephemeral `glm-parity-gpu-tests` container exited successfully with `--rm`; GPU01 was returned to the parent for candidate2 build. No host clocks, routes, reservations, or fabric settings were modified.

### Exact source bytes supplied to the GPU test

| File | SHA256 |
|---|---|
| `crates/spark-comm/src/nccl_backend/rdma_pair/oneshot.rs` | `cd96292cc4260f98eddd9beef78f9d060b9e341f422dbdc255c724742b25e98b` |
| `crates/spark-comm/src/nccl_backend/rdma_pair/oneshot_tests.rs` | `d925407af2063fee8f1694907a3e37e93f6db7d9cde843657dc35f9a18acc3e1` |
| `crates/spark-comm/src/nccl_backend/rdma_pair/oneshot/relay.rs` | `99ef4dde52142f41e013631cfd7c5bfcb48e4d3c6f5f9df41c92c7361746ca30` |
| `crates/spark-comm/src/nccl_backend/rdma_pair/oneshot/relay/forward.rs` | `e35dcdfb494551108f0bee5e7ee6132ff430356506bddfa8bab4217f739df16b` |
| `crates/spark-comm/src/nccl_backend/rdma_pair/chain/bootstrap.rs` | `d294d5e0368fcdd3275845dd05b6b3f6c5d34f5ce0ededf730b36faaa5dcb236` |
| `kernels/gb10/common/rdma_oneshot.cu` | `f20b9411c4dc007288a42c408dcee6787134216f9a3a0860b5195a53361daf4f` |

These identify the ephemeral tested archive. The final committed package may differ only in the noted formatter changes to the test file; the final builder must independently reproduce the corrected RDMA PTX hash above before whole-model qualification.
