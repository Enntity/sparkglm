set -euo pipefail
cd /build
python3 - <<'PATCH'
from pathlib import Path
p=Path('crates/spark-comm/src/nccl_backend/rdma_pair/chain_loopback_tests.rs')
s=p.read_text();assert s.count('for _ in 0..1000 {')==1
p.write_text(s.replace('for _ in 0..1000 {','for _ in 0..3 {'))
print('Work-only test change: timing-only tail reduced1000to3; correctness assertions unchanged; no timing claims')
PATCH
python3 - <<'DIAG'
from pathlib import Path
p=Path('crates/spark-comm/src/nccl_backend/rdma_pair/chain_loopback_tests.rs')
s=p.read_text().replace('#[derive(Clone, Copy, PartialEq)]','#[derive(Clone, Copy, Debug, PartialEq)]')
a='                got[from..][..len]\n                    .iter()\n                    .zip(&want[from..])\n                    .filter(|(a, b)| a != b)\n                    .count()'
b='                let bad: Vec<_> = got[from..][..len].iter().zip(&want[from..]).enumerate().filter(|(_, (a,b))| a != b).map(|(i,_)| i+from).collect();\n                if !bad.is_empty() { eprintln!("BAD k={k} {:?} bytes={} rank={rank} count={} first={:?} got/want={:?}", self.kind, self.bytes, bad.len(), &bad[..bad.len().min(8)], bad.iter().take(8).map(|&i| (got[i],want[i])).collect::<Vec<_>>()); }\n                bad.len()'
assert a in s;s=s.replace(a,b)
s=s.replace('        step.prepare(&g, *k);','        eprintln!("EAGER k={} {:?} bytes={}", *k, step.kind, step.bytes);\n        step.prepare(&g, *k);')
s=s.replace('    let execs = [0, 1, 2, 3].map','    eprintln!("GRAPH START");\n    let execs = [0, 1, 2, 3].map')
s=s.replace('    let drag = alloc(8 << 20);','    eprintln!("STRESS START");\n    let drag = alloc(8 << 20);')
p.write_text(s)
DIAG
export ATLAS_ONESHOT_CUBIN_DIR=/tmp/transport-test-kernels
mkdir "$ATLAS_ONESHOT_CUBIN_DIR"
for name in rdma_oneshot bf16_add; do
 ptx=$(find /build/target/release/build -name "t0__${name}.ptx" -print -quit)
 test -s "$ptx"
 cp "$ptx" "$ATLAS_ONESHOT_CUBIN_DIR/$name.cubin"
done
sha256sum "$ATLAS_ONESHOT_CUBIN_DIR/"*
export ATLAS_RDMA_ONESHOT=1 ATLAS_RDMA_PAIR_CHAIN=1 ATLAS_RDMA_LEFT_RAILS=rocep1s0f0,roceP2p1s0f0 ATLAS_RDMA_RIGHT_RAILS=rocep1s0f0,roceP2p1s0f0
export ATLAS_RDMA_ONESHOT_MAX=8388544 ATLAS_RDMA_RS_BLOCKS=16 ATLAS_RDMA_ONESHOT_SM_STAGE=1 ATLAS_RDMA_ONESHOT_PDL=0 ATLAS_ONESHOT_LOOPBACK_ROUNDS=1 ATLAS_ONESHOT_A2A_ROWS=4096 ATLAS_RDMA_ONESHOT_CHANNELS=1 ATLAS_RDMA_RS_FUSED_SEG=16777216
for topology in ring; do
 export ATLAS_RDMA_TOPOLOGY=$topology
 cargo test --locked --release -j 4 -p spark-comm --lib chain_loopback_four_ranks -- --ignored --nocapture --test-threads=1
done
