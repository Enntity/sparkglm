# SPDX-License-Identifier: AGPL-3.0-only
"""Operate only the unified RC containers on LLooM-reserved Sparks."""
import concurrent.futures as cf,io,json,re,subprocess,sys,tarfile,time
from pathlib import Path
from ops import *
WORK=ROOT.parent; PRODUCT=WORK/'glm-native-mtp-20261020/product'
STATE=ROOT/'cluster-state.json'
def image_id(host):return json.loads((ROOT/'image-host-identity.json').read_text())[host]['image_id']
NAMES=['atlas-sparkglm-unified-rank'+str(r) for r in range(4)]
LEFT=['rocep1s0f1,roceP2p1s0f1','rocep1s0f0,roceP2p1s0f0','rocep1s0f0,roceP2p1s0f0','rocep1s0f1,roceP2p1s0f1']
RIGHT=['rocep1s0f0,roceP2p1s0f0','rocep1s0f1,roceP2p1s0f1','rocep1s0f1,roceP2p1s0f1','rocep1s0f0,roceP2p1s0f0']
IFACE=['enP2p1s0f0np0','enP2p1s0f0np0','enP2p1s0f0np0','enP2p1s0f1np1']
def parallel(fn,hosts=HOSTS):
 with cf.ThreadPoolExecutor(len(hosts)) as pool:return list(pool.map(fn,hosts))
def state():return json.loads(STATE.read_text()) if STATE.exists() else {'owned':{},'pending':{},'clocks':[]}
def store(x):save('cluster-state.json',x)
def logs(s,host):
 cid=s['owned'].get(host)
 if not cid:return
 r=ssh(host,['docker','logs',cid],check=False)
 p=ROOT/s['arm'];p.mkdir(exist_ok=True)
 (p/(host+'-server.log')).write_bytes(r.stdout+r.stderr)
def attest(s,host):
 d=json.loads(ssh(host,['docker','inspect',s['owned'][host]]).stdout)[0]
 im=json.loads((ROOT/'final-image.json').read_text());assert d['Image']==image_id(host) and d['State']['Running']
 code="import pathlib,json,hashlib; rows=[]\nfor p in pathlib.Path('/proc').glob('[0-9]*/cmdline'):\n try:\n  a=p.read_bytes().split(b'\\0')\n  if a and a[0]==b'/usr/local/bin/spark':\n   e=dict(s.decode().split('=',1) for s in (p.parent/'environ').read_bytes().split(b'\\0') if b'=' in s); rows.append({'argv':[s.decode() for s in a if s], 'atlas_env':{k:v for k,v in e.items() if k.startswith('ATLAS_')}})\n except OSError:pass\nprint(json.dumps({'processes':rows,'source':json.loads(pathlib.Path('/opt/atlas/source-manifest.json').read_text()),'binary_sha256':hashlib.sha256(pathlib.Path('/usr/local/bin/spark').read_bytes()).hexdigest()}))"
 x=json.loads(ssh(host,['docker','exec',d['Id'],'python3','-c',code]).stdout)
 assert x['binary_sha256']==im['hashes']['/usr/local/bin/spark'] and x['source']==im['source'] and len(x['processes'])==1
 policy=x['processes'][0]['atlas_env'];assert policy['ATLAS_GLM_SERVING_MODE']==s['mode']
 if s['world']==4:assert policy['ATLAS_RDMA_TOPOLOGY']==s['topology']
 if s['mode']=='spark':assert policy['ATLAS_GLM_SHARED_TP_SPLIT']=='0'
 if s['native']:assert policy['ATLAS_GLM_STRICT_NATIVE_MTP']=='1'
 x.update(host=host,container_id=d['Id'],started=d['State']['StartedAt'],image=d['Image'],inspect=d)
 x['clock_service']=ssh(host,['systemctl','show','gpu-clock-cap.service','--property=ActiveState','--value']).stdout.decode().strip();assert x['clock_service']=='inactive'
 x['memory']=ssh(host,['cat','/proc/meminfo']).stdout.decode();x['gpu']=ssh(host,['nvidia-smi','-q']).stdout.decode()
 save(s['arm']+'/'+host+'-identity.json',x);logs(s,host);return x

def stage(host):
 image=json.loads((ROOT/'final-image.json').read_text())
 assert ssh(host,['docker','image','inspect','--format','{{.Id}}',image_id(host)]).stdout.decode().strip()==image_id(host)
 assert not ssh(host,['docker','ps','-q']).stdout.strip(),'Unexpected container '+host
 ssh(host,['mkdir','-p',STAGE+'/validation'])
 data=io.BytesIO()
 files={'start-node.sh':ROOT/'context/install/start-node.sh','short_parity.py':WORK/'glm-focused-fixes-r3-20261020/short_parity.py',
 'capacity-prompt.txt':WORK/'glm-tp2-rc-validation-20261020/repair/results/strict-repaired-normal/capacity/prompt.txt'}
 for name in ('smoke.py','capacity.py','nvme_probe.py','quick_speed.py','bench.py','prompts.json','shared-baseline.json','rc4-baseline.json','cases.json','grader.py','check_code.py'):
  if (ROOT/name).exists():files[name]=ROOT/name
 if state().get('profile_override'):files['diagnostic-profile.json']=ROOT/state()['profile_override']
 with tarfile.open(fileobj=data,mode='w') as archive:
  for name,path in files.items():archive.add(path,arcname=name)
 ssh(host,['tar','-xf','-','-C',STAGE+'/validation'],data.getvalue())
 return host

def start(mode,topology,world=4,native=False,util=None,profile_override=None,suffix=''):
 s=state();assert not s['owned'] and not s['pending']
 active=HOSTS[:world];image=json.loads((ROOT/'final-image.json').read_text())
 s.update(mode=mode,topology=topology,world=world,native=native,arm=f'tp{world}-{topology}-{mode}'+('-native' if native else '-serial' if mode=='strict' else ''),util=util or ('0.72' if world==4 else '0.91'))
 s.update(profile_override=profile_override,arm=s['arm']+('-'+suffix if suffix else ''))
 assert not (ROOT/s['arm']).exists(),'Use fresh arm name';(ROOT/s['arm']).mkdir();store(s)
 renew();note('Loading '+s['arm']+' for focused qualification')
 parallel(stage,active)
 for h in active:
  assert ssh(h,['systemctl','show','gpu-clock-cap.service','--property=ActiveState','--value']).stdout.strip()==b'active' or h in s['clocks']
  if h not in s['clocks']:s['clocks'].append(h);store(s)
  ssh(h,['sudo','-n','/usr/bin/systemctl','stop','gpu-clock-cap.service'])
 for rank in reversed(range(world)):
  h=HOSTS[rank];name=NAMES[rank];assert not ssh(h,['docker','ps','-aq','--filter','name=^/'+name+'$']).stdout.strip()
  args=['bash',STAGE+'/validation/start-node.sh','--mode',mode,'--rank',str(rank),'--world-size',str(world),
   '--leader-address','10.100.193.2','--model-root','/home/enntitysparkadmin/.lloom/models','--image',image_id(h),
   '--name',name,'--profile',STAGE+'/validation/diagnostic-profile.json' if profile_override else ('4x1m-tp4' if world==4 else '4x1m'),'--fabric-interface',IFACE[rank],
   '--cuda-cache','/home/enntitysparkadmin/.cache/atlas-cuda','--gpu-memory-utilization',s['util'],
   '--kv-shard','--display-carveout']
  args+=['--prefix-cache-dir',STAGE+'/prefix-cache-'+s['arm'],'--prefix-cache-gb','48']
  if world==4:
   args+=['--topology',topology]
   if rank>0 or topology=='ring':args+=['--left-hca',LEFT[rank]]
   if rank<3 or topology=='ring':args+=['--right-hca',RIGHT[rank]]
  else:args+=['--fabric-hca','roceP2p1s0f0,rocep1s0f0']
  if native:args+=['--strict-mtp']
  save(s['arm']+'/'+h+'-launch.json',args);s['pending'][h]=name;store(s)
  r=ssh(h,args);save(s['arm']+'/'+h+'-launch-result.json',{'stdout':r.stdout.decode(),'stderr':r.stderr.decode()})
  s['owned'][h]=ssh(h,['docker','inspect','--format','{{.Id}}',name]).stdout.decode().strip();del s['pending'][h];store(s)
 deadline=time.monotonic()+900;last=time.monotonic()
 while ssh('ennspark01',['curl','-fsS','--max-time','2','http://127.0.0.1:8893/health'],check=False).returncode:
  assert time.monotonic()<deadline,'Startup timeout'
  for h in active:
   if ssh(h,['docker','inspect','--format','{{.State.Running}}',s['owned'][h]]).stdout.strip()!=b'true':
    for host in active:logs(s,host)
    raise RuntimeError('Startup failed '+h)
  if time.monotonic()-last>100:renew();note('Loading '+s['arm']+'; process remains alive');last=time.monotonic()
  time.sleep(3)
 parallel(lambda h:attest(s,h),active);print('Ready',s['arm'],flush=True)

def stop_models():
 s=state();image=json.loads((ROOT/'final-image.json').read_text())
 for h,name in list(s['pending'].items()):
  r=ssh(h,['docker','inspect',name],check=False)
  if r.returncode==0:
   d=json.loads(r.stdout)[0];assert d['Image']==image_id(h);s['owned'][h]=d['Id']
  del s['pending'][h];store(s)
 for h,cid in list(s['owned'].items()):
  d=json.loads(ssh(h,['docker','inspect',cid]).stdout)[0];assert d['Image']==image_id(h) and d['Name']=='/'+NAMES[HOSTS.index(h)]
  logs(s,h);ssh(h,['docker','rm','-f',cid]);del s['owned'][h];store(s)
 print('Owned test containers stopped')

def collect():
 r=ssh('ennspark01',['tar','-cf','-','-C',STAGE+'/validation','results'],check=False)
 if r.returncode==0:
  with tarfile.open(fileobj=io.BytesIO(r.stdout)) as archive:archive.extractall(ROOT,filter='data')

if __name__=='__main__':
 action=sys.argv[1]
 if action=='start':start(sys.argv[2],sys.argv[3],int(sys.argv[4]) if len(sys.argv)>4 else 4,'--native' in sys.argv)
 elif action=='stop':stop_models();collect()
 elif action=='collect':collect()
 elif action=='attest':s=state();parallel(lambda h:attest(s,h),list(s['owned']))
 else:raise ValueError(action)
