#!/bin/bash
set -euo pipefail
cargo test --locked --release -j 4 -p spark-runtime --lib nvme -- --nocapture
cargo test --locked --release -j 4 -p spark-model --lib kv_nvme -- --nocapture
cargo build --locked --release -j 4 -p spark-server
