# SPDX-License-Identifier: AGPL-3.0-only
"""Freeze and build only the validated shared-prefix protection policy delta."""
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile
from ops import ROOT, STAGE, ssh, save, renew, note

PRODUCT = ROOT.parent / 'glm-native-mtp-20261020/product'
ENGINE = ROOT.parent / 'glm-native-mtp-20261020/engine'
OLD = ROOT / 'candidate-03'
CTX = ROOT / 'context'


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()


if '--resume' not in sys.argv:
    state = json.loads((ROOT / 'cluster-state.json').read_text())
    assert not state['owned'] and not state['pending']
    assert not git(PRODUCT, 'status', '--porcelain', '--', 'install')
    assert not git(ENGINE, 'status', '--porcelain')
    proof = json.loads((ROOT / 'results/tp4-chain-strict-native-write-floor/nvme-probe/result.json').read_text())
    assert proof['passed'] and proof['storage_passed'] and proof['cold_warm_exact']
    previous = json.loads((ROOT / 'final-image.json').read_text())
    assert previous['source']['commit'] == git(ENGINE, 'rev-parse', 'HEAD')
    profiles = sorted((PRODUCT / 'install/profiles').glob('*.json'))
    for path in profiles:
        old = json.loads((CTX / 'install/profiles' / path.name).read_text())
        new = json.loads(path.read_text())
        expected = json.loads(json.dumps(old))
        expected['environment']['ATLAS_GLM_PC_WRITE_FLOOR'] = '1'
        assert new == expected, path.name
    OLD.mkdir()
    for name in ('context', 'context.tar', 'build-plan.json', 'final-image.json',
                 'builder-build.log', 'builder-build-exit.json', 'runtime-build.log',
                 'runtime-build-exit.json', 'image-host-identity.json', 'final-static.json'):
        shutil.move(ROOT / name, OLD / name)
    CTX.mkdir()
    shutil.copytree(PRODUCT / 'install', CTX / 'install', ignore=shutil.ignore_patterns('__pycache__'))
    shutil.copy2(OLD / 'context/source-hashes.json', CTX / 'source-hashes.json')
    (CTX / 'root-fixtures').mkdir()
    for name in ('fabric.py', '.env.example', 'start.sh'):
        shutil.copy2(PRODUCT / name, CTX / 'root-fixtures' / name)
    install = git(PRODUCT, 'rev-parse', 'HEAD:install')
    plan = dict(commit=previous['source']['commit'], tree=previous['source']['tree'],
                product_commit=git(PRODUCT, 'rev-parse', 'HEAD'), install_tree=install,
                image='localhost/atlas-sparkglm:unified-rc-' + install[:12],
                builder_tag='localhost/atlas-glm-unified-builder:' + install[:12],
                builder_base=previous['builder_tag'], builder_base_id=previous['builder_id'],
                runtime_base=previous['tag'], runtime_base_id=previous['image_id'],
                changed_source=[], qualification_delta='Protect matched prefix blocks in all four release profiles; engine and native libraries unchanged')
    (CTX / 'Dockerfile').write_text(f'''# SPDX-License-Identifier: AGPL-3.0-only
    FROM {plan['builder_base']} AS builder
    COPY install/ /product/install/
    COPY root-fixtures/ /product/
    RUN python3 -m unittest discover -s /product/install -p 'test_*.py' -v
    FROM {plan['runtime_base']}
    COPY install/profiles/ /opt/atlas/profiles/
    LABEL io.enntity.sparkglm.install-tree="{install}" io.enntity.sparkglm.engine-commit="{plan['commit']}" io.enntity.sparkglm.local-rc="true"
    ''')
    with tarfile.open(ROOT / 'context.tar', 'w') as archive:
        for path in CTX.iterdir():
            archive.add(path, arcname=path.name)
    plan['context_sha256'] = hashlib.sha256((ROOT / 'context.tar').read_bytes()).hexdigest()
    save('build-plan.json', plan)
else:
    state = json.loads((ROOT / 'cluster-state.json').read_text())
    assert not state['owned'] and not state['pending']
    previous = json.loads((OLD / 'final-image.json').read_text())
    plan = json.loads((ROOT / 'build-plan.json').read_text())
    install = plan['install_tree']
renew()
note('Packaging verified matched-prefix write protection; engine binary and native kernels unchanged')
for tag, key in ((plan['builder_base'], 'builder_base_id'), (plan['runtime_base'], 'runtime_base_id')):
    assert ssh('ennspark01', ['docker', 'image', 'inspect', '--format', '{{.Id}}', tag]).stdout.decode().strip() == plan[key]
remote = STAGE + '/config-build-' + install[:12]
ssh('ennspark01', ['mkdir', '-p', remote])
with (ROOT / 'context.tar').open('rb') as src:
    ssh('ennspark01', ['tar', '-xf', '-', '-C', remote], stdin=src, stdout=subprocess.DEVNULL)
for target, tag in (('builder', plan['builder_tag']), (None, plan['image'])):
    label = 'builder' if target else 'runtime'
    args = ['docker', 'build', '--pull=false', '--progress=plain', '-t', tag]
    if target:
        args += ['--target', target]
    with (ROOT / (label + '-build.log')).open('wb') as log:
        result = ssh('ennspark01', args + [remote], stdout=log, stderr=subprocess.STDOUT, check=False)
    save(label + '-build-exit.json', {'code': result.returncode})
    assert result.returncode == 0
image = ssh('ennspark01', ['docker', 'image', 'inspect', '--format', '{{.Id}}', plan['image']]).stdout.decode().strip()
builder = ssh('ennspark01', ['docker', 'image', 'inspect', '--format', '{{.Id}}', plan['builder_tag']]).stdout.decode().strip()
code = """import pathlib,json,hashlib
paths=[pathlib.Path('/usr/local/bin/spark'),pathlib.Path('/opt/atlas/serve.py'),*pathlib.Path('/opt/atlas/native').glob('*.so'),*pathlib.Path('/opt/atlas/profiles').glob('*.json')]
print(json.dumps({'source':json.loads(pathlib.Path('/opt/atlas/source-manifest.json').read_text()),'hashes':{str(p):hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in paths}}))"""
actual = json.loads(ssh('ennspark01', ['docker', 'run', '--rm', '--runtime=runc', '--network=none', '--memory', '128m', '--entrypoint', 'python3', image, '-c', code]).stdout)
assert actual['source'] == previous['source']
for name, digest in actual['hashes'].items():
    if name.startswith('/opt/atlas/profiles/'):
        assert digest == hashlib.sha256((PRODUCT / 'install/profiles' / name.rsplit('/', 1)[-1]).read_bytes()).hexdigest()
    else:
        assert digest == previous['hashes'][name], name
save('final-image.json', dict(image_id=image, tag=plan['image'], builder_id=builder,
     builder_tag=plan['builder_tag'], source=actual['source'], hashes=actual['hashes'],
     install_tree=install, product_commit=plan['product_commit']))
print('Configuration-only image built; binary, source and native libraries unchanged:', image)
