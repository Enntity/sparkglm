# Independent TP4 topology review

Reviewed transport commit `bc7fceac8` plus formatting through `4abf199ce` in the shared engine. Read-only review; no engine edits or commits. Result: **no concrete source blocker found**. Hardware qualification remains necessary before claiming the new ring transport is release-qualified.

## Findings

- **Bootstrap agreement is explicit.** `ATLCHAN4` rejects an old wire layout before reading the longer head. The head includes topology in its agreement fields. All peers must agree before any QP connection callback runs. Ring requires four ranks and rails on both sides; `check_links` checks the closing 3-right/0-left edge too. Neighbor identities select the peer's opposite side, including both wraparound directions.
- **Mixed topology does not proceed into incompatible QPs.** A mismatched peer is rejected; the leader stops on peer lifeline closure or the bounded bootstrap deadline. The default deadline is two minutes, so an operator may see a wait before failure, but this is not an unbounded collective hang. The existing mismatch test proves zero connection callbacks.
- **All four ranks receive each flood payload exactly once.** Every origin sends directly to its two neighbors. Only its clockwise neighbor forwards once, reaching the opposite rank in two hops. This uses the 0–3 cable and avoids duplicate flags or a forwarding loop. Recipient slots are recomputed with `origin_slot(origin, recipient)` for both own writes and forwards, which is essential across wraparound.
- **Specialized arithmetic stays on the existing linear route.** Reduce-scatter, its FP8/fused variants, and all-to-all continue to select the chain route. Their own sends only select non-wrap linear edges, so using the ring neighbor helper there resolves to the same peer as before. Commands still travel 0→1→2→3 and terminate at rank 3.
- **Sequence and completion ownership are accounted for.** Forwarded operations retain per-origin sequence state; reduce-scatter origins which send no data to a rank are skipped from its own issued size record. Forward flag-source reuse waits on the stored QP side and rail from the old ticket before overwriting the source word. Fused completion uses the current linear forwarding side after the current sequence is posted. The two-slot argument still depends on every rank's collective dependencies; ring flood changes the forwarding path without removing those dependencies.
- **No arithmetic change was introduced by transport.** The collective methods moved into `chain/collectives.rs` are identical after whitespace removal. Commit `bc7fceac8` changes no CUDA kernels. The four-rank all-reduce still sums `(x0 + x1) + (x2 + x3)` in the kernel; reduce-scatter keeps the same pairing. Earlier FP8 reduce-scatter remains a separate, already lossy option and is not made lossless by this transport change.

## Independent validation

Ran the existing CPU harness against the production topology/bootstrap/relay sources: **31 passed, 0 failed**. Evidence: `topology-review-tests.log`. Initial sandbox run denied localhost TCP listeners; the same tests passed with local sockets allowed. This was an environment restriction, not a test or transport defect.

The asynchronous fake-QP relay test checks real payload bytes across 48 back-to-back operations per case, delayed ranks, chain/ring, one/two rails, pipelined/non-pipelined staging, and flood/all-to-all transitions. It keeps source pointers live until completion, which exercises flag-source lifetime. These tests do not reproduce GPU/NIC coherency, RDMA failure propagation, or actual command dispatch.

## Focused remaining checks

1. The topology author subsequently added and passed the mixed flood/reduce-scatter/fused-reduce-scatter harness (`topology-mixed-relay.log`): 16 configurations (chain/ring, one/two rails, each of four ranks delayed), 48 operations/rank, 63,979,520 exact BF16 tree-sum checks, and 1,536 missing-origin checks. It includes consecutive RS and fused→flood→fused transitions. Production source stayed unchanged. This closes the identified CPU transition-coverage gap; GPU/NIC qualification below remains required.
2. On the four reserved Sparks, run the production communication canary for exact BF16 all-reduce/reduce-scatter/gather, fused seam traffic, and command delivery in both chain and ring. Include graph replay and repeated mixed sizes/operations; compare outputs exactly. Verify actual logs report ring on all ranks and the wrap link carries traffic.
3. Reuse the focused model canaries already required for the TP4 RC. A short same-build chain/ring comparison can establish that the physical routing change preserves outputs. Do not infer a percent speed gain from hop count alone.

Minor documentation debt only: `oneshot.rs`'s `origin_slot` comment says a payload keeps its slot index along the way; that description is no longer generally true across the ring wrap, although the new implementation explicitly recomputes the correct slot. Existing chain-only relay prose also omits ring behavior.
