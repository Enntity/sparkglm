# SPDX-License-Identifier: AGPL-3.0-only
import hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent
ENGINE=WORK/'glm-native-mtp-20261020/engine';PRODUCT=WORK/'glm-native-mtp-20261020/product';CTX=ROOT/'context'
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
assert not git(ENGINE,'status','--porcelain')
assert not git(PRODUCT,'status','--porcelain','--','install')
CTX.mkdir()
old=json.loads((WORK/'glm-focused-fixes-r2-20261020/context/source-hashes.json').read_text())
roots=('crates/','kernels/','vendor/','jinja-templates/','test_data/','bench/ngram_ref/','scripts/dev/glm_sparse_native/')
hashes={f:hashlib.sha256((ENGINE/f).read_bytes()).hexdigest() for f in git(ENGINE,'ls-files').splitlines() if (f.startswith(roots) or f in ('Cargo.toml','Cargo.lock','rust-toolchain.toml')) and (ENGINE/f).is_file()}
assert not set(old)-set(hashes),set(old)-set(hashes)
changed=[]
for f,digest in hashes.items():
 if old.get(f)!=digest:
  dest=CTX/'patch'/f;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ENGINE/f,dest);changed.append(f)
(CTX/'source-hashes.json').write_text(json.dumps(hashes,sort_keys=True)+'\n')
(CTX/'changed-files.json').write_text(json.dumps(changed)+'\n')
for name in ('verify_source.py','touch_changed.py'):shutil.copy2(WORK/'glm-focused-fixes-r2-20261020/context'/name,CTX/name)
shutil.copytree(PRODUCT/'install',CTX/'install',ignore=shutil.ignore_patterns('__pycache__'))
commit,tree=git(ENGINE,'rev-parse','HEAD'),git(ENGINE,'rev-parse','HEAD^{tree}');install=git(PRODUCT,'rev-parse','HEAD:install')
assert json.loads((CTX/'install/atlas-source.json').read_text())['commit']==commit
plan={'commit':commit,'tree':tree,'product_commit':git(PRODUCT,'rev-parse','HEAD'),'install_tree':install,
'image':'localhost/atlas-sparkglm:unified-rc-'+install[:12],
'builder_base':'localhost/atlas-glm-focused-builder-r2:20261020','builder_base_id':'sha256:d855c4572e46895f35613119945aa4863cf1c8e41ff34ea5967d96b36cd40336',
'builder_tag':'localhost/atlas-glm-unified-builder:'+install[:12],
'runtime_base':'localhost/atlas-sparkglm:focused-fixes-87400d08a4fe','runtime_base_id':'sha256:147c059d5229338f44bed47020334fcab914cda14b128736968d67d53017018d',
'changed_source':changed,'verified_source_files':len(hashes)}
tests=[('spark-comm','chain::'),('spark-comm','oneshot::relay'),('spark-model','glm_sparse_native'),('spark-model','glm_native'),('spark-model','native_target_prerequisites'),('spark-model','weight_loader::glm5::mtp'),('spark-model','native_mtp_prefix::admission'),('spark-model','glm5_mtp'),('spark-server','glm_chain'),('spark-server','preflight::independent::tests::long_context'),('spark-server','scheduler::admission')]
script='#!/bin/bash\nset -euo pipefail\n'
for pkg,flt in tests:
 script+=f'cargo test --locked --release -j 4 -p {pkg} {"--lib" if pkg!="spark-server" else "--bin spark"} {flt} -- --nocapture\n'
script+='cargo test --locked --release -j 4 -p spark-model --lib glm_mla_fuse --no-run\ncargo build --locked --release -j 4 -p spark-server\n'
(CTX/'test-build.sh').write_text(script)
(CTX/'Dockerfile').write_text(f'''# SPDX-License-Identifier: AGPL-3.0-only
FROM {plan['builder_base']} AS builder
WORKDIR /build
COPY patch/ /build/
COPY changed-files.json touch_changed.py source-hashes.json verify_source.py test-build.sh /tmp/
COPY install/ /product/install/
RUN python3 /tmp/touch_changed.py && python3 /tmp/verify_source.py
RUN bash /tmp/test-build.sh
RUN ATLAS_BUILD_SPARSE_ONLY=1 bash /product/install/build-native.sh /build /opt/flashinfer /product /opt/atlas/native
FROM {plan['runtime_base']}
COPY --from=builder /build/target/release/spark /usr/local/bin/spark
COPY --from=builder /opt/atlas/native/libatlas_glm_sparse_native.so /opt/atlas/native/libatlas_glm_sparse_native.so
COPY --from=builder /opt/atlas/native/native-libraries.sha256 /opt/atlas/native/native-libraries.sha256
COPY install/serve.py /opt/atlas/serve.py
COPY install/profiles/ /opt/atlas/profiles/
COPY install/atlas-source.json /opt/atlas/source-manifest.json
LABEL io.enntity.sparkglm.install-tree="{install}" io.enntity.sparkglm.engine-commit="{commit}" io.enntity.sparkglm.local-rc="true"
''')
with tarfile.open(ROOT/'context.tar','w') as archive:
 for p in CTX.iterdir():archive.add(p,arcname=p.name)
plan['context_sha256']=hashlib.sha256((ROOT/'context.tar').read_bytes()).hexdigest();(ROOT/'build-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({k:v for k,v in plan.items() if k!='changed_source'}));print('Changed',len(changed))
