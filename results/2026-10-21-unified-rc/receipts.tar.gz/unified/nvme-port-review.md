# TP4 NVMe prefix-cache review

Read-only source review of the in-progress port owned by tp4_native_mtp. No source edits, test reruns or hardware access by this reviewer. No production blocker found in the reviewed changes.

## Invariants checked

- TP2 preserves record layout, the one-full-plus-one-peer budget, slot parity, file naming and synchronous/fast byte movement. Its startup fingerprint intentionally changes to include component geometry; all ranks must run the same build. Unsharded startup words remain unchanged.
- TP4 uses exactly four residue classes. Each rank budgets one full record plus three peer index-only records per row; all four lanes' pinned staging and all four classes' host metadata are reserved. Record sizes include their existing alignment/trailer overhead. The global slot cap reserves the u32 sentinel.
- The preallocation geometry receives the actual shard world. At attachment, exact geometry and latent owner rank must match the actual cache before any class files are created. Own class is class==rank; all other classes use the peer record size.
- A global slot maps to class=slot%world and local record=slot/world. Physical allocation preserves logical-index residue; the fast read only sorts blocks within one class. Latent byte addresses use block/world while replicated index rows use the global block id.
- Restoring several lanes returns the earliest failed global prefix position. Each record retains magic, tag and payload checksum verification. The caller adopts only verified leading blocks and returns all unused allocations; rank agreement caps the matched length to the minimum across the actual communicator. Missing, stale, truncated or misdirected records therefore fall back to recomputation.
- Eviction scans a disk tail no deeper than classes-1. Every node must be on disk and unpinned; any resident or pinned descendant rejects the whole victim. The recursive count matches the full subtree removed, including branches. Depth0 with no children does not evaluate depth-1. TP2 remains the one-descendant case.
- Restore pins protect the full path. Full-block-only prefix adoption and per-logical-index allocation remain unchanged. Kept records are invalidated before equivalent-value rewrites; ordinary cache/sequence reference handling is unchanged.

## Evidence and remaining qualification

Read `nvme-runtime-green.log`: 62 tests passed, zero failed, one pre-existing ignored test, including the new TP4 geometry, four-lane roundtrip/fault-prefix and multi-descendant eviction checks. The implementation owner has since added TP4 pinned-tail and branched-tail tests, model-level repeated restore/keep tests, common-prefix capping, pre/post allocation geometry checks and real-file TP2/TP4 attachment coverage. Their results remain the owner's responsibility.

At this review snapshot `nvme-model-green.log` contains an unsuccessful local build: the broader test target references disabled CUDA items, and two new tests needed the ModelResource trait import. The latter was reported to the owner. This is not a passing model-test receipt. Root still needs the final Linux build and affected serving checks; source review and mock-GPU byte tests do not establish actual four-host NVMe restore behavior or performance.

No additional performance campaign is proposed. Existing paired behavior should be checked by the focused regression suites already in flight.

Reviewed working-diff SHA256 at report creation: `4d370cb60398336178d0f4a84fe4a932232fc281eec55e8b84e307d76ca3e5f7`. The owner is still editing tests and formatting; this identifies a review snapshot rather than the final package.
