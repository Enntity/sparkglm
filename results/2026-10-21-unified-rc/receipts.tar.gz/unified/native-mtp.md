# Native MTP TP4 implementation and review

Implementation is ready for the root agent's cached Linux build and GPU qualification. No GPU hosts, reservations, product files, or commits were changed by this agent.

## Changes

- Added one explicit-mode/native-target topology boundary: overlapping TP=EP=world 2 or 4. The target weight loader, native factory, canonical decode runtime, and server preflight use it. Mismatched rank identity and out-of-range ranks are refused by native factory/runtime dispatch.
- Native Strict supports C1 through C4, full checkpoint context, and prefix caching on TP4. It preserves the exact TP2 eager-memory policy and equal admitted/active limits; no TP2 numeric kernel or native private-pool sizing changed.
- Added production tests for every TP2/TP4 rank's factory admission, all four TP4 rank-local preflight budgets at C1..C4 and 1,048,576 context, full 64-head predictor geometry, EH/MLA/index scratch sizes, and every TP4 rank's ability to veto a stale/missing shared-prefix snapshot.

## Audited reusable behavior

This port does not need a new distributed predictor. `glm5_mtp_draft_config` restores checkpoint-wide attention/KV heads (16 local heads x 4 = 64), sets TP=EP=1, and preserves all 288 experts. Only rank zero loads and executes that full native predictor; its `BufferArena` comes from the restored config, not the target's 16-head workspace. Private KV and prefix/COW state stay request-owned on rank zero.

Every target rank retains `native_glm_mtp=true`. EP protocol v2 broadcasts owner identity/commands across the actual communicator; four-rank vocabulary shards already gather full logit rows before native sampling. Owner-batched verification already admits TP4 through the sparse-TC geometry and row budget. Prefix admission proves the current target snapshot on every rank through `ep_min_u32`, which gathers all communicator members (or loops over the full world as fallback). Private predictor capacity is separately checked on the head. Cancellation and reuse retain the existing request lifecycle.

`ATLAS_GLM_MTP_DISTRIBUTED=1` in server `weights.rs` is an older experimental mirrored predictor/repair lane, not the native Strict path. Its TP2 restriction and TP4 preflight refusal remain intentionally intact. Enabling it is not required for native TP4.

## Validation completed locally

- `native-topology-red.log`: the TP4 admission test fails with the prior TP2-only boundary; negative-topology test passes.
- `native-topology-green.log`: same production module/tests pass after the boundary change (2/2).
- Full default-feature `spark-model --lib` tests compiled successfully on macOS (including the new Rust tests), then failed at link because macOS has no `libcuda`; see `native-topology-cargo.log`. This is a compilation receipt, not executed cargo-test evidence.
- An initial no-default-feature host test attempt stopped at pre-existing `deny(warnings)` unused CUDA-only runtime helpers; no unrelated workaround was added.
- `git diff --check` passes. Modified Rust files remain under 500 lines, apart from existing allow-listed parents.

Root should execute in the production Linux builder:

```
cargo test --locked --release -p spark-model --lib glm_native
cargo test --locked --release -p spark-model --lib native_target_prerequisites
cargo test --locked --release -p spark-model --lib weight_loader::glm5::mtp
cargo test --locked --release -p spark-model --lib native_mtp_prefix::admission
cargo test --locked --release -p spark-model --lib glm5_mtp
cargo test --locked --release -p spark-server preflight::independent::tests::long_context
cargo test --locked --release -p spark-server scheduler::admission
```

## Required focused GPU checks

1. TP4 Strict native MTP versus the same build/topology with request-level `disable_mtp=true`: short C1/C4 exact greedy IDs, seeded sampling with logprobs, and tool/structured path coverage. Use serial on the same KV-sharding setting and topology.
2. Cached identical/distinct branches, all four resident owner slots, exact serial controls, cancellation/reuse. Decode width may temporarily be below four while owners are prefilling; use the corrected resident-concurrency oracle.
3. Near-1M cold context and four shared-prefix branches with rank-zero private-pool accounting and available-memory sampling on all four ranks. Recompute TP4 capacity from actual loader/free-memory receipts rather than copying TP2's cap.
4. Chain and ring each need at least the cached C4 native/serial canary. Do not require TP2 versus TP4 or chain versus ring token identity: the distributed reduction ordering may differ. Check native versus serial within each actual configuration.

## Shared-expert split decision

The TP4 split uses the same BF16 partial-down outputs and pre-allreduce shared blend as TP2, divided into quarters rather than halves. The existing implementation is not the proposed FP32 split. Corrected FP4 weight rounding does not remove that summation/rounding difference. The TP2 arithmetic miss was causally isolated with split on/off; TP4 has not received that causal test.

For the initial unified RC, split off is the defensible baseline for both modes. Restoring TP4 Spark splitting requires an isolated off/on arithmetic/quality check and quick same-prompt timing showing a meaningful benefit. Do not claim the TP2 1.7% measurement describes TP4 or that passing a short test makes the split bit-exact. This is a policy choice/root-owned product change, not an engine edit made here.

## Remaining TP2-only paths and silent fallbacks

- `ATLAS_GLM_K5_FUSED_TP_HC`: `glm5_kda/forward_attention.rs` requires TP2 peer exchange. However it also requires noncanonical K5 execution; the new canonical RC lane already bypasses it on TP2 as well. Its enabled legacy profile flag does not prove an active optimization.
- `ATLAS_GLM_TP_VERIFY_GRAPH` / `ATLAS_GLM_MTP1_VERIFY_GRAPH`: TP2-only graph admission. Native Strict eager memory accounting rejects these on both topologies, so there is no native TP2 optimization to port here.
- `ATLAS_GLM_KV_CANONICAL`: the unsharded canonical emulation is a pair-specific 32-head/two-part merge and silently declines TP4. TP4 KV-sharded attention has a separate four-rank implementation. Preserve sharding within comparisons; do not simply loosen this guard.
- Independent/non-speculative indexed C4 KDA remains TP2-only (32 local heads). The RC native and DFlash modes use owner-batched verification, and the old independent/C4 flags are already off; porting this unused alternative is not needed for mode parity.
- Native B-tile gate/up profile guards are TP2-only, but the code explicitly has no serving/environment activation caller. It is staged experimental work, not an optimization currently enabled in the TP2 RC.
- DFlash split draft, vocabulary split, sequence-parallel gathers, sparse TC, and latent-cache sharding already have explicit four-rank implementations. New native-FP8 MLA fusion and 16-head sparse-native library work are owned by the attention agent.
- The optional block-level NVMe KV tier (distinct from disk prefix caching) rejects TP4 with latent sharding; the unified package must not enable that old pair-only combination accidentally.

## Changed files owned by this agent

```
crates/spark-model/src/factory/build.rs
crates/spark-model/src/factory/build/glm_native_mtp.rs
crates/spark-model/src/layers/glm_native.rs
crates/spark-model/src/layers/glm_native/mode.rs
crates/spark-model/src/layers/glm_native/topology.rs
crates/spark-model/src/model/native_mtp_prefix/admission.rs
crates/spark-model/src/model/trait_impl/decode_canonical.rs
crates/spark-model/src/model/trait_impl/verify_d.rs
crates/spark-model/src/weight_loader/glm5/layers.rs
crates/spark-model/src/weight_loader/glm5/mtp.rs
crates/spark-server/src/main_modules/serve_phases/preflight.rs
crates/spark-server/src/main_modules/serve_phases/preflight/independent/long_context_tests.rs
crates/spark-server/src/scheduler/admission_native.rs
```
