# NVMe replay divergence: storage-side audit

Source reviewed: engine d3620ffba. Read-only; no production/test source edits, hardware access or builds by this reviewer.

No concrete four-class storage defect found. Checked global slot class/local-record mapping, own/peer segment layout, physical-block residue preservation, per-lane block sorting, pitched DMA strides, staging ownership, write-behind flushes, scatter completion, restore-prefix adoption and disk-tail eviction.

- Global slot s maps to lane s%4 and local record s/4. Latent regions use physical block/4 only on the owner; index regions use the global physical block. Every restored allocation preserves its logical residue.
- Fast writes device-synchronize before gathering. Read waits for that lane's queued writes; scatter stream-synchronizes before handing its staging chunk back. The restored prefix is the earliest verified global position across all lanes.
- Restored raw-tail maps are published before replay. Raw tails are intentionally absent from a full-block spill; all finalized pooled index rows are included. A restored block's NO_TAIL prevents pooled-index recomputation, but does not prevent the latent-write path from changing that shared block when its write floor is zero.
- Production real-CUDA/file test passed all four rank geometries on sync and fast paths, with exact401408bytes and stale class3-tag failure at the correct prefix boundary. That test has8blocks and2layers. Live replay has160blocks starting at logical97 and11attention layers, so the small fixture does not alone exclude size- or later-mutation-specific failures.

## Confounding shared-prefix overwrite confirmed in source and receipt

All four pressure requests in `results/tp4-chain-strict-native-nvme-replay/nvme-probe/cycle1-pressure*-rank0.log` report a16-token/1-block prefix match without an SSM snapshot and recompute all KV. `pc_policy.rs` enables recompute-all write-floor protection only when ATLAS_GLM_PC_WRITE_FLOOR=1; absent that setting, `paged_glm_front.rs` can rewrite those still-shared latent rows. This requires no NVMe eviction. Root's clean single-pressure/no-restore control is therefore the first discriminator; no storage-cause claim is justified before that result.

## Smallest further byte-level diagnostic, only if needed

1. Read/hash the shared first block's per-layer latent and pooled-index bytes before and after one pressure request. A mutation with no disk I/O isolates the shared-prefix write.
2. If divergence persists with shared writes prevented, instrument GPU-region digests keyed by record tag immediately before spill gather and after restore scatter, then compare again after the16-row replay. Existing record checksums cover staged disk payload, not the destination GPU bytes or a subsequent replay mutation.
3. The existing tiny file/CUDA test can be enlarged to11layers and160sourceblocks with a nonzero logical start97, preserving modulo4 ownership and including lane-local sorting; use an ephemeral test-only copy. This is a focused byte-transfer test, not a whole-model benchmark.

No speculative source fix was made.

## Discriminating live result

`results/tp4-chain-strict-native-resident-pressure/nvme-probe/result.json`: the clean single-pressure control reproduced the same54-ID output for both native and serial while all four ranks had no NVMe restore events. The resident warm baseline was the original50IDs. This demonstrates that disk restoration is not required to trigger the observed change; shared-prefix mutation is independently reproduced without eviction. Root is testing the single ATLAS_GLM_PC_WRITE_FLOOR=1 change, followed by the original two-cycle disk-pressure check. No storage instrumentation is warranted at this stage.

Snapshot capacity correction for the final package report: the actual GPU snapshot cache uses the CLI setting16slots. ATLAS_SSM_TIER_SLOTS=2 controls the host tier, not that GPU snapshot pool; it must not be cited as evidence that the target GPU snapshot was evicted.
