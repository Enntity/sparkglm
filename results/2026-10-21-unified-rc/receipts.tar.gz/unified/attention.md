# TP4 attention port (ready for Linux build and GPU validation)

Engine checkout: `work/glm-native-mtp-20261020/engine`; no commit made by this agent.

## Implemented

- Native FP8 q_a/kv_a MLA fusion now accepts matching TP4/EP4 as well as TP2/EP2. Replicated front projections have unchanged shapes, checkpoint bytes, FP32 scale arithmetic, and BF16 output boundaries. Packed, tiled, shape, cache, index and width guards retained.
- Existing fused/unfused GPU test expanded to all four shard ranks, with a nontrivial physical block map preserving residues modulo4 (and2). Includes native FP8 and MXFP8, 1..32 rows, four mid-pool/block starts, full cache/index/localization byte comparisons.
- Native sparse continued-prefill library now uses explicit 16/32 heads in ABI2, including Rust plan/capacity validation, query padding, metadata/LSE/output dimensions, native dispatch and merge. ABI2 is120 bytes, heads offset112, reserved offset116 (must zero). ABI1 fails at startup.
- Initialization now receives the selected heads before memory sizing. Pinned FlashInfer uses SG16 (84368 dynamic shared bytes) for TP4; MG32 (91920) stays unchanged for TP2. No device allocation/attention in init, and TP2 does not initialize the unused TP4 specialization.
- Only the now-ported SPARSE_NATIVE preflight refusal removed.
- GPU prep and unified byte-oracle harnesses cover both16 and32 heads, including guard regions and rejection before submission.

`product/install/build-native.sh` compiles the entire pinned upstream `csrc/sparse_mla_sm120_prefill.cu`, which instantiates both the SG16 and MG32 GLM variants. It then recompiles the changed engine shim. No changes to that build script are needed for ABI2. Do not reuse the old .so.

## CPU verification

- Test-first Rust planner regression failed against ABI1, then all5 planner tests passed directly against production module through the standalone harness `attention-plan-harness.rs`.
- C++ header ABI size/alignment/offset compile passed.
- Python byte-oracle harnesses compile; touched Rust files formatted; git diff --check passes.
- Attempted full local Mac `cargo test -p spark-model --lib glm_sparse_native --no-default-features --features metal` stopped in pre-existing spark-runtime deny(dead_code) errors (`host_sync_trace`, `LaneWorkspace`). No unrelated source changed. Run actual CUDA-capable Linux build tests below.

## Required focused Linux tests

After building the real unified image/source:

```sh
ATLAS_SKIP_BUILD=1 CUDARC_CUDA_VERSION=13000 cargo test -p spark-model --lib glm_sparse_native -- --nocapture
ATLAS_SKIP_BUILD=1 CUDARC_CUDA_VERSION=13000 cargo test -p spark-server --bin spark glm_chain -- --nocapture
# Real target kernels, GB10, can run on one GPU; emulates all shard ranks.
cargo test --release -p spark-model --lib glm_mla_fuse -- --ignored --nocapture --test-threads=1
```

Native library, in retained validation environment (`/eval` holds the changed engine scripts and rebuilt libraries; `/native/sparse_mla_sm120.so` is pinned reference; Torch+TVM only in test image):

```sh
g++ -std=c++17 /eval/native-init-check.cpp -I/usr/local/cuda/include -L/eval -latlas_glm_sparse_native -Wl,-rpath,/eval -L/usr/local/cuda/lib64 -lcudart -o /tmp/native-init-check
/tmp/native-init-check
nvcc -std=c++17 -O2 --fmad=false --prec-div=true --ftz=false -gencode=arch=compute_121a,code=sm_121a -shared -Xcompiler=-fPIC /eval/native-prep.cu -o /eval/libatlas_native_prep.so
nvcc -std=c++17 -O2 --fmad=false --prec-div=true --ftz=false -gencode=arch=compute_121a,code=sm_121a -shared -Xcompiler=-fPIC /eval/merge-ds.cu -o /eval/libatlas_sparse_merge.so
python3 /eval/native-prep-check.py
python3 /eval/unified-check.py --heads 16 32
```

Unified oracle checks ABI2 against independently assembled reference for2048,3515,4100,4096 rows each head count. Includes inclusive speed comparison at4096 rows against Atlas sparse baseline; existing gate requires1.3x. Synthetic byte equivalence does not substitute for live TP4 quality/throughput checks. `/eval/libatlas_sparse.so` baseline must accept16 heads (existing model sparse kernels already do).

## Remaining optimization audit

- Sparse TC decode/split/prefill, K3 batched query/O, semantic index split, sharded latent cache, owner-batched verify, SP gather and O-projection alltoall already support TP4 geometry; no kernel port needed.
- C4 serial decode/graphs are off in checked-in TP2 RC; these are not parity gaps.
- K5_FUSED_TP_HC is present as env1 but INACTIVE in TP2 RC: `forward_attention.rs:228` requires `!canonical`, while `canonical_verify::enabled()` is true (`ATLAS_W4A16_TC=1`, canonical default1 and forced1 by mode). Thus this is not a TP4 parity gap. The canonical documentation explicitly disables K5-only seams. A new fusion would need a row-invariant design, not merely a four-rank exchange.
- KV_SHARD_OVERLAP is absent from all checked-in product profiles, so no active RC optimization is lost. TP4 retains its existing allgather path.

## Owned changed files

- crates/spark-model/src/layers/qwen3_attention/prefill/paged_glm_front.rs
- crates/spark-model/src/layers/qwen3_attention/mla_native.rs
- crates/spark-model/src/layers/ops/glm_mla_fuse_test_gpu.rs
- crates/spark-model/src/layers/ops/glm_sparse_native.rs
- crates/spark-model/src/layers/ops/glm_sparse_native_loader.rs
- crates/spark-model/src/layers/ops/glm_sparse_native_plan.rs
- crates/spark-model/src/layers/ops/glm_sparse_native_plan_tests.rs
- crates/spark-model/src/layers/ops/glm_sparse_native_tests.rs
- crates/spark-server/src/main_modules/serve_phases/preflight/glm_chain.rs (sparse-native refusal only; topology agent may have other edits)
- crates/spark-server/src/main_modules/serve_phases/preflight/glm_chain_tests.rs (sparse-native expectations only)
- scripts/dev/glm_sparse_native/atlas-glm-sparse-native.h
- scripts/dev/glm_sparse_native/atlas-glm-sparse-native.cu
- scripts/dev/glm_sparse_native/native-prep.cu
- scripts/dev/glm_sparse_native/native-prep-reviewed.cuh
- scripts/dev/glm_sparse_native/native-init.cpp
- scripts/dev/glm_sparse_native/native-init-check.cpp
- scripts/dev/glm_sparse_native/merge-ds.cu
- scripts/dev/glm_sparse_native/native-prep-check.py
- scripts/dev/glm_sparse_native/unified-check.py
- scripts/dev/glm_sparse_native/README.md

Source-map hashes describe original imported artifacts and have not been rewritten; the README provenance paragraph requires noting this TP4 derivative (added below in the actual README).
