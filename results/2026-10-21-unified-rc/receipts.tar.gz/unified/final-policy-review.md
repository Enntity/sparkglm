<!-- SPDX-License-Identifier: AGPL-3.0-only -->
# Final release policy review

No concrete release-policy blocker found. The frozen package retains the
applicable active TP2 optimizations at TP4, with the intended arithmetic
policy changes and four-rank implementations. This is a source/configuration
review, not hardware qualification or a throughput claim. The remaining
capacity, disk restore and topology receipts are owned by the active hardware
validation run.

## Identity and scope

- Engine HEAD and frozen manifest: `d3620ffbaf654186c7213b320e52d0112a71f956`.
- Product install tree: `0308329b4d3c3bb2025f1fcf25163fc9e7f056a5`.
- Every tracked frozen `context/install/` file matches the current product
  counterpart byte for byte. The incremental context Dockerfile names these
  exact identities and checks its assembled source against `source-hashes.json`.
- Compared the TP2 `4x1m`, `4x512k`, `8x128k` and TP4 `4x1m-tp4` profile
  dictionaries; resolved Strict serial, Strict native MTP and Spark with the
  frozen `serve.py`; inspected the corresponding engine guards and current
  launcher documentation.
- No builds, hardware actions or tests were run. No source, install, docs or
  result files were edited. This report is the only write.

## Effective serving policies

| Policy | TP2 | TP4 |
|---|---|---|
| Strict weights/input scales | Native groups, checkpoint scales | Same |
| Strict routed decode | A16 | Same |
| Strict speculation | Serial by default; explicit native MTP | Same |
| Spark target conversions | Corrected RNE FP4 KDA decode and shared experts; native KDA prefill, MLA, dense and head | Same |
| Spark routed decode/drafter | Calibrated A4 and DFlash2, with corrected drafter weight rounding | Same |
| Shared expert split | Spark off; Strict retains existing TP2 profile setting | Off in both modes |
| Strict native verification | Per-owner verification, C1–C4 and prefix caching | Same; full predictor on rank 0, target on all four ranks |
| Native 1M KV cap | 66,000 blocks on the supplied four-slot 1M profile | TP2 cap deliberately not copied |

`serve.py` applies mode overrides after profile defaults. The raw profile's
`ATLAS_GLM_FP4L_DECODE_A16=0` and KDA setting therefore do not describe Strict.
Engine `layers/glm_native/mode.rs` validates the native-group mask, input scales
and decode activation policy and refuses missing required formats. The target
loader and drafter twins select the corrected weight-RNE entry; this does not
change activation quantizers.

Strict native MTP removes the DFlash arguments and enables the native predictor
with full vocabulary, six draft positions and per-owner verification. Its
target admission still requires matching world/TP/EP 2 or 4, C1–C4 and the
existing canonical prerequisites. The full predictor stays on rank 0; the
TP4 target uses 16 local heads. The eight-slot profile remains a serial/DFlash
capacity option, not an admitted native-MTP configuration.

## Active optimization parity

The TP4 raw environment removes no enabled TP2 optimization. Differences are
the intentional unsplit shared expert, equivalent DFlash split spelling,
four-rank transport settings and additional TP4 paths:

- `ATLAS_GLM_DRAFT_TP=1` at TP2 and `mlp,head` at TP4 parse to the same
  `Parts { mlp: true, head: true, attn: false }`. The split geometry and
  context/batched/candidate protocols accept both two and four ranks.
- Native FP8 MLA fusion admits matching TP2/EP2 or TP4/EP4 while retaining
  its packing, layout, shape and canonical guards
  (`qwen3_attention/prefill/paged_glm_front.rs`).
- Native sparse ABI2 carries explicit 16/32-head geometry. Both profiles
  enable the native library; TP4 uses the 16-head implementation, and the
  production native build compiles both variants.
- Canonical projection kernels, sparse decode, expert TP, sequence-parallel
  prefill, gather/overlap and native projection layouts retain their existing
  four-rank paths. TP4 additionally selects the established SP quantized
  gather/seam, staged MLA output, index split and transport tuning settings.
- TP4 sharded NVMe spill/restore now uses four slot classes. Geometry validation,
  per-class staging/budget accounting, class-aware eviction, residue-preserving
  restore and startup agreement include the class count and own/peer record
  sizes. The obsolete TP4 refusal is removed. This is implemented parity;
  hardware eviction/restore evidence remains a separate gate.

The following are **not active TP2 release optimizations missing from TP4**:

- `ATLAS_GLM_K5_FUSED_TP_HC=1` is dormant in both effective policies:
  `forward_attention.rs` requires `!canonical`, while canonical verification
  is enabled by default with `ATLAS_W4A16_TC=1` and explicitly selected by Strict.
  The other K5-only seams are likewise disabled by canonical execution.
- `ATLAS_GLM_KV_SHARD_OVERLAP` is absent from the supplied profiles and off
  when unset. Its pair-only peer exchange is correctly refused at TP4.
- Independent/non-speculative C4 decode, legacy native MTP repair/distributed
  lanes, scalar query comparison and pair verify-graph switches are off in
  the TP2 RC. Their TP4 refusal or fallback is not an active parity gap.
- The TP2-only staged native B-tile gate/up family has no serving caller.
- The pair canonical sparse helper exists to match TP2 sharded/unsharded
  arithmetic. TP4 uses its own 16-head/four-rank attention paths; it must not
  be routed into the pair helper.

## Topology, namespaces and documentation

The launcher and `rdma_pair/topology.rs` agree on default chain and explicit
four-rank ring. The documented map is correct: ring rank 0 has left 3/right 1,
rank 3 has left 2/right 0; chain leaves those outer sides absent. Exact local
left/right lists must be disjoint. Bootstrap checks each edge's rail count
and topology, including the closing edge, so both rails of a dual-rail ring
must close. The launcher does not configure host networking.

Ring changes copied-payload routes. The specialized reduce-scatter/all-to-all
keep their existing arithmetic schedules. Multi-rank completion words now
use the payload parity slot; the TP2 single-word ABI is preserved. No ring
speedup follows from source support alone.

The same `--prefix-cache-dir` and optional `--kv-shard` enable the disk tier
at both sizes. Paths resolve to `strict/` or `spark/` at TP2 and
`tp4/{chain|ring}/{strict|spark}/` at TP4. Native and serial Strict share the
same target policy and mode namespace. README/manual/engine/limitations/LLooM
docs match the frozen policies, identify Strict native MTP as opt-in and
keep final-image qualification pending. The resident-prefix smoke is scoped
to roughly 12K and is not presented as disk-restore or near-1M evidence.

The split-off TP4 policy is supported by the retained same-image one-switch
control: all four serial and four native arithmetic results changed from
`-382130` to `-381530`, with native token IDs matching serial. No broader
fidelity or performance conclusion is inferred from that control.
