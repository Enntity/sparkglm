# SPDX-License-Identifier: AGPL-3.0-only
"""Image content identity shared by classic and containerd Docker stores."""
import hashlib
import json
import re

FIELDS = ('RootFS', 'Config', 'Architecture', 'Os', 'Variant', 'Created', 'Author')


def content_projection(image):
    for field in ('RootFS', 'Config', 'Architecture', 'Os', 'Created'):
        if field not in image or image[field] is None:
            raise ValueError('image inspect missing content field: '+field)
    if not isinstance(image['Config'], dict) or not isinstance(image['RootFS'], dict):
        raise ValueError('invalid image content structure')
    if image['RootFS'].get('Type') != 'layers' or not isinstance(image['RootFS'].get('Layers'), list):
        raise ValueError('invalid image RootFS layer inventory')
    # Docker may omit optional OCI fields. Missing and explicit null have the
    # same meaning; strings (including empty strings) remain distinct.
    return {field: image.get(field) for field in FIELDS}


def projection_sha256(image):
    raw = json.dumps(content_projection(image), sort_keys=True, separators=(',', ':')).encode()
    return hashlib.sha256(raw).hexdigest()


def verify_content(source, actual, expected_local_id=None):
    if not re.fullmatch(r'sha256:[0-9a-f]{64}', actual.get('Id', '')):
        raise ValueError('image inspect did not return an immutable local ID')
    if expected_local_id is not None and actual['Id'] != expected_local_id:
        raise ValueError('host-local immutable image ID changed')
    left, right = content_projection(source), content_projection(actual)
    differences = [field for field in FIELDS if left[field] != right[field]]
    if differences:
        raise ValueError('image content mismatch: '+', '.join(differences))
    return actual['Id']
