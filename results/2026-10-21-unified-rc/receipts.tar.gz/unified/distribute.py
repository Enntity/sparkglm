# SPDX-License-Identifier: AGPL-3.0-only
"""Distribute the pinned image through the fabric and compare full content."""
import concurrent.futures
import json
import shlex
import sys
import time
from ops import *

sys.path.insert(0, str(ROOT.parent / 'glm-tp2-rc-validation-20261020/quality'))
from image_identity import projection_sha256, verify_content

manifest = json.loads((ROOT / 'final-image.json').read_text())
source = json.loads(ssh(HOSTS[0], ['docker', 'image', 'inspect', manifest['image_id']]).stdout)[0]
assert source['Id'] == manifest['image_id']
save('image-inspect-ennspark01.json', source)
renew()
note('Distributing the corrected unified RC through the fabric; verifying full image content on all four hosts')


def transfer(host):
    command = shlex.join(['docker', 'save', manifest['tag']]) + ' | ' + shlex.join(
        ['ssh', '-o', 'BatchMode=yes', host + '-fab', 'docker load'])
    started = time.time()
    result = ssh(HOSTS[0], ['bash', '-o', 'pipefail', '-c', command], timeout=900)
    save('image-distribution-' + host + '.json',
         {'image': manifest['image_id'], 'started': started, 'ended': time.time(),
          'stdout': result.stdout.decode(), 'stderr': result.stderr.decode()})
    actual = json.loads(ssh(host, ['docker', 'image', 'inspect', manifest['tag']]).stdout)[0]
    local_id = verify_content(source, actual)
    save('image-inspect-' + host + '.json', actual)
    return host, {'image_id': local_id, 'content_projection_sha256': projection_sha256(actual)}


identity = {HOSTS[0]: {'image_id': source['Id'], 'content_projection_sha256': projection_sha256(source)}}
with concurrent.futures.ThreadPoolExecutor(3) as pool:
    for host, verified in pool.map(transfer, HOSTS[1:]):
        identity[host] = verified
save('image-host-identity.json', identity)
print(json.dumps(identity, indent=2))
