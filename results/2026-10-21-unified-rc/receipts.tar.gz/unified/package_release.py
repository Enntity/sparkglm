# SPDX-License-Identifier: AGPL-3.0-only
"""Create one portable RC source package from clean, committed repositories."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
from ops import ROOT

ENGINE = ROOT.parent / 'glm-native-mtp-20261020/engine'
PRODUCT = ROOT.parent / 'glm-native-mtp-20261020/product'
OUT = ROOT.parent.parent / 'outputs/sparkglm-unified-rc-20261021'
STAGE = ROOT / 'release-bundle'
QUAL = json.loads((ROOT / 'qualification.json').read_text())
assert QUAL['passed']
TESTED = json.loads((ROOT / 'final-image.json').read_text())
assert subprocess.check_output(['git', '-C', str(ENGINE), 'rev-parse', 'HEAD'], text=True).strip() == TESTED['source']['commit']
assert subprocess.check_output(['git', '-C', str(ENGINE), 'rev-parse', 'HEAD^{tree}'], text=True).strip() == TESTED['source']['tree']
assert subprocess.check_output(['git', '-C', str(PRODUCT), 'rev-parse', 'HEAD:install'], text=True).strip() == TESTED['install_tree']
for repo in (ENGINE, PRODUCT):
    assert not subprocess.check_output(['git', '-C', str(repo), 'status', '--porcelain'], text=True).strip()
assert not OUT.exists() and not STAGE.exists()
OUT.mkdir()
STAGE.mkdir()


def snapshot(repo, name):
    dest = STAGE / name
    dest.mkdir()
    # The archive contains only tracked files from the exact clean commit,
    # without local credentials, ignored build outputs, or repository history.
    process = subprocess.Popen(['git', '-C', str(repo), 'archive', '--format=tar', 'HEAD'], stdout=subprocess.PIPE)
    with tarfile.open(fileobj=process.stdout, mode='r|') as archive:
        archive.extractall(dest, filter='data')
    assert process.wait() == 0


snapshot(ENGINE, 'engine')
snapshot(PRODUCT, 'sparkglm')
identity = json.loads((ROOT / 'final-image.json').read_text())
identity['package_product_commit'] = subprocess.check_output(['git', '-C', str(PRODUCT), 'rev-parse', 'HEAD'], text=True).strip()
(STAGE / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n')
shutil.copy2(ROOT / 'package-build.sh', STAGE / 'build.sh')
(STAGE / 'build.sh').chmod(0o755)
shutil.copy2(ROOT / 'RELEASE.md', STAGE / 'RELEASE.md')
files = sorted(path for path in STAGE.rglob('*') if path.is_file())
for path in files:
    if path.is_symlink():
        assert path.resolve().is_relative_to(STAGE.resolve())
(STAGE / 'SOURCE-SHA256SUMS').write_text(''.join(
    hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + str(path.relative_to(STAGE)) + '\n' for path in files))
archive = OUT / 'sparkglm-tp2-tp4-rc-20261021.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    tar.add(STAGE, arcname='sparkglm-unified-rc')
for source, name in [('RELEASE.md', 'RESULT.md'), ('qualification.json', 'qualification.json'),
                     ('final-image.json', 'image.json'), ('topology-performance.json', 'topology-performance.json'),
                     ('nvme-causal-comparison.json', 'cache-fix.json')]:
    shutil.copy2(ROOT / source, OUT / name)
shutil.copy2(PRODUCT / 'results/2026-10-21-unified-rc/receipts.tar.gz', OUT / 'receipts.tar.gz')
(OUT / 'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.name + '\n'
                                     for p in sorted(OUT.iterdir()) if p.is_file()))
subprocess.run(['shasum', '-a', '256', '-c', 'SHA256SUMS'], cwd=OUT, check=True)
subprocess.run(['shasum', '-a', '256', '-c', 'SOURCE-SHA256SUMS'], cwd=STAGE, stdout=subprocess.DEVNULL, check=True)
subprocess.run(['bash', '-n', str(STAGE / 'build.sh')], check=True)
print(json.dumps({'output': str(OUT), 'package_bytes': archive.stat().st_size,
                  'engine_commit': identity['source']['commit'],
                  'product_commit': identity['package_product_commit'],
                  'install_tree': identity['install_tree']}, indent=2))
