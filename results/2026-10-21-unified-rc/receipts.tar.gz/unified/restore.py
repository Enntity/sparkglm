# SPDX-License-Identifier: AGPL-3.0-only
"""Restore prior managed serving after removing only this task's containers."""
import subprocess
import sys
import time
from ops import *
from cluster import state, store

s = state()
assert not s['owned'] and not s['pending'], 'Stop owned test containers first'
resources = sys.argv[1:] or ['drafter-0304', 'pair']
assert all(r in ('drafter-0304', 'pair') for r in resources)
resources = [r for r in resources if not (ROOT / ('released-' + r + '.json')).exists()]
hosts = [host for r in resources for host in (HOSTS[2:] if r == 'drafter-0304' else HOSTS[:2])]
for host in hosts:
    assert not ssh(host, ['docker', 'ps', '-q']).stdout.strip(), 'Unexpected container on ' + host
renew()
for host in list(s['clocks']):
    if host not in hosts:
        continue
    ssh(host, ['sudo', '-n', '/usr/bin/systemctl', 'start', 'gpu-clock-cap.service'])
    active = ssh(host, ['systemctl', 'show', 'gpu-clock-cap.service', '--property=ActiveState', '--value']).stdout.decode().strip()
    assert active == 'active'
    s['clocks'].remove(host)
    store(s)
for resource in resources:
    cli(['release', resource], 'release-' + resource + '-preview')
    released = cli(['release', resource, '--apply', '--yes'], 'release-' + resource + '-apply')
    save('released-' + resource + '.json', released)
if 'drafter-0304' in resources:
    subprocess.run([sys.executable, str(ROOT / 'fallback.py'), 'sparkqwen-pair'], check=True)
save('restored-schedule.json', cli(['schedule'], 'restored-schedule-' + str(time.time_ns())))
print('Managed serving and clock caps restored through LLooM: ' + ', '.join(resources))
