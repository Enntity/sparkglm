# SPDX-License-Identifier: AGPL-3.0-only
"""Compact, read-only view of the actual unified RC receipts."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent
for arm in sorted((root / 'results').iterdir()):
    if not arm.is_dir():
        continue
    row = {'arm': arm.name}
    for filename, key in [('smoke.json', 'smoke'), ('capacity/result.json', 'capacity'),
                          ('nvme-probe/result.json', 'nvme')]:
        path = arm / filename
        if path.exists():
            data = json.loads(path.read_text())
            row[key] = {'passed': data['passed'], 'error': data.get('error'),
                        'checks': len(data.get('checks', [])),
                        'requests': len(data.get('requests', []))}
            if key == 'capacity':
                row[key]['minimum_available_gib'] = {
                    host: round(kib / 1024**2, 3) if kib else None
                    for host, kib in data.get('minimum_MemAvailable_kib', {}).items()}
    for filename in ['speed.json', 'speed-serial.json']:
        path = arm / filename
        if path.exists():
            data = json.loads(path.read_text())
            row[filename] = {'passed': data.get('passed', False), 'runs': data['runs'],
                             'rates': {name: item['decode_tokens_per_second']
                                       for name, item in data['decode'].items()}}
    print(json.dumps(row))
