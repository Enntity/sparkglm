# SPDX-License-Identifier: AGPL-3.0-only
"""Tiny real CUDA/O_DIRECT storage qualification on reserved, idle GPU01."""
import json
import time
from ops import *

final = json.loads((ROOT / 'final-image.json').read_text())
assert not ssh('ennspark01', ['docker', 'ps', '-q']).stdout.strip()
directory = STAGE + '/nvme-device-check'
ssh('ennspark01', ['mkdir', '-p', directory])
filesystem = ssh('ennspark01', ['findmnt', '-T', directory, '-o', 'TARGET,SOURCE,FSTYPE', '--json']).stdout.decode()
save('nvme-gpu-filesystem.json', json.loads(filesystem))
renew()
note('Final RC: tiny real CUDA and O_DIRECT round-trip across all four NVMe shard geometries')
started = time.time()
args = ['docker', 'run', '--rm', '--gpus', 'all', '--network=none', '--memory', '12g',
        '-v', directory + ':/nvme', '-e', 'ATLAS_NVME_TEST_DIR=/nvme',
        '-e', 'LD_LIBRARY_PATH=/usr/local/cuda/lib64:/usr/lib/aarch64-linux-gnu',
        '--entrypoint', 'cargo', final['builder_id'], 'test', '--locked', '--release',
        '-j', '4', '-p', 'spark-runtime', '--lib', 'tp4_nvme_device_file_round_trip',
        '--', '--ignored', '--nocapture']
with (ROOT / 'nvme-gpu.log').open('wb') as log:
    result = ssh('ennspark01', args, stdout=log, stderr=subprocess.STDOUT, check=False, timeout=600)
save('nvme-gpu-exit.json', {'code': result.returncode, 'started': started, 'ended': time.time(),
                          'builder_id': final['builder_id'], 'image_id': final['image_id'],
                          'binary_sha256': final['hashes']['/usr/local/bin/spark'], 'argv': args})
assert result.returncode == 0, 'Real NVMe GPU check failed'
text = (ROOT / 'nvme-gpu.log').read_text()
assert '1 passed; 0 failed' in text, 'Test must run, not just compile'
print('Real CUDA/O_DIRECT TP4 storage round trip passed')
