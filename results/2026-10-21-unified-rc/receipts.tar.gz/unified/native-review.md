# Independent native MTP TP4 review

Scope: read-only review of the current shared engine diff against ddd6a0d33d54e2efac7c29b982009daa27d7a840. No edits, commits or GPU work from this review.

## Result

No concrete blocking defect found in the native-MTP TP4 changes. This is source review, not a live qualification result. The patch chiefly extends explicit topology boundaries while reusing existing four-rank target execution and all-rank EP protocols; it does not introduce a four-rank private predictor.

## Checked paths and invariants

- `glm_native/topology.rs` admits only matching world/TP/EP2 or4. Factory checks also require aligned in-range TP/EP rank. Runtime `native_canonical_target_ready` checks the actual communicator size and rank against both configured ranks. This strengthens malformed TP2 construction rejection while preserving valid TP2/EP2.
- Preflight still requires explicit strict native MTP, speculation, C1..C4, equal active/admitted capacities, and EPv2 when concurrency exceeds1. The memory-reserve exception remains behind the same admission. No broad topology-only bypass observed.
- Format policy is unchanged. Strict still requires native groups, checkpoint input scales and A16 routed decode; unknown/unsupported conversions remain rejected. The loader’s new topology check does not weaken these checks.
- Factory capability validates predictor marker and full shared vocabulary tensors on every rank; only rank0 builds the predictor. `glm5_mtp_draft_config` restores64 total MLA heads from16 local heads atTP4, sets TP/EP1 and keeps all experts. It does not mutate the target. No new predictor weight quantization introduced.
- Canonical target verification remains mandatory (canonical verify + BF16 mHC + prepared MXFP8 vocabulary shard). Existing sparse TC geometry already supports TP4 local16. Existing token-sharded TP4 attention has its own four-rank merge/view path; it does not enter the TP2-only canonical pair helper.
- Split vocabulary argmax/sample/full-row reconstruction already use communicator world size. TP4 full rows use the existing in-place four-rank gather; TP2 still uses its peer exchange. The new readiness predicate does not route TP4 into the pair exchange.
- Shared-prefix admission still broadcasts one bounded probe, then `ep_min_u32` votes across the actual communicator. Its fast path gathers all four rank slots; fallback broadcasts each root. A missing worker owner/snapshot votes zero and still participates. Root’s private predictor snapshot/free-block checks precede issuing the command; workers do not need private predictor state.
- Prefix restore performs two all-rank agreements (exact anchor and readiness) before skipping target rows; only rank0 restores predictor state. Slot addressing remains EPv2 and independent of rank count.
- There is no algorithmic modification to TP2 numerical execution in this native patch; the added rank validation is the only intentional stricter boundary.

## Necessary focused live checks

1. TP4 Strict, exact same loaded target and settings: native MTP vs disable_mtp serial token IDs, both short and longer-than32K prompts. Include a sampled case; greedy equality alone does not cover full-vocabulary reconstruction/fallback.
2. C4 distinct owners with prefix reuse and one cancellation/reuse cycle. Require matching per-request serial controls; inspect all four rank logs for slot/collective errors.
3. Near1M shared resident prefix: four resident branches, exact serial IDs, all-rank cache-hit/anchor agreement and rank0 host-memory headroom. The new CPU test exercises logical four-rank veto but does not validate actual ring/chain transport.
4. Repeat one native+serial/cached canary in chain mode and ring mode, because both the vocabulary gather and prefix-min fast path now traverse the selected four-rank transport. Exact outputs should remain equal between transports because transport must preserve rank placement and reduction order.
5. TP2 native+serial short/cached canary on the unified build to verify unchanged serving behavior.

## CPU test targets worth retaining

- `native_target_prerequisites_cover_every_pair_and_four_rank_member`
- `tp4_predictor_retains_all_heads_experts_and_eh_workspace`
- `tp4_shared_prefix_credit_requires_all_four_current_snapshots`
- `strict_native_tp4_resolves_all_ranks_for_c1_through_c4_full_context`
- existing `glm_sparse_decode` and `glm_vocab_split` tests

The exact production Linux test run is owned by root; this review did not rerun broad tests while the build is in flight.
