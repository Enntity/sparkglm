# SPDX-License-Identifier: AGPL-3.0-only
import concurrent.futures as cf,json,sys
from ops import *
code="""import json,pathlib
root=pathlib.Path('/sys/class/infiniband');out={}
for device in root.iterdir():
 p=device/'ports/1';values={}
 for k in ('port_xmit_data','port_rcv_data','port_xmit_packets','port_rcv_packets'):
  f=p/'counters'/k
  if f.exists():values[k]=int(f.read_text().strip())
 out[device.name]=values
print(json.dumps(out))"""
def one(host):return host,json.loads(ssh(host,['python3','-c',code]).stdout)
with cf.ThreadPoolExecutor(4) as pool:rows=dict(pool.map(one,HOSTS))
save(sys.argv[1]+'/fabric-counters-'+sys.argv[2]+'.json',rows)
