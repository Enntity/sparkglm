#!/usr/bin/env bash
# SPDX-License-Identifier: AGPL-3.0-only
# Cold build from this RC's complete source snapshots. Requires Linux arm64,
# Docker/BuildKit and network access for pinned upstream build dependencies.
set -euo pipefail
root=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
cd "$root"
sha256sum -c --quiet SOURCE-SHA256SUMS
tree=$(python3 -c 'import json; print(json.load(open("identity.json"))["install_tree"])')
[[ $tree =~ ^[0-9a-f]{40}$ ]]
image=${SPARKGLM_IMAGE_REPO:-localhost/atlas-sparkglm}:unified-rc-${tree:0:12}
context=$(mktemp -d "${TMPDIR:-/tmp}/sparkglm-unified-build.XXXXXXXX")
trap 'rm -rf "$context"' EXIT
cp -a engine "$context/engine"
cp -a sparkglm/install "$context/install"
cp sparkglm/install/dockerignore "$context/.dockerignore"
args=(--build-arg "INSTALL_TREE=$tree" --build-arg "BUILD_JOBS=${ATLAS_BUILD_JOBS:-4}"
      -f "$context/install/Dockerfile")
docker build "${args[@]}" --target checks "$context"
docker build "${args[@]}" --target runtime -t "$image" "$context"
docker image inspect --format '{{.Id}} {{.Architecture}}' "$image"
echo "$image"
