# TP4 attention port

1. Extend native MLA fusion only to the matching TP4/EP4 geometry; retain packed/tiled/shape safety and exact reference GPU tests, now including four shard ranks.
2. Introduce explicit-head sparse ABI2. Parameterize query padding, scratch and LSE capacities, C validation and 16-head initialization. Preserve TP2 arithmetic and reject stale ABI1 libraries at startup.
3. Add CPU geometry/ABI/capacity regression tests and synthetic GPU byte-oracle fixtures for TP2 and TP4. No GPU work from this agent; root owns reservations and runs.
4. Remove only the sparse-native preflight refusal once the full port exists; report remaining pair-specific lanes and their TP4 equivalents.
