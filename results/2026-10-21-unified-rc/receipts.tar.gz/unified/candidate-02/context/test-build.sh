#!/bin/bash
set -euo pipefail
cargo test --locked --release -j 4 -p spark-comm --lib chain:: -- --nocapture
cargo test --locked --release -j 4 -p spark-comm --lib oneshot::tests:: -- --nocapture
cargo test --locked --release -j 4 -p spark-comm --lib --no-run
cargo build --locked --release -j 4 -p spark-server
