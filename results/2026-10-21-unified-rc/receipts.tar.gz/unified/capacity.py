# SPDX-License-Identifier: AGPL-3.0-only
"""One near-limit prefix, native/serial equality and four cached branches."""
import concurrent.futures as cf
import datetime,hashlib,json,re,subprocess,threading,time,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=Path.cwd()/'capacity';OUT.mkdir(exist_ok=False)
URL='http://127.0.0.1:8893';LIMIT=1048576;OLD_LIMIT=1014752
record={'passed':False,'context_limit':LIMIT,'old_resident_limit':OLD_LIMIT,'requests':[],'memory':[]}
stop=threading.Event();save_lock=threading.RLock();memory_interval=1
def save():
 with save_lock:(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
HOSTS=['ennspark01','ennspark02','ennspark03','ennspark04']
def hostwatch(host):
 while not stop.is_set():
  try:
   if host=='ennspark01':raw=Path('/proc/meminfo').read_text()
   else:raw=subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5',host+'-fab','cat /proc/meminfo'],text=True,timeout=10)
   info={}
   for line in raw.splitlines():
    key,rest=line.split(':',1)
    if key in ('MemAvailable','MemFree','SwapFree'):info[key+'_kib']=int(rest.split()[0])
   with save_lock:record['memory'].append({'host':host,'time':time.time(),**info})
  except Exception as exc:record.setdefault('memory_monitor_errors',[]).append(repr(exc))
  stop.wait(0.1 if host=='ennspark01' else 1)
def post(path,body,timeout=1800):
 req=urllib.request.Request(URL+path,json.dumps(body).encode(),{'Content-Type':'application/json'})
 return urllib.request.urlopen(req,timeout=timeout)
def tokenize(prompt,messages=False):
 body={'messages':[{'role':'user','content':prompt}],'chat_template_kwargs':{'reasoning_effort':'low'}} if messages else {'prompt':prompt}
 with post('/tokenize',body,180) as response:data=json.load(response)
 ids=data.get('tokens');n=data.get('count',len(ids) if ids else None);assert isinstance(n,int)
 return n
BASE={'model':'glm-5.3-flash-atlas','temperature':0,'top_k':1,'top_p':1,'min_p':0,'repetition_penalty':1,
      'chat_template_kwargs':{'reasoning_effort':'low'},'return_token_ids':True,'max_tokens':192,
      'stream':True,'stream_options':{'include_usage':True}}
def request(prompt,serial,label,barrier=None,cancel=False):
 body=dict(BASE,messages=[{'role':'user','content':prompt}],disable_mtp=serial)
 if label.startswith(('extended-','cached-C4','fork-C4','fork-serial','cancelled-')):body['max_tokens']=384
 if barrier:barrier.wait(timeout=30)
 row={'label':label,'serial':serial,'started':time.monotonic(),'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),
      'body_without_messages':{k:v for k,v in body.items() if k!='messages'},'events':[],'token_ids':[],'content':'','reasoning_content':''}
 with save_lock:record['requests'].append(row);save()
 try:
  with post('/v1/chat/completions',body) as response:
   for raw in response:
    if not raw.startswith(b'data:'):continue
    data=raw[5:].strip()
    if data==b'[DONE]':row['done']=True;break
    e=json.loads(data);row['events'].append(e);assert not e.get('error'),e
    if e.get('usage'):row['usage']=e['usage']
    for choice in e.get('choices',[]):
     delta=choice.get('delta') or {};ids=choice.get('token_ids') or delta.get('token_ids') or []
     row['token_ids'].extend(ids)
     for key in ('content','reasoning_content'):row[key]+=delta.get(key) or ''
     if choice.get('finish_reason'):row['finish_reason']=choice['finish_reason']
    if cancel and row['token_ids'] and not row.get('finish_reason'):row['cancelled']=True;break
 except BaseException as exc:
  row['error']=repr(exc);raise
 finally:
  row['ended']=time.monotonic();save()
 if cancel:assert row.get('cancelled') and not row.get('finish_reason') and not row.get('done'),'Request finished before cancellation'
 if not cancel:
  assert row.get('done') and row.get('usage') and row['token_ids']
  assert row.get('finish_reason')=='stop','Near-limit answer truncated'
  if serial:assert accepted(row)==0
 return row
def accepted(row):return row['usage'].get('completion_tokens_details',{}).get('accepted_prediction_tokens',0)
def cached(row):return row['usage'].get('prompt_tokens_details',{}).get('cached_tokens',0)
def logs(rank,since=None,until=None):
 args=['docker','logs']
 if since:args+=['--since',since]
 if until:args+=['--until',until]
 args+=['atlas-sparkglm-unified-rank'+str(rank)]
 if rank:args=['ssh','-o','BatchMode=yes',HOSTS[rank]+'-fab',*args]
 raw=subprocess.check_output(args,stderr=subprocess.STDOUT,text=True,timeout=30)
 return re.sub(r'\x1b\[[0-9;]*m','',raw)
def utcnow():return datetime.datetime.now(datetime.timezone.utc).isoformat()
monitors=[threading.Thread(target=hostwatch,args=(h,),daemon=True) for h in HOSTS]
for monitor in monitors:monitor.start()
try:
 allocations=[]
 for rank in range(4):
  raw=logs(rank);(OUT/('rank'+str(rank)+'-allocation.log')).write_text(raw)
  agreed=re.findall(r'KV cache: rank '+str(rank)+r' fits \d+ blocks; all ranks agree on (\d+)',raw)
  allocated=re.findall(r'KV cache: (\d+) blocks [×x] 11 layers',raw)
  assert allocated,'Missing allocated target KV pool evidence'
  target=int(allocated[-1]);assert target>=65538,target
  if agreed:assert int(agreed[-1])==target,(agreed,target)
  allocation={'rank':rank,'target_blocks':target}
  if rank==0:
   matches=re.findall(r'native GLM MTP private KV allocated from joint aggregate budget.*?target_blocks=(\d+).*?private_blocks=(\d+)',raw)
   assert matches,'Missing rank-0 native MTP private KV allocation evidence'
   private_target,private=map(int,matches[-1]);assert private_target==target and private==target+4,(target,private_target,private)
   allocation['private_blocks']=private
  allocations.append(allocation)
 assert len({r['target_blocks'] for r in allocations})==1,'Rank KV allocation disagreement'
 record['allocations']=allocations;save()
 prompt=(ROOT/'capacity-prompt.txt').read_text()
 n=tokenize(prompt,True)
 assert 1046000<n<1048576-384,n
 record.update(prompt_tokens_tokenizer=n,prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest())
 (OUT/'prompt.txt').write_text(prompt)
 save()
 native=request(prompt,False,'near-limit-native')
 serial=request(prompt,True,'near-limit-serial')
 assert serial['token_ids']==native['token_ids'],'Near-limit native/serial tokens differ'
 assert accepted(native)>0,'Native path not exercised'
 assert all('ORCHID-7291' in r['content'] for r in (serial,native)),'Near-limit marker retrieval failed'
 assert all(r['usage']['prompt_tokens']>OLD_LIMIT for r in (serial,native))
 memory_interval=1
 suffix=' Then write three short sentences explaining why the maintenance archive needs an exact identifier.';extension=prompt+suffix
 record['extension_suffix']=suffix
 seeded=request(extension,False,'extended-prefix-native')
 assert cached(seeded)>0 and accepted(seeded)>0 and 'ORCHID-7291' in seeded['content']
 barrier=threading.Barrier(4)
 wave_start=utcnow()
 with cf.ThreadPoolExecutor(4) as pool:branches=list(pool.map(lambda i:request(extension,False,'cached-C4-'+str(i),barrier),range(4)))
 wave_end=utcnow();raw=logs(0,wave_start,wave_end);(OUT/'c4-scheduler.log').write_text(raw)
 record['c4_scheduler_active4']=bool(re.search(r'DFLASH WIDTH n_active=4\b',raw));save()
 assert record['c4_scheduler_active4'],'No scheduler evidence of four simultaneously active sequences'
 assert max(r['started'] for r in branches)<min(r['ended'] for r in branches),'Branches did not overlap'
 for r in branches:assert cached(r)>0 and accepted(r)>0 and r['token_ids']==seeded['token_ids'],'Cached C4 branch differs'
 # Exercise ordinary branches with different tails, not just identical replays.
 fork_prompts=[extension+' Begin the explanation with "Record '+letter+'".' for letter in 'ABCD']
 record['fork_suffixes']=[p[len(prompt):] for p in fork_prompts]
 fork_barrier=threading.Barrier(4);fork_start=utcnow()
 with cf.ThreadPoolExecutor(4) as pool:
  forks=list(pool.map(lambda i:request(fork_prompts[i],False,'fork-C4-'+str(i),fork_barrier),range(4)))
 fork_end=utcnow();fork_log=logs(0,fork_start,fork_end);(OUT/'fork-c4-scheduler.log').write_text(fork_log)
 record['fork_c4_scheduler_active4']=bool(re.search(r'DFLASH WIDTH n_active=4\b',fork_log))
 lines=fork_log.splitlines();restores=[line for line in lines if 'native MTP prefix hit:' in line];done=[line for line in lines if 'mtp_accept_debug: Done:' in line]
 def ts(line):return datetime.datetime.fromisoformat(line.split()[0].replace('Z','+00:00')).timestamp()
 record['fork_c4_resident4']=len(restores)==4 and len(done)==4 and {int(re.search(r'slot=(\d+)',line)[1]) for line in restores}=={0,1,2,3} and max(map(ts,restores))<min(map(ts,done))
 record['fork_c4_resident_overlap_seconds']=min(map(ts,done))-max(map(ts,restores)) if restores and done else None
 record['fork_c4_peak_decode_width']=max(map(int,re.findall(r'DFLASH WIDTH n_active=(\d+)',fork_log)),default=0)
 save();assert record['fork_c4_resident4'],'Distinct-tail shared-prefix branches did not reach four resident slots'
 for i,r in enumerate(forks):
  assert cached(r)>0 and accepted(r)>0 and 'ORCHID-7291' in r['content']
  reference=request(fork_prompts[i],True,'fork-serial-'+str(i))
  assert r['token_ids']==reference['token_ids'],'Distinct-tail native/serial tokens differ'
 cancel_suffix=' Then write 100 numbered maintenance instructions, each a complete sentence.'
 record['cancel_suffix']=cancel_suffix
 request(prompt+cancel_suffix,False,'cancelled-long-prefix',cancel=True)
 reused=request('What is 17 + 25? Reply with only the integer.',False,'slot-reuse')
 assert reused['content'].strip()=='42'
 stop.set()
 for monitor in monitors:monitor.join(timeout=15)
 assert not any(m.is_alive() for m in monitors) and not record.get('memory_monitor_errors'),'Memory monitor failed'
 assert all(any(r['host']==host for r in record['memory']) for host in HOSTS),'Missing host memory samples'
 assert all(r['MemAvailable_kib']>=4096*1024 for r in record['memory']),'Loaded host headroom fell below 4 GiB'
 record['passed']=True
except BaseException as exc:
 record['error']=repr(exc);raise
finally:
 stop.set()
 for monitor in monitors:monitor.join(timeout=15)
 record['minimum_MemAvailable_kib']={host:min((r['MemAvailable_kib'] for r in record['memory'] if r['host']==host),default=None) for host in HOSTS}
 save()
