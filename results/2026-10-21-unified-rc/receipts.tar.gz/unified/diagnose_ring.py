import ast,subprocess
from ops import *
source=ast.parse((ROOT/'gpu_transport.py').read_text())
cmd=next(ast.literal_eval(n.value) for n in source.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cmd' for t in n.targets))
patch=r'''python3 - <<'DIAG'
from pathlib import Path
p=Path('crates/spark-comm/src/nccl_backend/rdma_pair/chain_loopback_tests.rs')
s=p.read_text().replace('#[derive(Clone, Copy, PartialEq)]','#[derive(Clone, Copy, Debug, PartialEq)]')
a='''+repr('''                got[from..][..len]
                    .iter()
                    .zip(&want[from..])
                    .filter(|(a, b)| a != b)
                    .count()''')+r'''
b='''+repr('''                let bad: Vec<_> = got[from..][..len].iter().zip(&want[from..]).enumerate().filter(|(_, (a,b))| a != b).map(|(i,_)| i+from).collect();
                if !bad.is_empty() { eprintln!("BAD k={k} {:?} bytes={} rank={rank} count={} first={:?} got/want={:?}", self.kind, self.bytes, bad.len(), &bad[..bad.len().min(8)], bad.iter().take(8).map(|&i| (got[i],want[i])).collect::<Vec<_>>()); }
                bad.len()''')+r'''
assert a in s;s=s.replace(a,b)
s=s.replace('''+repr('''        step.prepare(&g, *k);''')+r''','''+repr('''        eprintln!("EAGER k={} {:?} bytes={}", *k, step.kind, step.bytes);
        step.prepare(&g, *k);''')+r''')
s=s.replace('''+repr('''    let execs = [0, 1, 2, 3].map''')+r''','''+repr('''    eprintln!("GRAPH START");
    let execs = [0, 1, 2, 3].map''')+r''')
s=s.replace('''+repr('''    let drag = alloc(8 << 20);''')+r''','''+repr('''    eprintln!("STRESS START");
    let drag = alloc(8 << 20);''')+r''')
p.write_text(s)
DIAG
'''
cmd=cmd.replace('export ATLAS_ONESHOT_CUBIN_DIR=',patch+'export ATLAS_ONESHOT_CUBIN_DIR=')
cmd=cmd.replace('for topology in chain ring;','for topology in ring;').replace('--lib chain_loopback --','--lib chain_loopback_four_ranks --')
(ROOT/'diagnose-ring-command.sh').write_text(cmd)
args=['docker','run','--rm','--name','glm-ring-diagnostic','--gpus','all','--network','host','--ipc','host','--memory','12g','--ulimit','memlock=-1:-1','--device','/dev/infiniband','-e','LD_LIBRARY_PATH=/usr/local/cuda/lib64:/lib/aarch64-linux-gnu','-e','ATLAS_PDL=1','--entrypoint','/bin/bash','localhost/atlas-glm-unified-builder:e611459b2621']
with (ROOT/'ring-gpu-diagnostic-red.log').open('wb') as log:r=ssh('ennspark01',args+['-lc',cmd],stdout=log,stderr=subprocess.STDOUT,timeout=240,check=False)
print('exit',r.returncode)
