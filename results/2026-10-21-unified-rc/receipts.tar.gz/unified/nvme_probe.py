# SPDX-License-Identifier: AGPL-3.0-only
"""Two bounded real-model NVMe spill/restore cycles on the reserved TP4 leader.

Run from a fresh results/arm directory on ennspark01, with the final Strict
native server, --kv-shard, a 48 GiB combined tier (24 GiB KV + 24 GiB SSM)
and ATLAS_KV_MAX_BLOCKS=2048.
Pressure requests are serial: they must not evict native predictor snapshots.
Establish resident warm native/serial controls BEFORE any pressure, then require
both modes to reproduce those exact token IDs after each actual disk restore.
Cold-versus-warm equality is reported separately and remains an overall quality
gate; a difference does not abort the disk-isolation experiment prematurely.
This is a correctness probe, not a throughput or capacity benchmark.
"""
import argparse
import concurrent.futures as cf
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time
import urllib.error
import urllib.request
import uuid

ANSI = re.compile(r'\x1b\[[0-9;]*m')
HOSTS = ['ennspark01', 'ennspark02', 'ennspark03', 'ennspark04']
BASE = {
    'model': 'glm-5.3-flash-atlas', 'temperature': 0, 'top_k': 1,
    'top_p': 1, 'min_p': 0, 'repetition_penalty': 1,
    'chat_template_kwargs': {'enable_thinking': False, 'reasoning_effort': 'low'},
    'stream': True, 'stream_options': {'include_usage': True}, 'return_token_ids': True,
}
RESTORE = re.compile(
    r'NVMe prefix restore: (?P<restored>\d+)/(?P<wanted>\d+) blocks '
    r'\((?P<tokens>\d+) tokens after (?P<resident>\d+) resident\).*?'
    r'tier (?P<slots_used>\d+)/(?P<max_slots>\d+) slots, (?P<spills>\d+) spills, '
    r'(?P<restores>\d+) restores, (?P<failures>\d+) failures;.*?'
    r'(?P<clean_evictions>\d+) evictions without a write;'
)
NATIVE_HIT = 'native MTP prefix hit: restored predictor KV and target boundary'
NATIVE_MISS = 'native MTP prefix miss: recomputing target and predictor context'
NATIVE_EVICT = 'native MTP prefix eviction: private pool pressure'
SKIP = re.compile(r'Marconi (?:SSM cache hit: (\d+) tokens skipped|'
                  r'intermediate hit: restored from checkpoint at token (\d+))')
ORACLE_HISTORY = {
    'previous_schema': 'sparkglm.tp4-nvme-probe/v1',
    'previous_receipt': 'results/tp4-chain-strict-native-nvme-pressure/nvme-probe/result.json',
    'previous_receipt_sha256': 'fef471f3d893b05595d7a78131c0dac63fc2061d5b382ccd61c2b0331ad96d7b',
    'previous_run_id': '85f8bbc5b934',
    'change': 'The original oracle compared cold full recomputation with warm prefix reuse only after disk pressure. '
              'Add matched resident warm controls before pressure to isolate disk preservation; retain cold/warm '
              'exactness as a separate overall quality gate. The original failed receipt is preserved.',
}


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def accepted(row):
    return row.get('usage', {}).get('completion_tokens_details', {}).get('accepted_prediction_tokens', 0)


def cached(row):
    return row.get('usage', {}).get('prompt_tokens_details', {}).get('cached_tokens', 0)


def restore_evidence(raw):
    clean = ANSI.sub('', raw)
    rows = [dict((k, int(v)) for k, v in m.groupdict().items()) for m in RESTORE.finditer(clean)]
    skips = [int(a or b) for a, b in SKIP.findall(clean)]
    return {'restores': rows, 'skip_tokens': skips,
            'native_hits': clean.count(NATIVE_HIT), 'native_misses': clean.count(NATIVE_MISS),
            'native_private_evictions': clean.count(NATIVE_EVICT),
            'restore_skipped': 'NVMe prefix restore skipped:' in clean,
            'restore_failed': 'a record FAILED' in clean or 'tail-map publish failed' in clean,
            'nvme_events': [line for line in clean.splitlines() if 'NVMe' in line]}


class Probe:
    def __init__(self, args):
        self.args = args
        self.out = args.out
        self.out.mkdir(exist_ok=False)
        self.snapshots = {}
        self.record = {
            'schema': 'sparkglm.tp4-nvme-probe/v2', 'passed': False,
            'storage_passed': False, 'cold_warm_exact': None,
            'url': args.url, 'run_id': args.run_id or uuid.uuid4().hex[:12],
            'run_id_replayed': args.run_id is not None, 'oracle_history': ORACLE_HISTORY,
            'resident_pressure_only': args.resident_pressure_only,
            'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'started_unix': time.time(), 'expected_blocks': args.blocks, 'block_size': 16,
            'disk_budget_gib': {'combined': 48, 'kv': 24, 'ssm': 24},
            'scope': 'Two forced disk restores; serial pressure preserves native private snapshots. No performance qualification.',
            'requests': [], 'checks': [], 'cycles': [],
        }
        self.save()

    def save(self):
        (self.out / 'result.json').write_text(json.dumps(self.record, indent=2, allow_nan=False) + '\n')

    def check(self, name, condition, **detail):
        self.record['checks'].append({'name': name, 'passed': bool(condition), **detail})
        self.save()
        if not condition:
            raise AssertionError(name)
        print('PASS', name, flush=True)

    def post(self, path, body, timeout=None):
        request = urllib.request.Request(self.args.url + path, json.dumps(body).encode(),
                                         {'Content-Type': 'application/json'})
        return urllib.request.urlopen(request, timeout=timeout or self.args.timeout)

    def tokenize(self, prompt):
        with self.post('/tokenize', {'model': BASE['model'],
                                    'messages': [{'role': 'user', 'content': prompt}],
                                    'chat_template_kwargs': BASE['chat_template_kwargs']}, 60) as response:
            data = json.load(response)
        count = data.get('count', len(data.get('tokens') or []))
        if not isinstance(count, int) or count <= 0:
            raise AssertionError('Tokenizer returned no token count')
        return count

    def prompt(self, label, target_tokens, target=False):
        prefix = f"Archive {self.record['run_id']} {label}. This archive's identifier is ARCHIVE-KITE-4821.\n"
        unit = 'The maintenance record describes a blue cabinet, a numbered shelf, and a dated inspection note.\n'
        suffix = ('\nState the archive identifier exactly, then explain in two short sentences why '
                  'an exact record identifier helps someone find the correct file.' if target else '\nReply only OK.')
        # Measure chat overhead and the marginal unit once, then converge by
        # whole units; tokenization calls do not run model inference.
        base = self.tokenize(prefix + suffix)
        step = self.tokenize(prefix + unit + suffix) - base
        if step <= 0:
            raise AssertionError('Unexpected tokenizer unit size')
        repeats = max(1, (target_tokens - base + step - 1) // step)
        for _ in range(6):
            text = prefix + unit * repeats + suffix
            count = self.tokenize(text)
            if target_tokens <= count <= target_tokens + 2 * step:
                return text, {'prefix': prefix, 'unit': unit, 'repeats': repeats,
                              'suffix': suffix, 'tokenizer_tokens': count, 'sha256': digest(text)}
            repeats = max(1, repeats + (target_tokens - count + step - 1) // step)
        raise AssertionError('Prompt length did not converge')

    def logs(self, rank):
        command = ['docker', 'logs', '--timestamps', f'atlas-sparkglm-unified-rank{rank}']
        if rank:
            command = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
                       HOSTS[rank] + self.args.ssh_suffix, *command]
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                timeout=30, check=True, text=True)
        return result.stdout

    def all_logs(self):
        with cf.ThreadPoolExecutor(4) as pool:
            return dict(zip(range(4), pool.map(self.logs, range(4))))

    def capture(self, label):
        latest = self.all_logs()
        evidence = {}
        for rank, raw in latest.items():
            prior = self.snapshots[rank]
            # Never use overlapping timestamp windows to attribute another
            # request's restore. A truncated/rotated log is a failed proof.
            if not raw.startswith(prior):
                (self.out / f'{label}-rank{rank}-unstable.log').write_text(raw)
                raise AssertionError(f'rank{rank} log rotated or reordered; request evidence is ambiguous')
            delta = raw[len(prior):]
            (self.out / f'{label}-rank{rank}.log').write_text(delta)
            evidence[str(rank)] = {'raw_sha256': digest(delta), **restore_evidence(delta)}
        self.snapshots = latest
        return evidence

    def startup(self):
        self.snapshots = self.all_logs()
        allocations = []
        for rank, raw in self.snapshots.items():
            text = ANSI.sub('', raw)
            blocks = re.findall(r'KV cache: (\d+) blocks [×x] 11 layers', text)
            tiers = [line for line in text.splitlines()
                     if f'prefix cache NVMe spill tier ON (rank {rank}):' in line]
            useful = [line for line in text.splitlines() if any(key in line for key in (
                'KV cache:', 'native GLM MTP private KV allocated', 'prefix cache NVMe spill tier ON'))]
            (self.out / f'rank{rank}-startup.log').write_text('\n'.join(useful) + '\n')
            self.check(f'rank{rank}-pool-cap', bool(blocks) and int(blocks[-1]) == self.args.blocks,
                       observed_blocks=blocks[-1:] or None)
            self.check(f'rank{rank}-four-class-nvme', len(tiers) == 1 and '3 peer classes' in tiers[0],
                       tier=tiers[-1:] or None)
            tier = tiers[0]
            budget = re.search(r'budget ([0-9.]+) GiB', tier)
            self.check(f'rank{rank}-production-tier', bool(budget) and float(budget[1]) == 24.0
                       and 'fast I/O' in tier and 'restored records released' in tier,
                       expected={'kv_budget_gib': 24, 'combined_budget_gib': 48, 'fast': True, 'keep': False})
            allocations.append({'rank': rank, 'target_blocks': int(blocks[-1]),
                                'initial_log_sha256': digest(raw), 'initial_log_bytes': len(raw.encode()),
                                'keep': False})
        private = re.findall(r'native GLM MTP private KV allocated from joint aggregate budget.*?'
                             r'target_blocks=(\d+).*?private_blocks=(\d+)', ANSI.sub('', self.snapshots[0]))
        self.check('native-private-pool-sized', bool(private) and tuple(map(int, private[-1])) ==
                   (self.args.blocks, self.args.blocks + 4), observed=private[-1:] or None)
        self.record['allocations'] = allocations
        self.save()

    def request(self, label, prompt, plan, serial=False, budget=96):
        body = dict(BASE, messages=[{'role': 'user', 'content': prompt}],
                    max_tokens=budget, disable_mtp=serial)
        row = {'label': label, 'serial': serial, 'prompt_plan': plan,
               'body_without_messages': {k: v for k, v in body.items() if k != 'messages'},
               'started_unix': time.time(), 'token_ids': [], 'content': '', 'reasoning_content': ''}
        self.record['requests'].append(row)
        self.save()
        try:
            with (self.out / f'{label}-events.jsonl').open('w') as events:
                with self.post('/v1/chat/completions', body) as response:
                    for raw in response:
                        if not raw.startswith(b'data:'):
                            continue
                        data = raw[5:].strip()
                        if data == b'[DONE]':
                            row['done'] = True
                            break
                        event = json.loads(data)
                        events.write(json.dumps(event, separators=(',', ':')) + '\n')
                        if event.get('error'):
                            raise AssertionError(event['error'])
                        if event.get('usage'):
                            row['usage'] = event['usage']
                        for choice in event.get('choices', []):
                            delta = choice.get('delta') or {}
                            row['token_ids'].extend(choice.get('token_ids') or delta.get('token_ids') or [])
                            for key in ('content', 'reasoning_content'):
                                row[key] += delta.get(key) or ''
                            if choice.get('finish_reason'):
                                row['finish_reason'] = choice['finish_reason']
            self.check(label + '-complete', row.get('done') and bool(row.get('usage'))
                       and bool(row['token_ids']) and row.get('finish_reason') in ('stop', 'length'))
            if serial:
                self.check(label + '-serial', accepted(row) == 0)
            row['rank_logs'] = self.capture(label)
        except BaseException as error:
            row['error'] = repr(error)
            if isinstance(error, urllib.error.HTTPError):
                row['error_body'] = error.read().decode(errors='replace')
            raise
        finally:
            row['ended_unix'] = time.time()
            self.save()
        return row

    def pressure(self, cycle, target_blocks):
        # At least half the old target should be displaced, allowing small
        # shared chat prefixes and block-rounded caching. Actual all-rank
        # disk restoration below is mandatory; this arithmetic is only a
        # bounded way to choose work, never evidence that an eviction occurred.
        goal = self.args.blocks - target_blocks // 2
        fresh = 0
        rows = []
        for index in range(self.args.max_pressure):
            remaining = goal - fresh
            if remaining <= 0:
                break
            desired = min(self.args.pressure_tokens, max(1024, remaining * 16 + 64))
            label = f'cycle{cycle}-pressure{index}'
            prompt, plan = self.prompt(label, desired)
            row = self.request(label, prompt, plan, serial=True, budget=1)
            prompt_tokens = row['usage']['prompt_tokens']
            uncached = max(0, prompt_tokens - cached(row))
            fresh += uncached // 16
            rows.append({'label': label, 'uncached_prompt_tokens': uncached,
                         'new_full_blocks_lower_bound': uncached // 16})
            self.check(label + '-no-private-eviction', not any(
                item['native_private_evictions'] for item in row['rank_logs'].values()))
            self.check(label + '-distinct-prefix', cached(row) < 128, cached_tokens=cached(row))
        self.check(f'cycle{cycle}-bounded-pressure', fresh >= goal,
                   goal_blocks=goal, observed_fresh_blocks=fresh, requests=len(rows))
        return {'goal_blocks': goal, 'fresh_blocks': fresh, 'requests': rows}

    def restored(self, cycle, row, baseline):
        self.check(f'cycle{cycle}-native-used', accepted(row) > 0, accepted=accepted(row))
        self.check(f'cycle{cycle}-cached-rows', cached(row) >= 256, cached_tokens=cached(row))
        for rank, evidence in row['rank_logs'].items():
            restored = evidence['restores']
            valid = bool(restored) and all(
                item['restored'] > 0 and item['restored'] == item['wanted']
                and item['tokens'] == 16 * item['restored'] and item['failures'] == 0
                for item in restored)
            self.check(f'cycle{cycle}-rank{rank}-disk-restore', valid
                       and not evidence['restore_skipped'] and not evidence['restore_failed'], evidence=evidence)
            self.check(f'cycle{cycle}-rank{rank}-reused-target', bool(evidence['skip_tokens'])
                       and max(evidence['skip_tokens']) >= 256 and evidence['native_misses'] == 0,
                       skip_tokens=evidence['skip_tokens'], native_misses=evidence['native_misses'])
        self.check(f'cycle{cycle}-native-private-hit', row['rank_logs']['0']['native_hits'] > 0)
        self.exact(f'cycle{cycle}-exact-greedy-ids', row, baseline)

    def exact(self, label, row, baseline):
        self.check(label, row['token_ids'] == baseline['token_ids'],
                   baseline=baseline['label'], response=row['label'])

    def resident_warm(self, label, row):
        # Cached-token usage alone is insufficient: a native cache miss can
        # report a matched prefix but recompute all target/predictor context.
        for rank, evidence in row['rank_logs'].items():
            self.check(f'{label}-rank{rank}-resident-only', not evidence['restores']
                       and not evidence['restore_skipped'] and not evidence['restore_failed'],
                       evidence=evidence)
            self.check(f'{label}-rank{rank}-reused-target', bool(evidence['skip_tokens'])
                       and max(evidence['skip_tokens']) >= 256 and evidence['native_misses'] == 0,
                       skip_tokens=evidence['skip_tokens'], native_misses=evidence['native_misses'])
        if not row['serial']:
            self.check(label + '-native-private-hit', row['rank_logs']['0']['native_hits'] > 0)
            self.check(label + '-native-used', accepted(row) > 0, accepted=accepted(row))

    def cold_warm(self, cold, warm):
        left, right = cold['token_ids'], warm['token_ids']
        same = left == right
        differing = next((i for i, (a, b) in enumerate(zip(left, right)) if a != b), None)
        if differing is None and len(left) != len(right):
            differing = min(len(left), len(right))
        comparison = {'cold': cold['label'], 'warm': warm['label'], 'exact': same,
                      'cold_ids': len(left), 'warm_ids': len(right), 'first_difference_index': differing}
        self.record.setdefault('cold_warm_comparisons', []).append(comparison)
        self.save()
        print('PASS' if same else 'MISMATCH', 'cold-versus-warm', json.dumps(comparison), flush=True)
        return same

    def resident_pressure(self, prompt, plan, target_blocks, warm_native, warm_serial):
        """One original pressure0 with ample KV room; no disk-restore oracle."""
        pressure_prompt, pressure_plan = self.prompt('cycle1-pressure0', self.args.pressure_tokens)
        # Three extra target generations and one pressure generation are
        # conservatively retained too. This clean-start probe must stay far
        # below capacity, including every prompt and possible output block.
        upper_bound = target_blocks + (pressure_plan['tokenizer_tokens'] + 15) // 16 + 4 * 7 + 1
        self.check('resident-pressure-has-capacity', upper_bound < self.args.blocks // 2,
                   conservative_block_upper_bound=upper_bound, pool_blocks=self.args.blocks)
        pressure = self.request('cycle1-pressure0', pressure_prompt, pressure_plan, serial=True, budget=1)
        self.check('resident-pressure-shared-block-trigger', cached(pressure) == 16,
                   cached_tokens=cached(pressure), note='Original pressure request shares exactly one complete block.')
        native = self.request('resident-pressure-warm-native', prompt, plan)
        serial = self.request('resident-pressure-warm-serial', prompt, plan, serial=True)
        self.resident_warm(native['label'], native)
        self.resident_warm(serial['label'], serial)
        self.record['resident_pressure'] = {
            'pressure': pressure['label'], 'native': native['label'], 'serial': serial['label'],
            'conservative_block_upper_bound': upper_bound,
            'native_exact': native['token_ids'] == warm_native['token_ids'],
            'serial_exact': serial['token_ids'] == warm_serial['token_ids'],
        }
        # Inspect every delta, not just the final target's delta. Full raw
        # per-rank logs remain beside result.json for independent review.
        for row in self.record['requests']:
            for rank, evidence in row['rank_logs'].items():
                self.check(f"resident-{row['label']}-rank{rank}-no-nvme-events",
                           not evidence['nvme_events'], nvme_events=evidence['nvme_events'])
        self.exact('resident-pressure-native-exact', native, warm_native)
        self.exact('resident-pressure-serial-exact', serial, warm_serial)
        self.exact('resident-pressure-serial-native-exact', native, serial)
        self.check('cold-warm-exact-quality', self.record['cold_warm_exact'])
        self.record['passed'] = True
        self.record['storage_passed'] = None
        self.record['scope'] = 'One non-evicting pressure request; resident prefix integrity only. Disk storage not tested.'

    def run(self):
        try:
            self.startup()
            prompt, plan = self.prompt('target', self.args.target_tokens, target=True)
            (self.out / 'target-prompt.txt').write_text(prompt)
            serial = self.request('target-serial', prompt, plan, serial=True)
            self.check('target-serial-fresh-cache', cached(serial) == 0, cached_tokens=cached(serial))
            native = self.request('target-native', prompt, plan)
            self.check('initial-serial-native-exact', serial['token_ids'] == native['token_ids'])
            for row in (serial, native):
                self.check(row['label'] + '-full-recompute-control', not any(
                    item['restores'] or item['skip_tokens'] for item in row['rank_logs'].values()))
            self.check('initial-native-used', accepted(native) > 0, accepted=accepted(native))
            self.check('initial-retrieval', all('ARCHIVE-KITE-4821' in row['content'] for row in (serial, native)))
            warm_native = self.request('target-warm-native', prompt, plan)
            self.resident_warm('target-warm-native', warm_native)
            warm_serial = self.request('target-warm-serial', prompt, plan, serial=True)
            self.resident_warm('target-warm-serial', warm_serial)
            self.exact('warm-serial-native-exact', warm_native, warm_serial)
            # Always record both comparisons; do not short-circuit the second.
            native_exact = self.cold_warm(native, warm_native)
            serial_exact = self.cold_warm(serial, warm_serial)
            self.record['cold_warm_exact'] = native_exact and serial_exact
            self.save()
            target_blocks = native['usage']['prompt_tokens'] // 16
            self.check('target-fits-with-headroom', 16 <= target_blocks < self.args.blocks // 2,
                       target_blocks=target_blocks)
            if self.args.resident_pressure_only:
                self.record['scope'] = 'One non-evicting pressure request; resident prefix integrity only. Disk storage not tested.'
                self.record['storage_passed'] = None
                self.resident_pressure(prompt, plan, target_blocks, warm_native, warm_serial)
                return
            for cycle in (1, 2):
                pressure = self.pressure(cycle, target_blocks)
                row = self.request(f'cycle{cycle}-target-restore', prompt, plan)
                self.restored(cycle, row, warm_native)
                serial_after = self.request(f'cycle{cycle}-warm-serial', prompt, plan, serial=True)
                self.resident_warm(f'cycle{cycle}-warm-serial', serial_after)
                self.exact(f'cycle{cycle}-serial-exact-greedy-ids', serial_after, warm_serial)
                self.exact(f'cycle{cycle}-serial-native-exact', row, serial_after)
                self.record['cycles'].append({'cycle': cycle, 'pressure': pressure,
                                              'response': row['label'], 'rank_logs': row['rank_logs'],
                                              'serial_control': serial_after['label']})
                self.save()
            self.record['storage_passed'] = True
            self.check('cold-warm-exact-quality', self.record['cold_warm_exact'],
                       storage_passed=True, note='Storage isolation completed; this quality gate is not waived.')
            self.record['passed'] = True
        except BaseException as error:
            self.record['error'] = repr(error)
            raise
        finally:
            self.record['ended_unix'] = time.time()
            self.save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url', default='http://127.0.0.1:8893')
    parser.add_argument('--out', type=Path, default=Path.cwd() / 'nvme-probe')
    parser.add_argument('--blocks', type=int, default=2048)
    parser.add_argument('--target-tokens', type=int, default=4096)
    parser.add_argument('--pressure-tokens', type=int, default=8192)
    parser.add_argument('--max-pressure', type=int, default=5)
    parser.add_argument('--timeout', type=float, default=600)
    parser.add_argument('--ssh-suffix', default='-fab')
    parser.add_argument('--run-id', help='Replay the original 12-digit hex prompt run ID after a clean server reload')
    parser.add_argument('--resident-pressure-only', action='store_true',
                        help='Use only original pressure0 with ample pool headroom, then check resident prefix integrity')
    args = parser.parse_args()
    if args.blocks < 128 or args.max_pressure < 1 or args.target_tokens < 256:
        parser.error('invalid bounded probe configuration')
    if args.run_id is not None and not re.fullmatch(r'[0-9a-f]{12}', args.run_id):
        parser.error('--run-id must be exactly 12 lowercase hexadecimal characters')
    Probe(args).run()


if __name__ == '__main__':
    main()
