# GLM TP2 focused fixes — 2026-10-20

Both reported blockers are fixed in the affected checks. The final image is a local RC. No full benchmark campaign was rerun.

| Check | Result |
|---|---|
| Original rolling C4 arithmetic/needle boundary | 10/10 correct after disabling shared-expert TP splitting |
| Arithmetic control | Correct `-381530`; serial and speculative output match exactly (211 tokens) |
| Short C4 native MTP | Four prompts match serial exactly; reused R2 evidence |
| Near-limit prompt | 1,046,988 tokens; native output matches saved serial reference |
| Identical cached C4 | Four simultaneously active sequences; exact seeded output |
| Distinct-tail cached C4 | Four concurrently admitted resident sequences; each output matches its serial control |
| Cancellation and slot reuse | Passed on R2; reused because admission and model execution are unchanged |
| Minimum sampled host memory available | 01: 4.279 GiB; 02: 12.570 GiB; required floor 4 GiB |

## Arithmetic

With shared-expert TP splitting enabled, `2123 * 49 - 7256 * 67 + 595` returned `-382130`. This reproduced in serial and speculative decoding, and at C1: the failure was not caused by C4 scheduling or MTP acceptance. Changing only `ATLAS_GLM_SHARED_TP_SPLIT` from 1 to 0 corrected the answer and passed the ten original boundary requests.

The split changes BF16 partial-sum and blending order around the all-reduce. The code audit found no indexing or scale-layout defect. Spark TP2 now disables this split. Corrected FP4 decode and shared-expert quantization stay enabled. The earlier split experiment showed only a 1.70% prose gain in one run on an older native build, insufficient to justify the reproduced fidelity loss.

## Native MTP

The loader releases 147.082 MiB of obsolete MXFP8 source weights and scales after creating owned BF16 predictor tensors. It also removes 285.25 MiB of duplicate lazy-expansion reserve. The budget improvement is 432.332 MiB; only 147.082 MiB was actual retained tensor memory. Strict native 4x1m uses 66,000 target blocks and 66,004 private predictor blocks, fitting at .91 GPU-memory utilization. The request limit remains 1,048,576 tokens. The near-limit checks use the dedicated-pair configuration: KV sharding and display carveout enabled, with a 48 GiB disk prefix cache per rank. The launcher's conservative memory-utilization default remains unchanged; .91 is an explicit setting for this verified configuration.

Admission counts shared physical target blocks once while retaining private and future reservations per sequence. Both ranks must prove the same current resident checkpoint; rank 0 must also prove its paired native checkpoint and private continuation space. A following branch may use a deeper checkpoint established by the preceding branch within their common pinned prefix. This corrected the distinct-tail C4 failure. NVMe caching stays enabled; disk restores use conservative admission.

Host memory remained the final problem. Four million-token request preparations could overlap ahead of GPU admission. A two-wide gate helped, but the Linux allocator retained substantial tokenizer metadata. Serializing those encodes further barely reduced peak RSS and increased encoding time. The selected fix uses the tokenizer's IDs-only path, avoiding unused token spellings and offsets, with the existing two-wide gate. Both switches are enabled only in Strict native 4x1m. GPU concurrency and model arithmetic are unchanged.

A matched Linux CPU test (cold C1, then two C4 bursts retaining returned token IDs) reduced peak RSS from 2,789,044,224 to 2,155,061,248 bytes, about 605 MiB. Encoding time was 5.836 versus 5.786 seconds in that single experiment. The served tokenizer returned exactly the same IDs across 160 cases: all 42 checked-in chat/tool prompts, 36 special tokens in multiple boundary contexts, Unicode/JSON cases, and the complete near-1M body. These are tokenizer measurements, not model-throughput claims.

## Validation and identity

The first live attempt reached a 3.650 GiB minimum and exposed the advancing-checkpoint problem. R2 fixed distinct-tail C4 but still reached 3.826 GiB. The final replay measures the leader every 100 ms and rank 1 every second plus SSH latency; the sampled minima are shown above. It reruns one prefix prefill and the two affected C4 bursts, comparing to saved matching serial controls. Short C4 and cancellation/reuse are carried forward from R2. Failed attempts remain in the receipt archive.

The final raw script stopped at its requirement for four simultaneous *decoding* sequences in the distinct-tail burst. A receipt audit and independent source review found that all four were already admitted into distinct resident slots: the fourth completed inline chunk 0 at 04:59:43.560092 UTC, and the first request retired at 04:59:49.195796, an overlap of 5.635704 seconds. That short answer finished before the other two prefills completed, so decode width peaked at three. Identical-prefix C4 did reach four simultaneous decodes. All distinct-tail outputs match the saved serial controls exactly; minimum memory remained 4.279 GiB. This was a timing-sensitive test assertion, not an admission failure. The corrected resident-concurrency check rejects the original two-slot failure and passes R2 and the final run. `focused-verdict.json` records that correction; the original failed assertion and raw result are preserved unchanged. No additional GPU replay was needed.

Arithmetic was verified on `sha256:05cbc8591b31b7259aba3e846f44d3ee6188a98c9b19c97a4e0f6e3bc1e0cb10`. Subsequent changes leave Spark arithmetic policy and numerical code unchanged. The final image is `sha256:147c059d5229338f44bed47020334fcab914cda14b128736968d67d53017018d`, from engine `ddd6a0d33d54e2efac7c29b982009daa27d7a840` and product `a435e7ac6357482297da3e3b431a2e50e6aa91d8`. Its binary SHA-256 is `ba519f996e50d2500897af9b8b2993a7d629f00bf925ae36b55e00e8d064423e`. Both ranks were attested; build inputs were hash-checked. Native libraries and profile JSON bytes match the preceding RC.

Affected regression checks passed: 10 loader tests, 24 admission tests, 5 native-prefix tests, 2 IDs-only tests, 3 large-encode tests, and 50 product install tests. Loader/admission evidence belongs to the earlier images where those files last changed. No Kindling, RigMark, full quality suite, NLL, full needle suite, or sampler campaign was repeated. Previous 8x128k Kindling already had shared splitting off; previous 4x1m Rig used it on and is not final-policy performance evidence.

These results cover four branches sharing a resident near-1M prefix, not four independent million-token contexts. Memory figures are sampled workload minima, not a universal worst-case guarantee.

Managed serving was restored to its recorded image, normal clock caps were checked on both ranks, the LLooM lease was released, and a gateway request returned `42`. The fixed RC remains local; no public release or push was made.

`qualification.json` records the result and evidence reuse. The patch files contain the scoped changes. `receipts.tar.gz` includes raw requests, memory samples, logs, identity checks, build/test logs, and diagnostic harnesses. `SHA256SUMS` covers the deliverables.
